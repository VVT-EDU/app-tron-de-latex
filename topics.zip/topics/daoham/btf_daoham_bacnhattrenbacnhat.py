import random
from fractions import Fraction

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    return (f"\\choiceTF \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def to_latex(frac):
    """Chuyển đổi Fraction sang LaTeX, triệt tiêu mẫu số nếu bằng 1."""
    if frac.denominator == 1:
        return str(frac.numerator)
    return rf"\dfrac{{{frac.numerator}}}{{{frac.denominator}}}"

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    while True:
        a = random.randint(-3, 3)
        b = random.randint(-5, 5)
        c = random.choice([-2, -1, 1, 2])
        d = random.randint(-3, 3)
        det = a*d - b*c
        if det != 0: break
        
    while True:
        xM = random.randint(-3, 3)
        if c*xM + d != 0: break

    # Sử dụng Fraction để tính toán hữu tỉ
    A, B, C, D, XM = Fraction(a), Fraction(b), Fraction(c), Fraction(d), Fraction(xM)

    # --- 2. TÍNH TOÁN ---
    yM = (A * XM + B) / (C * XM + D)
    k = Fraction(a*d - b*c, (c*xM + d)**2)
    intercept = yM - k * XM

    # --- 3. ĐỊNH DẠNG ĐA THỨC TỬ/MẪU ---
    def fmt_poly(h1, h2):
        res = ""
        if h1 != 0:
            if h1 == 1: res += "x"
            elif h1 == -1: res += "-x"
            else: res += f"{h1}x"
        if h2 != 0:
            res += f"{h2:+}" if res != "" else str(h2)
        return res if res != "" else "0"

    f_tu = fmt_poly(a, b)
    f_mau = fmt_poly(c, d)
    f_x_tex = rf"\dfrac{{{f_tu}}}{{{f_mau}}}"
    
    f_prime_x_tex = rf"\dfrac{{{a*d - b*c}}}{{({f_mau})^2}}"

    # Phương trình tiếp tuyến y = kx + m
    def fmt_pttt(k_val, m_val):
        k_tex = to_latex(k_val)
        m_tex = to_latex(m_val)
        
        if k_val == 1: k_part = "x"
        elif k_val == -1: k_part = "-x"
        else: k_part = rf"{k_tex}x"
        
        if m_val == 0: return f"y = {k_part}"
        m_sign = "+" if m_val > 0 else "" 
        return f"y = {k_part} {m_sign} {m_tex}"

    pt_tt_tex = fmt_pttt(k, intercept)

    # --- 4. DANH SÁCH KHẲNG ĐỊNH ---
    dung_list = [
        rf"Đạo hàm của hàm số là $f'(x) = {f_prime_x_tex}$",
        rf"Hệ số góc của tiếp tuyến tại $M({xM}; {to_latex(yM)})$ là $k = {to_latex(k)}$",
        rf"Phương trình tiếp tuyến tại $M$ là ${pt_tt_tex}$",
        rf"Hàm số nghịch biến trên từng khoảng xác định" if (a*d-b*c) < 0 else rf"Hàm số đồng biến trên từng khoảng xác định",
        rf"Tọa độ tiếp điểm là $M\left({xM}; {to_latex(yM)}\right)$"
    ]
    
    sai_list = [
        rf"Hệ số góc của tiếp tuyến tại $M$ là $k = {to_latex(yM)}$",
        rf"Phương trình tiếp tuyến tại $M$ là $y = {to_latex(k)}x$",
        rf"Tọa độ tiếp điểm là $M\left({to_latex(yM)}; {xM}\right)$",
        rf"Đạo hàm của hàm số là $f'(x) = \dfrac{{{a*d + b*c}}}{{({f_mau})^2}}$",
        rf"Hàm số có đạo hàm tại $x = {to_latex(Fraction(-d, c))}$"
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 5. RENDER (SỬA LỖI DẤU yM_join) ---
    # Thay vì dùng f"{to_latex(yM):+}", ta dùng logic if/else
    if yM > 0:
        yM_join = " + " + to_latex(yM)
    elif yM < 0:
        yM_join = " " + to_latex(yM) # Dấu trừ đã có sẵn trong to_latex
    else:
        yM_join = ""

    return rf"""\begin{{ex}}
    Cho hàm số $f(x) = {f_x_tex}$ có đồ thị $(C)$. Gọi $M$ là điểm thuộc $(C)$ có hoành độ $x_M = {xM}$.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        \begin{{itemize}}
            \item Tập xác định: $D = \mathbb{{R}} \setminus \left\{{ {to_latex(Fraction(-d, c))} \right\}}$.
            \item Đạo hàm: $f'(x) = \dfrac{{{a}({d}) - ({b})({c})}}{{({f_mau})^2}} = {f_prime_x_tex}$.
            \item Tại $x_M = {xM} \Rightarrow y_M = f({xM}) = {to_latex(yM)}$. Vậy $M({xM}; {to_latex(yM)})$.
            \item Hệ số góc tiếp tuyến tại $M$: $k = f'({xM}) = {to_latex(k)}$.
            \item Phương trình tiếp tuyến: $y = {to_latex(k)}(x - ({xM})) {yM_join} \Leftrightarrow {pt_tt_tex}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
