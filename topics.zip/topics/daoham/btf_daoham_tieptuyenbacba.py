import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    # Đảm bảo danh sách có đủ phần tử để lấy mẫu
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def format_poly(coeffs):
    """Hàm bổ trợ viết đa thức đẹp: loại bỏ hệ số 1, xử lý dấu, bỏ số 0."""
    res = ""
    degrees = len(coeffs) - 1
    for i, c in enumerate(coeffs):
        p = degrees - i
        if c == 0: continue
        
        # Xử lý dấu
        sign = "+" if c > 0 and res != "" else ""
        if c < 0: sign = "-"
        
        # Xử lý trị tuyệt đối hệ số
        abs_c = abs(c)
        if abs_c == 1 and p > 0:
            val = ""
        else:
            val = str(abs_c)
            
        # Ghép biến x
        if p == 0:
            res += f" {sign} {abs_c}"
        elif p == 1:
            res += f" {sign} {val}x"
        else:
            res += f" {sign} {val}x^{p}"
    return res.strip()

import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def format_poly(coeffs):
    """Hàm bổ trợ viết đa thức đẹp: loại bỏ hệ số 1, xử lý dấu, bỏ số 0."""
    res = ""
    degrees = len(coeffs) - 1
    for i, c in enumerate(coeffs):
        p = degrees - i
        if c == 0: continue
        
        sign = "+" if c > 0 and res != "" else ""
        if c < 0: sign = "-"
        
        abs_c = abs(c)
        if abs_c == 1 and p > 0:
            val = ""
        else:
            val = str(abs_c)
            
        if p == 0:
            res += f" {sign} {abs_c}"
        elif p == 1:
            res += f" {sign} {val}x"
        else:
            res += f" {sign} {val}x^{p}"
    return res.strip()

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    a = random.choice([-2, -1, 1, 2])
    b = random.randint(-3, 3)
    c = random.randint(-4, 4)
    d = random.randint(-5, 5)
    xM = random.randint(-2, 2)
    
    # --- 2. TÍNH TOÁN TOÁN HỌC ---
    f_x_tex = format_poly([a, b, c, d])
    f_prime_coeffs = [3*a, 2*b, c]
    f_prime_x_tex = format_poly(f_prime_coeffs)
    
    yM = a*(xM**3) + b*(xM**2) + c*xM + d
    k = 3*a*(xM**2) + 2*b*xM + c
    
    intercept = yM - k*xM
    pt_tt_tex = f"y = {format_poly([k, intercept])}" if k != 0 else f"y = {intercept}"

    # --- 3. CHUẨN BỊ CHUỖI CHO LỜI GIẢI ---
    yM_detail = rf"{a}({xM})^3"
    if b != 0: yM_detail += rf" {b:+} \cdot ({xM})^2"
    if c != 0: yM_detail += rf" {c:+} \cdot ({xM})"
    if d != 0: yM_detail += rf" {d:+}"

    k_detail = rf"3 \cdot ({a}) \cdot ({xM})^2"
    if b != 0: k_detail += rf" + 2 \cdot ({b}) \cdot ({xM})"
    if c != 0: k_detail += rf" {c:+}"
    
    # Xử lý dấu của yM để đưa vào phương trình y = k(x-xM) + yM
    yM_sign = rf"{yM:+}" if yM != 0 else ""

    # Tạo phương án sai cho đạo hàm
    f_prime_sai_tex = format_poly([a, b, c]) 

    # --- 4. DANH SÁCH KHẲNG ĐỊNH ---
    dung_list = [
        rf"Đạo hàm của hàm số là $f'(x) = {f_prime_x_tex}$",
        rf"Tọa độ tiếp điểm là $M({xM}; {yM})$",
        rf"Hệ số góc của tiếp tuyến tại $M$ là $k = {k}$",
        rf"Phương trình tiếp tuyến tại $M$ là ${pt_tt_tex}$",
        rf"Hàm số $f(x)$ liên tục và có đạo hàm trên $\mathbb{{R}}$",
        rf"Giá trị $f'(0) = {c}$"
    ]
    
    sai_list = [
        rf"Đạo hàm của hàm số là $f'(x) = {f_prime_sai_tex}$",
        rf"Hệ số góc của tiếp tuyến tại $M$ là $k = {yM}$",
        rf"Phương trình tiếp tuyến tại $M$ là $y = {k}x$",
        rf"Tọa độ tiếp điểm là $M({yM}; {xM})$",
        rf"Đạo hàm của hàm số tại $x=0$ là $f'(0) = {a+b+c}$",
        rf"Tiếp tuyến tại $M$ có hệ số góc $k = -{k}$" if k != 0 else "Tiếp tuyến tại $M$ song song với trục tung"
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 5. RENDER MÃ EX ---
    return rf"""\begin{{ex}}
    Cho hàm số $f(x) = {f_x_tex}$ có đồ thị là đường cong $(C)$. Gọi $M$ là điểm thuộc $(C)$ có hoành độ $x_M = {xM}$.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        \begin{{itemize}}
            \item Đạo hàm của hàm số: $f'(x) = {f_prime_x_tex}$.
            \item Với hoành độ $x_M = {xM} \Rightarrow y_M = f({xM}) = {yM_detail} = {yM}$. Vậy $M({xM}; {yM})$.
            \item Hệ số góc tiếp tuyến tại $M$: $k = f'({xM}) = {k_detail} = {k}$.
            \item Phương trình tiếp tuyến tại $M$: $y = k(x - x_M) + y_M$.
            Thay số: $y = {k}(x - ({xM})) {yM_sign} \Leftrightarrow {pt_tt_tex}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
