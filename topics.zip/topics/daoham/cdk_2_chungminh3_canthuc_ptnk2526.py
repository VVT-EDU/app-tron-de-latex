import random
from sympy import symbols, diff, latex, simplify, Rational, N
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    """Hàm làm tròn chuẩn toán học (0.5 lên 1)"""
    try:
        d = Decimal(str(float(number)))
        if decimals == 0:
            factor_dec = Decimal('1')
        else:
            factor_dec = Decimal('1.' + '0' * decimals)
        return float(d.quantize(factor_dec, rounding=ROUND_HALF_UP))
    except:
        return int(number + 0.5)

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    m_sym = symbols('m')
    h_value = random.randint(1, 5)
    a = 2 * h_value + 3  # Tạo số lẻ: 5, 7, 9, 11, 13
    
    # Số mũ n = a/2
    n = Rational(a, 2)
    
    # Định nghĩa hàm y = (2x - 1)^(a/2)
    f = (2 * x - 1)**n
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    # Đạo hàm bậc một: y' = n * u^(n-1) * u'
    f1 = simplify(diff(f, x))
    f1_sq = simplify(f1**2) # (y')^2
    
    # Đạo hàm bậc hai: y''
    f2 = simplify(diff(f1, x))
    y_f2 = simplify(f * f2) # y * y''
    
    # Tìm hệ số m: m * (y')^2 = y * y'' => m = (y * y'') / (y')^2
    # Với dạng hàm này, m sẽ là một hằng số (n-1)/n
    m_exact = simplify(y_f2 / f1_sq)
    
    # Tính giá trị làm tròn của m
    m_float = float(N(m_exact))
    m_rounded = int(round_half_up(m_float, 0))
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai_tap = (
        f"Cho hàm số $y = {latex(f)}$. Biết rằng giữa hàm số và các đạo hàm của nó có mối liên hệ "
        f"${latex(m_sym)} \\cdot (y')^2 = y \\cdot y''$. Tính giá trị của ${latex(m_sym)}$ "
        f"(làm tròn kết quả đến hàng đơn vị)."
    )

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số: $y = {latex(f)}$.",
        f"Tính đạo hàm bậc nhất: $y' = ({latex(f)})' = {latex(f1)}$.",
        f"Tính đạo hàm bậc hai: $y'' = ({latex(f1)})' = {latex(f2)}$.",
        f"Ta có các biểu thức:",
        f"$(y')^2 = ({latex(f1)})^2 = {latex(f1_sq)}$.",
        f"$y \\cdot y'' = {latex(f)} \\cdot ({latex(f2)}) = {latex(y_f2)}$.",
        f"Từ phương trình ${latex(m_sym)} \\cdot (y')^2 = y \\cdot y''$, ta có:",
        f"${latex(m_sym)} = \\frac{{y \\cdot y''}}{{(y')^2}} = \\frac{{{latex(y_f2)}}}{{{latex(f1_sq)}}} = {latex(m_exact)}$.",
        f"Giá trị xấp xỉ: $m \\approx {m_float:.3f}$.",
        f"Làm tròn đến hàng đơn vị, ta được $m = {m_rounded}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai_tap}
    \shortans{{ ${m_rounded}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    # In ra thử một bài toán
    print(generate())
