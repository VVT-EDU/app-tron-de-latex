import random
from sympy import symbols, diff, latex, simplify, exp, N, expand, Rational
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    """Hàm làm tròn chuẩn toán học (0.5 lên 1)"""
    try:
        d = Decimal(str(float(number)))
        if decimals == 0:
            factor_dec = Decimal('1')
        else:
            factor_dec = Decimal('1.' + '0' * decimals)
        return float(d.quantize(factor_dec, rounding=ROUND_HALF_UP))
    except:
        return int(number + 0.5)

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    h_value = random.randint(1, 4)
    a_val = h_value + 2  # a sẽ là các số nguyên từ 3 đến 6
    a = Rational(a_val, 1) # Sử dụng Rational để biểu diễn hệ số nguyên
    
    # Định nghĩa hàm y = e^{ax} - a*e^{2x}
    f = exp(a * x) - a * exp(2 * x)
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    f1 = diff(f, x)        # y' = a*e^{ax} - 2a*e^{2x}
    f2 = diff(f1, x)       # y'' = a^2*e^{ax} - 4a*e^{2x}
    
    # Biểu thức liên hệ: y'' - a*y'
    # = (a^2*e^{ax} - 4a*e^{2x}) - a*(a*e^{ax} - 2a*e^{2x})
    # = a^2*e^{ax} - 4a*e^{2x} - a^2*e^{ax} + 2a^2*e^{2x}
    # = (2a^2 - 4a) * e^{2x}
    tongso = simplify(f2 - a * f1)
    
    # Tính giá trị tại x = 0
    x0 = 0
    m_at_x0 = tongso.subs(x, x0)
    m_float = float(N(m_at_x0))
    m_rounded = int(round_half_up(m_float, 0))
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai = (
        f"Cho hàm số $y = {latex(f)}$. Biết rằng tại $x = {x0}$, "
        f"biểu thức $y'' - {a_val}y' = m$. "
        f"Tính giá trị của $m$ (làm tròn kết quả đến hàng đơn vị)."
    )

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số: $y = {latex(f)}$.",
        f"Đạo hàm bậc nhất: $y' = {latex(f1)}$.",
        f"Suy ra ${a_val} \\cdot y' = {latex(expand(a * f1))}$.",
        f"Đạo hàm bậc hai: $y'' = {latex(f2)}$.",
        f"Tính biểu thức liên hệ: $y'' - {a_val}y' = ({latex(f2)}) - ({latex(expand(a * f1))})$.",
        f"Rút gọn ta được: $y'' - {a_val}y' = {latex(tongso)}$.",
        f"Tại $x = {x0}$, ta có $m = {latex(m_at_x0)}$.",
        f"Làm tròn đến hàng đơn vị, kết quả là $m = {m_rounded}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai}
    \shortans{{ ${m_rounded}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
