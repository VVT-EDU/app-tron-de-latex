import random
from sympy import symbols, diff, latex, expand, Eq, solve, N
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    """Hàm làm tròn chuẩn toán học"""
    try:
        d = Decimal(str(float(number)))
        if decimals == 0:
            factor = Decimal('1')
        else:
            factor = Decimal('1.' + '0' * decimals)
        return float(d.quantize(factor, rounding=ROUND_HALF_UP))
    except:
        return int(number + 0.5)

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    h_value = random.randint(1, 5)
    m = 2 * h_value + 1
    
    # Đa thức đặc biệt: a=m, b=-6m, c=1, d=1
    a, b, c, d = m, -6 * m, 1, 1
    f = a * x**3 + b * x**2 + c * x + d
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    f1 = diff(f, x)        # y'
    f2 = diff(f1, x)       # y''
    
    # Biểu thức vế trái của phương trình: x^2 * y'' - 6y
    # Khi thay vào, các hạng mục x^3 sẽ tự triệt tiêu do cấu trúc hệ số
    vt_pt = expand(x**2 * f2 - 6 * f)
    
    # 3. GIẢI PHƯƠNG TRÌNH vt_pt = 0
    pt = Eq(vt_pt, 0)
    nghiem = solve(pt, x)
    
    # Tính tổng các nghiệm và làm tròn
    tong_nghiem_chinh_xac = sum(nghiem)
    tong_float = float(N(tong_nghiem_chinh_xac))
    kq_lam_tron = int(round_half_up(tong_float, 0))
    
    # 4. TRÌNH BÀY ĐỀ BÀI
    bai_tap = (
        f"Cho hàm số $ y = {latex(f)}$. "
        f"Tính tổng các số $x$ thỏa mãn phương trình $x^2 \\cdot y'' - 6y = 0$ "
        f"(làm tròn kết quả đến hàng đơn vị)."
    )

    # 5. CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số: $y = {latex(f)}$.",
        f"Đạo hàm cấp một: $y' = {latex(f1)}$.",
        f"Đạo hàm cấp hai: $y'' = {latex(f2)}$.",
        f"Thay vào phương trình $x^2 \\cdot y'' - 6y = 0$, ta được:",
        f"$x^2 \\cdot ({latex(f2)}) - 6 \\cdot ({latex(f)}) = 0$.",
        f"$\\Leftrightarrow {latex(vt_pt)} = 0$.",
        f"Giải phương trình bậc hai trên, ta tìm được tập nghiệm $x \\in \\left\\{{ {', '.join([latex(n) for n in nghiem])} \\right\\}} $.",
        f"Tổng các nghiệm là $S = {latex(tong_nghiem_chinh_xac)} \\approx {tong_float:.3f}$.",
        f"Làm tròn đến hàng đơn vị, ta được kết quả bằng ${kq_lam_tron}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 6. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
    {bai_tap}
    \shortans{{ ${kq_lam_tron}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
