import random
from fractions import Fraction

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    return (f"\\choiceTF \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def to_latex(frac):
    """Chuyển đổi Fraction sang LaTeX, triệt tiêu mẫu số nếu bằng 1."""
    if frac.denominator == 1:
        return str(frac.numerator)
    return rf"\dfrac{{{frac.numerator}}}{{{frac.denominator}}}"

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    # f(x) = ax^4 + bx^2 + c
    a_val = random.choice([-2, -1, -0.5, 0.5, 1, 2])
    b_val = random.randint(-4, 4)
    c_val = random.randint(-5, 5)
    
    # Ép kiểu sang Fraction để tính toán chính xác
    A, B, C = Fraction(a_val), Fraction(b_val), Fraction(c_val)
    
    # Chọn hoành độ tiếp điểm xM (tránh x=0 để bài toán tiếp tuyến thú vị hơn)
    xM_val = random.choice([-2, -1, 1, 2])
    XM = Fraction(xM_val)

    # --- 2. TÍNH TOÁN ---
    # f(xM) = a*xM^4 + b*xM^2 + c
    yM = A * (XM**4) + B * (XM**2) + C
    
    # f'(x) = 4ax^3 + 2bx
    # f'(xM) = 4*a*xM^3 + 2*b*xM
    k = 4 * A * (XM**3) + 2 * B * XM
    
    # Phương trình tiếp tuyến: y = k(x - xM) + yM  => y = kx + (yM - k*xM)
    intercept = yM - k * XM

    # --- 3. ĐỊNH DẠNG ĐỀ BÀI ---
    def fmt_poly_trung_phuong(a, b, c):
        res = ""
        # Hệ số a (x^4)
        if a == 1: res += "x^4"
        elif a == -1: res += "-x^4"
        else: res += f"{to_latex(Fraction(a))}x^4"
        
        # Hệ số b (x^2)
        if b != 0:
            b_frac = Fraction(b)
            if b_frac == 1: res += " + x^2"
            elif b_frac == -1: res += " - x^2"
            else:
                sign = " + " if b_frac > 0 else " - "
                res += f"{sign}{to_latex(abs(b_frac))}x^2"
        
        # Hệ số c
        if c != 0:
            c_frac = Fraction(c)
            sign = " + " if c_frac > 0 else " - "
            res += f"{sign}{to_latex(abs(c_frac))}"
        return res

    f_x_tex = fmt_poly_trung_phuong(a_val, b_val, c_val)
    
    # Đạo hàm f'(x) hiển thị
    def fmt_f_prime(a, b):
        a4 = 4 * Fraction(a)
        b2 = 2 * Fraction(b)
        res = ""
        if a4 == 1: res += "x^3"
        elif a4 == -1: res += "-x^3"
        else: res += f"{to_latex(a4)}x^3"
        
        if b2 != 0:
            sign = " + " if b2 > 0 else " - "
            val = to_latex(abs(b2))
            if val == "1": res += f"{sign}x"
            else: res += f"{sign}{val}x"
        return res

    f_prime_x_tex = fmt_f_prime(a_val, b_val)

    # --- 4. DANH SÁCH KHẲNG ĐỊNH ---
    def fmt_pttt(k_val, m_val):
        k_t = to_latex(k_val)
        m_t = to_latex(m_val)
        if k_val == 1: k_p = "x"
        elif k_val == -1: k_p = "-x"
        elif k_val == 0: k_p = ""
        else: k_p = f"{k_t}x"
        
        if m_val == 0: return f"y = {k_p}" if k_p != "" else "y = 0"
        m_s = " + " if m_val > 0 else " - "
        return f"y = {k_p}{m_s}{to_latex(abs(m_val))}"

    pt_tt_tex = fmt_pttt(k, intercept)

    dung_list = [
        rf"Đạo hàm của hàm số đã cho là $f'(x) = {f_prime_x_tex}$",
        rf"Hệ số góc của tiếp tuyến tại điểm $M$ có hoành độ $x_M = {xM_val}$ là $k = {to_latex(k)}$",
        rf"Tọa độ tiếp điểm là $M({xM_val}; {to_latex(yM)})$",
        rf"Phương trình tiếp tuyến của đồ thị $(C)$ tại $M$ là ${pt_tt_tex}$",
        rf"Đồ thị $(C)$ của hàm số đối xứng qua trục tung $Oy$",
        rf"Hàm số đã cho là hàm số chẵn"
    ]
    
    sai_list = [
        rf"Hệ số góc của tiếp tuyến tại $M$ là $k = f({xM_val})$",
        rf"Đạo hàm của hàm số là $f'(x) = {to_latex(Fraction(a_val))}x^3 + {to_latex(Fraction(b_val))}x$", # Sai quy tắc đạo hàm nx^{n-1}
        rf"Phương trình tiếp tuyến tại $M$ là $y = {to_latex(k)}x$",
        rf"Tọa độ tiếp điểm là $M({to_latex(yM)}; {xM_val})$",
        rf"Đồ thị hàm số đối xứng qua tâm đối xứng $O(0;0)$",
        rf"Tiếp tuyến của đồ thị tại điểm cực trị có hệ số góc bằng $1$"
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 5. RENDER LỜI GIẢI ---
    yM_join = (" + " + to_latex(yM)) if yM > 0 else (" - " + to_latex(abs(yM))) if yM < 0 else ""

    return rf"""\begin{{ex}}
    Cho hàm số $f(x) = {f_x_tex}$ có đồ thị $(C)$. Gọi $M$ là điểm thuộc $(C)$ có hoành độ $x_M = {xM_val}$.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        \begin{{itemize}}
            \item Đạo hàm: $f'(x) = ({to_latex(A)}x^4)' + ({to_latex(B)}x^2)' + ({to_latex(C)})' = {f_prime_x_tex}$.
            \item Tung độ tiếp điểm: $y_M = f({xM_val}) = {to_latex(A)} \cdot ({xM_val})^4 + {to_latex(B)} \cdot ({xM_val})^2 + {to_latex(C)} = {to_latex(yM)}$.
            \item Hệ số góc tiếp tuyến tại $M$: $k = f'({xM_val}) = {to_latex(k)}$.
            \item Phương trình tiếp tuyến: $y = k(x - x_M) + y_M$
            $\Leftrightarrow y = {to_latex(k)}(x - ({xM_val})) {yM_join} \Leftrightarrow {pt_tt_tex}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
