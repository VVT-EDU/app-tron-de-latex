import random
from fractions import Fraction

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    return (f"\\choiceTF \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def to_latex(frac):
    """Chuyển đổi Fraction sang LaTeX, triệt tiêu mẫu số nếu bằng 1."""
    if frac.denominator == 1:
        return str(frac.numerator)
    return rf"\dfrac{{{frac.numerator}}}{{{frac.denominator}}}"

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    # f(x) = (ax^2 + bx + c) / (dx + e)
    while True:
        a = random.randint(-2, 2)
        if a == 0: a = 1 # Đảm bảo là bậc 2
        b = random.randint(-3, 3)
        c = random.randint(-4, 4)
        d = random.choice([-1, 1]) # Giữ mẫu đơn giản d=1 hoặc -1
        e = random.randint(-3, 3)
        
        # Chọn xM sao cho xM != -e/d
        xM_val = random.randint(-2, 3)
        if d * xM_val + e != 0: break

    # Ép kiểu sang Fraction
    A, B, C, D, E, XM = Fraction(a), Fraction(b), Fraction(c), Fraction(d), Fraction(e), Fraction(xM_val)

    # --- 2. TÍNH TOÁN ---
    # f(xM) = (a*xM^2 + b*xM + c) / (d*xM + e)
    yM = (A*XM**2 + B*XM + C) / (D*XM + E)
    
    # Đạo hàm f'(x) = [ (2ax+b)(dx+e) - d(ax^2+bx+c) ] / (dx+e)^2
    # f'(x) = [ adx^2 + 2aex + (be-cd) ] / (dx+e)^2
    tu_dao_ham_coeffs = [A*D, 2*A*E, B*E - C*D]
    k = (tu_dao_ham_coeffs[0]*XM**2 + tu_dao_ham_coeffs[1]*XM + tu_dao_ham_coeffs[2]) / (D*XM + E)**2
    
    # Phương trình tiếp tuyến y = kx + m
    intercept = yM - k * XM

    # --- 3. ĐỊNH DẠNG ĐA THỨC ---
    def fmt_p(coeffs, vars):
        res = ""
        for i, val in enumerate(coeffs):
            if val == 0: continue
            v = vars[i]
            sign = "+" if val > 0 and res != "" else ""
            if val < 0: sign = "-"
            
            abs_v = abs(val)
            coeff_str = "" if (abs_v == 1 and v != "") else str(abs_v)
            res += f" {sign} {coeff_str}{v}"
        return res.strip()

    f_tu = fmt_p([a, b, c], ["x^2", "x", ""])
    f_mau = fmt_p([d, e], ["x", ""])
    f_x_tex = rf"\dfrac{{{f_tu}}}{{{f_mau}}}"
    
    f_prime_tu_tex = fmt_p([int(c) for c in tu_dao_ham_coeffs], ["x^2", "x", ""])
    f_prime_x_tex = rf"\dfrac{{{f_prime_tu_tex}}}{{({f_mau})^2}}"

    # Phương trình tiếp tuyến
    def fmt_pttt(k_val, m_val):
        k_t = to_latex(k_val)
        if k_val == 1: k_p = "x"
        elif k_val == -1: k_p = "-x"
        elif k_val == 0: k_p = ""
        else: k_p = rf"{k_t}x"
        
        if m_val == 0: return f"y = {k_p}" if k_p != "" else "y = 0"
        m_s = " + " if m_val > 0 else " - "
        return f"y = {k_p}{m_s}{to_latex(abs(m_val))}"

    pt_tt_tex = fmt_pttt(k, intercept)

    # --- 4. KHẲNG ĐỊNH ---
    dung_list = [
        rf"Đạo hàm của hàm số là $f'(x) = {f_prime_x_tex}$",
        rf"Hệ số góc của tiếp tuyến tại $M$ có hoành độ $x_M = {xM_val}$ là $k = {to_latex(k)}$",
        rf"Tọa độ tiếp điểm là $M({xM_val}; {to_latex(yM)})$",
        rf"Phương trình tiếp tuyến tại $M$ là ${pt_tt_tex}$",
        rf"Hàm số không có đạo hàm tại $x = {to_latex(-E/D)}$"
    ]
    
    sai_list = [
        rf"Hệ số góc của tiếp tuyến tại $M$ là $k = f({xM_val})$",
        rf"Đạo hàm của hàm số là $f'(x) = \dfrac{{{fmt_p([2*a, b], ['x', ''])}}}{{{d}}}$", # Sai quy tắc u/v thành u'/v'
        rf"Phương trình tiếp tuyến tại $M$ là $y = {to_latex(k)}x$",
        rf"Tọa độ tiếp điểm là $M({to_latex(yM)}; {xM_val})$",
        rf"Hệ số góc của tiếp tuyến tại $M$ là $k = {to_latex(yM)}$"
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 5. RENDER LỜI GIẢI ---
    yM_join = (" + " + to_latex(yM)) if yM > 0 else (" - " + to_latex(abs(yM))) if yM < 0 else ""

# Sửa lại phần render để tránh lỗi ngoặc nhọn trong LaTeX
    return rf"""\begin{{ex}}
    Cho hàm số $f(x) = {f_x_tex}$ có đồ thị $(C)$. Gọi $M$ là điểm thuộc $(C)$ có hoành độ $x_M = {xM_val}$.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        \begin{{itemize}}
            \item Tập xác định: $D = \mathbb{{R}} \setminus \left\{{ {to_latex(-E/D)} \right\}}$.
            \item Đạo hàm: $f'(x) = \dfrac{{({f_tu})'({f_mau}) - ({f_mau})'({f_tu})}}{{{({f_mau})}^2}} = {f_prime_x_tex}$.
            \item Tại $x_M = {xM_val} \Rightarrow y_M = f({xM_val}) = {to_latex(yM)}$.
            \item Hệ số góc tiếp tuyến: $k = f'({xM_val}) = {to_latex(k)}$.
            \item Phương trình tiếp tuyến: $y = {to_latex(k)}(x - {xM_val}) {yM_join} \Leftrightarrow {pt_tt_tex}$.
        \end{{itemize}}
    }}
\end{{ex}}"""
if __name__ == "__main__":
    print(generate())
