import random
from fractions import Fraction

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    if len(dung) < 4 or len(sai) < 4:
        return "% Lỗi: Danh sách khẳng định quá ngắn"
    
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def to_latex_frac(frac):
    """Chuyển đổi Fraction thành mã LaTeX phân số tối giản."""
    if frac.denominator == 1:
        return str(frac.numerator)
    num, den = frac.numerator, frac.denominator
    if den < 0:
        num, den = -num, -den
    return rf"\dfrac{{{num}}}{{{den}}}"

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    a = random.randint(2, 6)
    b = random.choice([-4, -3, -2, 2, 3, 4, 5])
    x0 = 1 
    
    c_pool = [v for v in [-5, -4, -3, -2, 2, 3, 4, 5] if v != b]
    c = random.choice(c_pool)

    # --- 2. TÍNH TOÁN ĐẠO HÀM & TIẾP TUYẾN ---
    # f'(x) = -a / (x + b)^2
    f_prime_val_tex = rf"-\dfrac{{{a}}}{{(x {b:+})^2}}"
    
    # f'(x0)
    val_f_prime_x0 = Fraction(-a, (x0 + b)**2)
    f_prime_x0_tex = to_latex_frac(val_f_prime_x0)

    # g'(x) = (x^2 + 2cx) / (x + c)^2
    g_prime_num_tex = rf"x^2 {2*c:+}x"
    g_prime_den_tex = rf"(x {c:+})^2"
    
    # g'(x0)
    num_val_g = x0**2 + 2*c*x0
    den_val_g = (x0 + c)**2
    val_g_prime_x0 = Fraction(num_val_g, den_val_g)
    g_prime_x0_tex = to_latex_frac(val_g_prime_x0)

    # --- 3. DANH SÁCH 6 CẶP KHẲNG ĐỊNH ---
    dung_list = [
        rf"$f'(x) = {f_prime_val_tex}, \forall x \neq {-b}$",
        rf"Hệ số góc của tiếp tuyến của đồ thị hàm số $g(x)$ tại điểm có hoành độ $x={x0}$ là $k = {g_prime_x0_tex}$",
        rf"$(g(x))' = \dfrac{{{g_prime_num_tex}}}{{{g_prime_den_tex}}}, \forall x \neq {-c}$",
        rf"Đạo hàm của hàm số $h(x) = f(x) \cdot g(x)$ là $h'(x) = f'(x)g(x) + f(x)g'(x)$",
        rf"Giá trị $f'({x0}) = {f_prime_x0_tex}$",
        rf"Tiếp tuyến của đồ thị hàm số $f(x)$ tại điểm có hoành độ $x=x_0$ có hệ số góc là $f'(x_0)$"
    ]
    
    sai_list = [
        rf"$f'(x) = \dfrac{{{a}}}{{(x {b:+})^2}}, \forall x \neq {-b}$", # Sai dấu
        rf"Hệ số góc của tiếp tuyến của đồ thị hàm số $g(x)$ tại điểm có hoành độ $x={x0}$ là $k = {to_latex_frac(val_g_prime_x0 + 1)}$", # Sai giá trị k
        rf"$(g(x))' = \dfrac{{2x}}{{(x {c:+})^2}}, \forall x \neq {-c}$", # Sai công thức u/v
        rf"$(f(x) \cdot g(x))' = f'(x) \cdot g'(x)$", # Sai quy tắc tích
        rf"Giá trị $f'({x0}) = {to_latex_frac(val_f_prime_x0 * -1)}$", # Sai dấu giá trị
        rf"Tiếp tuyến của đồ thị hàm số $f(x)$ tại điểm có hoành độ $x=x_0$ có hệ số góc là $f(x_0)$" # Nhầm hệ số góc với tung độ
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 4. RENDER MÃ EX ---
    return rf"""\begin{{ex}}
    Cho hai hàm số $f(x) = \dfrac{{{a}}}{{x {b:+}}}$ và $g(x) = \dfrac{{x^2}}{{x {c:+}}}$.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        \textbf{{Phân tích:}}
        \begin{{itemize}}
            \item Đạo hàm hàm số $f(x)$: $f'(x) = \left({a}(x{b:+})^{{-1}}\right)' = -{a}(x{b:+})^{{-2}} = {f_prime_val_tex}$.
            \item Đạo hàm hàm số $g(x)$: $g'(x) = \dfrac{{(x^2)'(x{c:+}) - x^2(x{c:+})'}}{{(x{c:+})^2}} = \dfrac{{2x(x{c:+}) - x^2}}{{(x{c:+})^2}} = \dfrac{{{g_prime_num_tex}}}{{{g_prime_den_tex}}}$.
            \item Hệ số góc tiếp tuyến của đồ thị hàm số tại điểm có hoành độ $x_0$ là $k = y'(x_0)$.
            \item Với $x={x0}$, ta tính được $g'({x0}) = {g_prime_x0_tex}$ và $f'({x0}) = {f_prime_x0_tex}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

if __name__ == "__main__":
    try:
        print(generate())
    except Exception as e:
        print(f"% Lỗi: {e}")
