import random
from fractions import Fraction
import math

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    return (f"\\choiceTF \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def to_latex(frac):
    """Chuyển đổi Fraction sang LaTeX."""
    if frac.denominator == 1:
        return str(frac.numerator)
    return rf"\dfrac{{{frac.numerator}}}{{{frac.denominator}}}"

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    # f(x) = sqrt(ax + b)
    # g(x) = cx + d (đa thức bậc nhất cho nhẹ nhàng)
    while True:
        a = random.randint(1, 4)
        b = random.randint(1, 10)
        c = random.randint(-3, 3)
        if c == 0: c = 2
        d = random.randint(-5, 5)
        
        # Chọn xM sao cho ax + b là số chính phương để căn bậc hai ra số đẹp
        # axM + b = k^2 => xM = (k^2 - b) / a
        k = random.randint(2, 5)
        if (k**2 - b) % a == 0:
            xM = (k**2 - b) // a
            if xM >= -2 and xM <= 5: # Giới hạn xM trong khoảng dễ tính
                break

    # --- 2. TÍNH TOÁN ---
    # f(x) = sqrt(ax + b) => f'(x) = a / (2 * sqrt(ax + b))
    f_xM = k
    f_prime_xM = Fraction(a, 2 * k)
    
    # g(x) = cx + d => g'(x) = c
    g_xM = c * xM + d
    g_prime_xM = Fraction(c)
    
    # Xét hàm tổng h(x) = f(x) + g(x)
    h_xM = Fraction(f_xM + g_xM)
    k_h = f_prime_xM + g_prime_xM # Hệ số góc tiếp tuyến của h(x)
    
    # Xét hàm tích p(x) = f(x) * g(x)
    # p'(x) = f'(x)g(x) + f(x)g'(x)
    k_p = f_prime_xM * g_xM + f_xM * g_prime_xM

    # --- 3. ĐỊNH DẠNG TEXT ---
    f_tex = rf"\sqrt{{{a}x + {b}}}" if b > 0 else (rf"\sqrt{{{a}x - {abs(b)}}}" if b < 0 else rf"\sqrt{{{a}x}}")
    g_tex = rf"{c}x {'+' if d >= 0 else '-'} {abs(d)}"
    
    # --- 4. KHẲNG ĐỊNH ---
    dung_list = [
        rf"Giá trị đạo hàm của hàm số $f(x)$ tại $x = {xM}$ là $f'({xM}) = {to_latex(f_prime_xM)}$",
        rf"Hệ số góc của tiếp tuyến của đồ thị hàm số $h(x) = f(x) + g(x)$ tại $x = {xM}$ là $k = {to_latex(k_h)}$",
        rf"Tọa độ tiếp điểm của đồ thị hàm số $g(x)$ tại $x = {xM}$ là $M({xM}; {g_xM})$",
        rf"Giá trị đạo hàm của hàm số tích $p(x) = f(x) \cdot g(x)$ tại $x = {xM}$ là $p'({xM}) = {to_latex(k_p)}$",
        rf"Đạo hàm của hàm số $f(x)$ là $f'(x) = \dfrac{{{a}}}{{2\sqrt{{{a}x + {b}}}}}$"
    ]
    
    sai_list = [
        rf"Hệ số góc của tiếp tuyến của đồ thị hàm số $h(x) = f(x) + g(x)$ tại $x = {xM}$ là $k = {to_latex(f_prime_xM)}$", # Quên đạo hàm g(x)
        rf"Giá trị đạo hàm của hàm số $f(x)$ tại $x = {xM}$ là $f'({xM}) = {a}$",
        rf"Đạo hàm của hàm số $f(x)$ là $f'(x) = \dfrac{{1}}{{2\sqrt{{{a}x + {b}}}}}$", # Quên nhân u'
        rf"Giá trị đạo hàm của hàm số tích $p(x) = f(x) \cdot g(x)$ tại $x = {xM}$ là $p'({xM}) = f'({xM}) \cdot g'({xM})$", # Sai quy tắc tích
        rf"Tiếp tuyến của đồ thị hàm số $g(x)$ tại $x = {xM}$ có hệ số góc bằng $0$"
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 5. RENDER LỜI GIẢI ---
    return rf"""\begin{{ex}}
    Cho hai hàm số $f(x) = {f_tex}$ và $g(x) = {g_tex}$. Xét các hàm số $h(x) = f(x) + g(x)$ và $p(x) = f(x) \cdot g(x)$.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        \begin{{itemize}}
            \item Đạo hàm của $f(x)$: $f'(x) = \dfrac{{({a}x + {b})'}}{{2\sqrt{{{a}x + {b}}}}} = \dfrac{{{a}}}{{2\sqrt{{{a}x + {b}}}}}$. 
            Tại $x = {xM} \Rightarrow f'({xM}) = {to_latex(f_prime_xM)}$.
            \item Đạo hàm của $g(x)$: $g'(x) = {c}$. 
            Tại $x = {xM} \Rightarrow g'({xM}) = {c}$.
            \item Hệ số góc tiếp tuyến của $h(x) = f(x) + g(x)$ tại $x = {xM}$ là: 
            $k_h = h'({xM}) = f'({xM}) + g'({xM}) = {to_latex(f_prime_xM)} + {c} = {to_latex(k_h)}$.
            \item Đạo hàm của hàm tích $p(x)$ tại $x = {xM}$: 
            $p'({xM}) = f'({xM}) \cdot g({xM}) + f({xM}) \cdot g'({xM}) = {to_latex(f_prime_xM)} \cdot ({g_xM}) + {f_xM} \cdot ({c}) = {to_latex(k_p)}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
