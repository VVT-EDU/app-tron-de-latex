import random
import math
from sympy import symbols, diff, latex, Rational, simplify, sin, cos, pi, N
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    """Hàm làm tròn chuẩn toán học (0.5 lên 1)"""
    try:
        if decimals == 0:
            factor = Decimal('1')
        else:
            factor = Decimal('1.' + '0' * decimals)
        return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))
    except:
        return math.floor(number + 0.5)

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    # Chọn giá trị a để tạo k = Rational(a)
    # k thường là số nguyên nhỏ để biểu thức lượng giác không quá phức tạp
    a = random.choice([1, 2, 4, 5]) 
    k = Rational(a)
    
    # Hàm số f(x) = sin(kx) + cos(3x)
    ham_so = sin(k * x) + cos(3 * x)
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    # (sin(ux))' = u.cos(ux); (cos(vx))' = -v.sin(vx)
    dham = diff(ham_so, x)
    
    # Điểm tính đạo hàm x = k*pi/3
    thay_x = k * pi / 3
    
    # Giá trị chính xác của đạo hàm tại x
    f_prime_val_exact = dham.subs(x, thay_x)
    
    # Tính giá trị thập phân và làm tròn
    f_val_float = float(N(f_prime_val_exact))
    kq_lam_tron = int(round_half_up(f_val_float, 0))
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai_tap = (
        f"Cho hàm số $f(x) = {latex(ham_so)}$. Tính đạo hàm của hàm số tại điểm $x = {latex(thay_x)}$ "
        f"(làm tròn kết quả đến hàng đơn vị)."
    )

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số $f(x) = {latex(ham_so)}$.",
        f"Áp dụng quy tắc đạo hàm hàm lượng giác hợp $(\\sin u)' = u'\\cos u$ và $(\\cos v)' = -v'\\sin v$, ta có:",
        f"$f'(x) = {latex(dham)}$.",
        f"Thay $x = {latex(thay_x)}$ vào biểu thức đạo hàm, ta được:",
        f"$f'({latex(thay_x)}) = {latex(f_prime_val_exact)}$.",
        f"Giá trị xấp xỉ: $f'({latex(thay_x)}) \\approx {f_val_float:.3f}$.",
        f"Làm tròn đến hàng đơn vị, ta được kết quả bằng ${kq_lam_tron}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai_tap}
    \shortans{{ ${kq_lam_tron}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
