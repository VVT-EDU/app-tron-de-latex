import random
import math
from sympy import symbols, diff, latex, Rational, exp, log, N
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    """Hàm làm tròn chuẩn toán học (0.5 lên 1)"""
    try:
        # Chuyển về string để tránh lỗi floating point của Decimal
        d = Decimal(str(number))
        if decimals == 0:
            factor = Decimal('1')
        else:
            factor = Decimal('1.' + '0' * decimals)
        return float(d.quantize(factor, rounding=ROUND_HALF_UP))
    except:
        return int(number + 0.5)

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    a = random.choice([2, 4, 6, 8])
    b = random.choice([3, 5, 7, 9])
    
    # Chọn điểm thay thế (0, 1/2, 1/3)
    thay = random.choice([Rational(1, 2), 0, Rational(1, 3)])
    
    # Hàm số f(x) = e^(x^a) + 2^(bx)
    ham_so = exp(x**a) + 2**(b*x)
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    # (e^u)' = u'.e^u và (a^u)' = u'.a^u.ln(a)
    dham = diff(ham_so, x)
    
    # Giá trị chính xác của đạo hàm tại điểm 'thay'
    f_prime_val_exact = dham.subs(x, thay)
    
    # Tính giá trị thập phân và làm tròn đến hàng đơn vị
    f_val_float = float(N(f_prime_val_exact))
    kq_lam_tron = int(round_half_up(f_val_float, 0))
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai_tap = (
        f"Cho hàm số $f(x) = {latex(ham_so)}$. Tính đạo hàm của hàm số tại điểm $x = {latex(thay)}$ "
        f"(làm tròn kết quả đến hàng đơn vị)."
    )

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số $f(x) = {latex(ham_so)}$.",
        f"Sử dụng quy tắc đạo hàm hàm hợp $(e^u)' = u' e^u$ và $(a^u)' = u' a^u \\ln a$, ta có:",
        f"$f'(x) = {latex(dham)}$.",
        f"Thay $x = {latex(thay)}$ vào biểu thức đạo hàm, ta được:",
        f"$f'({latex(thay)}) = {latex(f_prime_val_exact)}$.",
        f"Giá trị xấp xỉ: $f'({latex(thay)}) \\approx {f_val_float:.3f}$.",
        f"Làm tròn đến hàng đơn vị, ta được kết quả bằng ${kq_lam_tron}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai_tap}
    \shortans{{ ${kq_lam_tron}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
