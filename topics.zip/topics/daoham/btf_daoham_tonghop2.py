import random
from fractions import Fraction

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    return (f"\\choiceTF \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def to_latex(frac):
    """Chuyển đổi Fraction sang LaTeX."""
    if frac.denominator == 1:
        return str(frac.numerator)
    return rf"\dfrac{{{frac.numerator}}}{{{frac.denominator}}}"

def fmt_poly(coeffs, vars):
    """Hàm bổ trợ viết đa thức đẹp."""
    res = ""
    for i, val in enumerate(coeffs):
        if val == 0: continue
        v = vars[i]
        sign = "+" if val > 0 and res != "" else ""
        if val < 0: sign = "-"
        abs_v = abs(val)
        coeff_str = "" if (abs_v == 1 and v != "") else str(abs_v)
        res += f" {sign} {coeff_str}{v}"
    return res.strip()

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    # f(x) = ax^2 + bx + c
    # g(x) = dx + e
    while True:
        a = random.randint(-2, 2)
        if a == 0: a = 1
        b = random.randint(-3, 3)
        c = random.randint(-4, 4)
        
        d = random.choice([-2, -1, 1, 2])
        e = random.randint(-3, 3)
        
        # Chọn x0 sao cho g(x0) != 0 để tính được đạo hàm hàm thương
        x0 = random.randint(-2, 2)
        if d * x0 + e != 0: break

    # Ép kiểu Fraction
    A, B, C, D, E, X0 = Fraction(a), Fraction(b), Fraction(c), Fraction(d), Fraction(e), Fraction(x0)

    # --- 2. TÍNH TOÁN GIÁ TRỊ TẠI X0 ---
    f_x0 = A*X0**2 + B*X0 + C
    f_prime_x0 = 2*A*X0 + B
    
    g_x0 = D*X0 + E
    g_prime_x0 = D

    # 1. Hàm tổng s(x) = f(x) + g(x) => s'(x0)
    k_sum = f_prime_x0 + g_prime_x0
    
    # 2. Hàm tích p(x) = f(x).g(x) => p'(x0) = f'(x0)g(x0) + f(x0)g'(x0)
    k_prod = f_prime_x0 * g_x0 + f_x0 * g_prime_x0
    
    # 3. Hàm thương q(x) = f(x)/g(x) => q'(x0) = [f'(x0)g(x0) - f(x0)g'(x0)] / g(x0)^2
    k_quot = (f_prime_x0 * g_x0 - f_x0 * g_prime_x0) / (g_x0**2)

    # --- 3. ĐỊNH DẠNG TEXT ---
    f_tex = fmt_poly([a, b, c], ["x^2", "x", ""])
    g_tex = fmt_poly([d, e], ["x", ""])
    
    # --- 4. KHẲNG ĐỊNH ---
    dung_list = [
        rf"Giá trị đạo hàm của hàm số $f(x)$ tại $x = {x0}$ là $f'({x0}) = {to_latex(f_prime_x0)}$",
        rf"Hệ số góc của tiếp tuyến của đồ thị hàm số $s(x) = f(x) + g(x)$ tại $x = {x0}$ là $k = {to_latex(k_sum)}$",
        rf"Đạo hàm của hàm số tích $p(x) = f(x) \cdot g(x)$ tại $x = {x0}$ là $p'({x0}) = {to_latex(k_prod)}$",
        rf"Đạo hàm của hàm số thương $q(x) = \dfrac{{f(x)}}{{g(x)}}$ tại $x = {x0}$ là $q'({x0}) = {to_latex(k_quot)}$",
        rf"Hàm số $g(x)$ có đạo hàm không đổi $g'(x) = {d}$ trên $\mathbb{{R}}$"
    ]
    
    sai_list = [
        rf"Đạo hàm của hàm số tích tại $x = {x0}$ là $p'({x0}) = f'({x0}) \cdot g'({x0}) = {to_latex(f_prime_x0 * g_prime_x0)}$",
        rf"Đạo hàm của hàm số thương tại $x = {x0}$ là $q'({x0}) = \dfrac{{f'({x0})}}{{g'({x0})}} = {to_latex(f_prime_x0 / g_prime_x0) if g_prime_x0 != 0 else '0'}$",
        rf"Hệ số góc của tiếp tuyến của đồ thị $f(x)$ tại $x = {x0}$ là $k = {to_latex(f_x0)}$",
        rf"Hàm số $q(x) = \dfrac{{f(x)}}{{g(x)}}$ có tập xác định $D = \mathbb{{R}}$",
        rf"Giá trị đạo hàm của hàm số $f(x)$ tại $x = {x0}$ là $f'({x0}) = {to_latex(2*A*X0)}$" # Quên b
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 5. RENDER ---
    return rf"""\begin{{ex}}
    Cho hai hàm số $f(x) = {f_tex}$ và $g(x) = {g_tex}$. Gọi $s(x) = f(x) + g(x)$, $p(x) = f(x) \cdot g(x)$ và $q(x) = \dfrac{{f(x)}}{{g(x)}}$.
    \textbf{{Xét tính đúng sai của các khẳng định sau tại điểm $x_0 = {x0}$:}}
    {choice_tf}
    \loigiai{{
        \begin{{itemize}}
            \item Ta có: $f'({x0}) = {to_latex(f_prime_x0)}$; $g'({x0}) = {to_latex(g_prime_x0)}$.
            \item Giá trị hàm số tại $x_0 = {x0}$: $f({x0}) = {to_latex(f_x0)}$; $g({x0}) = {to_latex(g_x0)}$.
            \item Đạo hàm hàm tổng: $s'({x0}) = f'({x0}) + g'({x0}) = {to_latex(f_prime_x0)} + ({to_latex(g_prime_x0)}) = {to_latex(k_sum)}$.
            \item Đạo hàm hàm tích: $p'({x0}) = f'({x0})g({x0}) + f({x0})g'({x0}) = ({to_latex(f_prime_x0)})({to_latex(g_x0)}) + ({to_latex(f_x0)})({to_latex(g_prime_x0)}) = {to_latex(k_prod)}$.
            \item Đạo hàm hàm thương: $q'({x0}) = \dfrac{{f'({x0})g({x0}) - f({x0})g'({x0})}}{{[g({x0})]^2}} = \dfrac{{{to_latex(f_prime_x0 * g_x0 - f_x0 * g_prime_x0)}}}{{{to_latex(g_x0**2)}}} = {to_latex(k_quot)}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
