import random
from sympy import symbols, diff, latex, simplify, sin, cos, N
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    """Hàm làm tròn chuẩn toán học (0.5 lên 1)"""
    try:
        d = Decimal(str(float(number)))
        if decimals == 0:
            factor_dec = Decimal('1')
        else:
            factor_dec = Decimal('1.' + '0' * decimals)
        return float(d.quantize(factor_dec, rounding=ROUND_HALF_UP))
    except:
        return int(number + 0.5)

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    h_value = random.randint(1, 4)
    a = h_value + 1
    
    # Định nghĩa hàm y = sin(ax) - cos(ax)
    f = sin(a*x) - cos(a*x)
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    f1 = diff(f, x)        # y' = a*cos(ax) + a*sin(ax)
    f2 = diff(f1, x)       # y'' = -a^2*sin(ax) + a^2*cos(ax)
    
    # Biểu thức m = y'' + a*y'
    # Biến đổi: m = (-a^2*sin + a^2*cos) + (a^2*cos + a^2*sin) = 2*a^2*cos(ax)
    m_expr = simplify(f2 + a * f1)
    
    # Để có số để làm tròn, ta tính giá trị tại x = 0 (hoặc một điểm bất kỳ)
    x0 = 0
    m_at_x0 = m_expr.subs(x, x0)
    
    # Tính giá trị làm tròn
    m_float = float(N(m_at_x0))
    m_rounded = int(round_half_up(m_float, 0))
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai = (
        f"Cho hàm số $y = {latex(f)}$. Biết rằng tại $x = {x0}$, "
        f"biểu thức $y'' + {a} \\cdot y' = m$. "
        f"Tính giá trị của $m$ (làm tròn kết quả đến hàng đơn vị)."
    )

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số: $y = {latex(f)}$.",
        f"Đạo hàm bậc nhất: $y' = ({latex(f)})' = {latex(f1)}$.",
        f"Đạo hàm bậc hai: $y'' = ({latex(f1)})' = {latex(f2)}$.",
        f"Suy ra biểu thức $y'' + {a}y' = {latex(f2)} + {a}({latex(f1)})$.",
        f"Rút gọn ta được: $y'' + {a}y' = {latex(m_expr)}$.",
        f"Tại $x = {x0}$, ta có: $m = {latex(m_expr.subs(x, x0))} = {m_at_x0}$.",
        f"Làm tròn đến hàng đơn vị, ta được kết quả $m = {m_rounded}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai}
    \shortans{{ ${m_rounded}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
