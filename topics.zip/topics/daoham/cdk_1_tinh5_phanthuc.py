import random
from sympy import symbols, diff, latex, Rational, simplify, apart

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    # Chọn giá trị a ngẫu nhiên để tạo k = Rational(a)
    a = random.choice([1, 2, 3, 4, 5])
    k = Rational(a)
    
    # Hàm số f(x) = (x^2 - kx + 3) / (x + 1)
    ham_goc = (x**2 - k*x + 3) / (x + 1)
    
    # Sử dụng apart() để phân tích hàm số: f(x) = đa thức + phân thức đơn giản
    ham_apart = apart(ham_goc)
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    dham = diff(ham_apart, x)
    
    # Tính giá trị đạo hàm tại x = k
    thay_x = k
    f_prime_k = dham.subs(x, thay_x)
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai_tap = f"Cho hàm số $f(x) = {latex(ham_goc)}$. Tính đạo hàm của hàm số tại điểm $x = {latex(k)}$."

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số: $f(x) = {latex(ham_goc)}$.",
        f"Thực hiện phép chia đa thức hoặc sử dụng phân tích `apart`, ta viết lại hàm số dưới dạng:",
        f"$f(x) = {latex(ham_apart)}$.",
        f"Đạo hàm của hàm số là: $f'(x) = {latex(dham)}$.",
        f"Thay $x = {latex(thay_x)}$ vào biểu thức đạo hàm, ta được:",
        f"$f'({latex(thay_x)}) = {latex(f_prime_k)}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai_tap}
    \shortans{{ ${latex(f_prime_k)}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
