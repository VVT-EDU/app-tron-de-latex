import random
import math
from sympy import symbols, diff, latex, Rational, simplify, sqrt, N
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    """Hàm làm tròn chuẩn toán học (0.5 lên 1)"""
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    # Chọn giá trị a để tạo k = Rational(a)
    a = random.choice([1, 2, 3, 5, 6, 7])
    k = Rational(a)
    
    # Hàm số f(x) = sqrt(1 + k*x^2)
    ham_so = sqrt(1 + k * x**2)
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    dham = diff(ham_so, x)
    dham = simplify(dham) # Rút gọn biểu thức đạo hàm: kx / sqrt(1 + kx^2)
    
    # Tính giá trị đạo hàm tại x = k (giá trị chính xác)
    thay_x = k
    f_prime_k_exact = dham.subs(x, thay_x)
    
    # Tính giá trị thập phân và làm tròn đến hàng đơn vị
    # N(expression) chuyển biểu thức SymPy thành số thực
    f_val_float = float(N(f_prime_k_exact))
    kq_lam_tron = int(round_half_up(f_val_float, 0))
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai_tap = (
        f"Cho hàm số $f(x) = {latex(ham_so)}$. Tính đạo hàm của hàm số tại điểm $x = {latex(k)}$ "
        f"(làm tròn kết quả đến hàng đơn vị)."
    )

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số $f(x) = {latex(ham_so)}$.",
        f"Đạo hàm của hàm số là: $f'(x) = \\dfrac{{({latex(1 + k * x**2)})'}}{{2\\sqrt{{{latex(1 + k * x**2)}}}}} = {latex(dham)}$.",
        f"Thay $x = {latex(thay_x)}$ vào biểu thức $f'(x)$, ta được:",
        f"$f'({latex(thay_x)}) = {latex(f_prime_k_exact)}$.",
        f"Tính toán giá trị xấp xỉ: $f'({latex(thay_x)}) \\approx {f_val_float:.3f}$.",
        f"Làm tròn đến hàng đơn vị, ta được kết quả bằng ${kq_lam_tron}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai_tap}
    \shortans{{ ${kq_lam_tron}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
