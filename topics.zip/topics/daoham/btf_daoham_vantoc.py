import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định."""
    all_indices = random.sample(range(len(dung)), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    # s(t) = a*t^3 + b*t^2 + c*t + d
    a = 1
    # Chọn t_min (thời điểm vận tốc đạt cực tiểu) là số nguyên dương
    t_min = random.randint(2, 4)
    # Vận tốc cực tiểu v_min
    v_min = random.randint(5, 10)
    
    # Từ v(t) = 3at^2 + 2bt + c. Đỉnh parabol tại t = -2b/6a = t_min => b = -3 * a * t_min
    b = -3 * a * t_min
    # Tại t_min, v = v_min => 3*a*(t_min^2) + 2*b*t_min + c = v_min
    c = v_min - (3 * a * (t_min**2) + 2 * b * t_min)
    d = random.randint(1, 10)
    
    t_check = random.randint(5, 7) # Thời điểm kiểm tra quãng đường
    s_check = a*(t_check**3) + b*(t_check**2) + c*t_check + d
    
    # --- 2. DANH SÁCH KHẲNG ĐỊNH ---
    # v(t) = 3t^2 + 2bt + c
    # a(t) = 6t + 2b
    dung_list = [
        rf"Quãng đường vật đi được sau ${t_check}$ giây kể từ khi bắt đầu chuyển động là ${s_check}$ (m).",
        rf"Vận tốc tức thời của vật là $v(t) = 3t^2 {b*2:+}t {c:+}$ (m/s).",
        rf"Gia tốc tức thời của vật là $a(t) = 6t {b*2:+}$ (m/s$^2$).",
        rf"Vận tốc nhỏ nhất vật đạt được trong $10$ giây đầu tiên là ${v_min}$ (m/s).",
        rf"Gia tốc của vật tại thời điểm $t={t_min}$ là $0$ (m/s$^2$).",
        rf"Tại thời điểm $t=1$ (s), vận tốc của vật đang giảm (do $a(1) < 0$)."
    ]
    
    sai_list = [
        rf"Quãng đường vật đi được sau ${t_check}$ giây kể từ khi bắt đầu chuyển động là ${s_check + random.randint(5,15)}$ (m).",
        rf"Vận tốc tức thời của vật là $v(t) = 3t^2 {b*2:+}t$ (m/s).", # Thiếu hệ số tự do
        rf"Gia tốc tức thời của vật là $a(t) = 3t {b:+}$ (m/s$^2$).", # Sai đạo hàm
        rf"Vận tốc nhỏ nhất vật đạt được trong $10$ giây đầu tiên là ${v_min - 2}$ (m/s).",
        rf"Quãng đường vật đi được sau $1$ giây là ${a+b+c}$ (m).", # Thiếu d
        rf"Vận tốc của vật luôn tăng trên khoảng $(0; 10)$."
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 3. ĐỊNH DẠNG PHƯƠNG TRÌNH ---
    s_tex = rf"t^3 {b:+}t^2 {c:+}t {d:+}"

    return rf"""\begin{{ex}}
    Một vật chuyển động thẳng không đều xác định bởi phương trình $s(t) = {s_tex}$, trong đó $s(t)$ là quãng đường (m) và $t$ là thời gian (s), $t \geq 0$.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        \begin{{itemize}}
            \item Ta có $v(t) = s'(t) = 3t^2 {b*2:+}t {c:+}$.
            \item Gia tốc $a(t) = v'(t) = 6t {b*2:+}$.
            \item Xét $v(t) = 3(t^2 {b*2//3:+}t) {c:+} = 3(t - {t_min})^2 + {v_min} \geq {v_min}$.
            \item Dấu "=" xảy ra khi $t = {t_min}$ (s).
            \item Quãng đường sau ${t_check}$ giây: $s({t_check}) = {t_check}^3 {b:+}({t_check}^2) {c:+}({t_check}) {d:+} = {s_check}$ (m).
        \end{{itemize}}
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
