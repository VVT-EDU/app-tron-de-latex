import random
from sympy import symbols, diff, latex, simplify, sin, cos, N
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    """Hàm làm tròn chuẩn toán học (0.5 lên 1)"""
    try:
        d = Decimal(str(float(number)))
        if decimals == 0:
            factor_dec = Decimal('1')
        else:
            factor_dec = Decimal('1.' + '0' * decimals)
        return float(d.quantize(factor_dec, rounding=ROUND_HALF_UP))
    except:
        return int(number + 0.5)

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    h_value = random.randint(1, 4)
    a = h_value + 1
    heso = a**2 # Hệ số a^2 trong biểu thức y'' + a^2*y
    
    # Định nghĩa hàm y = x * sin(a*x)
    f = x * sin(a * x)
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    # Sử dụng quy tắc (u.v)' = u'v + uv'
    f1 = diff(f, x)      # y' = sin(ax) + ax*cos(ax)
    f2 = diff(f1, x)     # y'' = 2a*cos(ax) - a^2*x*sin(ax)
    
    # Biểu thức m = y'' + a^2 * y
    # m = (2a*cos(ax) - a^2*x*sin(ax)) + a^2*(x*sin(ax)) = 2a*cos(ax)
    m_expr = simplify(f2 + heso * f)
    
    # Tính giá trị tại x = 0 để làm tròn
    x0 = 0
    m_at_x0 = m_expr.subs(x, x0)
    m_float = float(N(m_at_x0))
    m_rounded = int(round_half_up(m_float, 0))
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai = (
        f"Cho hàm số $y = {latex(f)}$. Biết rằng tại $x = {x0}$, "
        f"biểu thức $y'' + {heso}y = m$. "
        f"Tính giá trị của $m$ (làm tròn kết quả đến hàng đơn vị)."
    )

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số: $y = {latex(f)}$.",
        f"Đạo hàm bậc nhất (quy tắc tích): $y' = (x)'\\sin({a}x) + x(\\sin({a}x))' = {latex(f1)}$.",
        f"Đạo hàm bậc hai: $y'' = ({latex(f1)})' = {latex(f2)}$.",
        f"Tính biểu thức liên hệ: $y'' + {heso}y = ({latex(f2)}) + {heso}({latex(f)}) = {latex(m_expr)}$.",
        f"Tại $x = {x0}$, ta có $m = {latex(m_expr.subs(x, x0))} = {m_at_x0}$.",
        f"Làm tròn đến hàng đơn vị, ta được kết quả $m = {m_rounded}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai}
    \shortans{{ ${m_rounded}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
