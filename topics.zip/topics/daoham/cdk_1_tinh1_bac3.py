import random
from sympy import symbols, diff, latex, Rational

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    a = random.choice([1, 2, 3, 5, 7, 9])
    b = random.choice([2, 4, 6, 8])
    c = random.choice([1, 2, 3, 5, 7, 9])
    
    # Hàm số f(x) = (1/3)x^3 + ax^2 + bx - c
    # Sử dụng Rational(1, 3) để SymPy hiểu là phân số 1/3 thay vì số thập phân 0.333
    ham_so = Rational(1, 3) * x**3 + a * x**2 + b * x - c
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    dham = diff(ham_so, x)
    
    # Tính giá trị đạo hàm tại x = c
    thay_x = c
    f_prime_c = dham.subs(x, thay_x)
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    # Định dạng đề bài theo phong cách bài tập đạo hàm tại điểm
    bai_tap = f"Cho hàm số $f(x) = {latex(ham_so)}$. Tính đạo hàm của hàm số tại điểm $x = {thay_x}$."

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số $f(x) = {latex(ham_so)}$.",
        f"Áp dụng quy tắc tính đạo hàm của hàm đa thức, ta được:",
        f"$f'(x) = ({latex(ham_so)})' = {latex(dham)}$.",
        f"Thay $x = {thay_x}$ vào biểu thức đạo hàm, ta có:",
        f"$f'({thay_x}) = {thay_x}^2 + 2 \\cdot {a} \\cdot {thay_x} + {b} = {f_prime_c}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai_tap}
    \shortans{{ ${f_prime_c}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
