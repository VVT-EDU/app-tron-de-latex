import random
from sympy import symbols, diff, latex, log, Rational, N
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    try:
        d = Decimal(str(number))
        if decimals == 0:
            factor = Decimal('1')
        else:
            factor = Decimal('1.' + '0' * decimals)
        return float(d.quantize(factor, rounding=ROUND_HALF_UP))
    except:
        return int(number + 0.5)

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    # f(x) = log_a(x^2 + bx + c)
    a_base = random.choice([2, 3, 5])
    b = random.choice([1, 2, 3])
    c = random.choice([4, 5, 6])
    thay = random.choice([1, 2])
    
    # Hàm số f(x) = log(x^2 + bx + c, a_base)
    # Trong SymPy: log(u, base)
    ham_so = log(x**2 + b*x + c, a_base)
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    # Công thức: (log_a(u))' = u' / (u * ln(a))
    dham = diff(ham_so, x)
    
    # Giá trị chính xác tại điểm thay
    f_prime_val_exact = dham.subs(x, thay)
    
    # Tính giá trị thực và làm tròn
    f_val_float = float(N(f_prime_val_exact))
    kq_lam_tron = int(round_half_up(f_val_float, 0))
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai_tap = (
        f"Cho hàm số $f(x) = {latex(ham_so)}$. Tính đạo hàm của hàm số tại điểm $x = {thay}$ "
        f"(làm tròn kết quả đến hàng đơn vị)."
    )

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số $f(x) = {latex(ham_so)}$.",
        f"Áp dụng quy tắc đạo hàm hàm hợp $(\\log_a u)' = \\dfrac{{u'}}{{u \\ln a}}$, ta có:",
        f"$f'(x) = {latex(dham)}$.",
        f"Thay $x = {thay}$ vào biểu thức đạo hàm, ta được:",
        f"$f'({thay}) = {latex(f_prime_val_exact)}$.",
        f"Giá trị xấp xỉ: $f'({thay}) \\approx {f_val_float:.3f}$.",
        f"Làm tròn đến hàng đơn vị, ta có kết quả bằng ${kq_lam_tron}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai_tap}
    \shortans{{ ${kq_lam_tron}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
