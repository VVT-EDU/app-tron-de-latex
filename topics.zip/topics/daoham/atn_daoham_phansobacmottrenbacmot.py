import random

def to_latex_linear(a, b, var='x'):
    """Hiển thị biểu thức ax + b dạng LaTeX đẹp."""
    if a == 0:
        return f"{b}"
    if a == 1:
        ax = var
    elif a == -1:
        ax = f"-{var}"
    else:
        ax = f"{a}{var}"
    if b == 0:
        return ax
    return f"{ax} + {b}" if b > 0 else f"{ax} - {abs(b)}"

def nhanvao_dsdungsai_rachoice_motdung(dung, sai):
    r"""Trộn 1 đúng, 3 sai theo định dạng \choice."""
    if len(dung) < 1 or len(sai) < 3:
        return "\\choice {Lỗi} {Lỗi} {Lỗi} {Lỗi}"
    
    selected_dung = dung[0]
    selected_sai = random.sample(list(set(sai)), 3)
    
    choices = [r'\True ' + selected_dung] + selected_sai
    random.shuffle(choices)
    
    return (f"\\choice \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def generate():
    # --- 1. THIẾT KẾ HÀM SỐ y = (ax + b) / (cx + d) ---
    while True:
        a = random.randint(-5, 5)
        b = random.randint(-9, 9)
        c = random.choice([-3, -2, -1, 1, 2, 3])
        d = random.randint(-9, 9)
        det = a * d - b * c
        
        # Chọn x0 ngẫu nhiên từ -3 đến 5
        x0 = random.randint(-3, 5)
        
        # Điều kiện: ad-bc != 0, a != 0 và mẫu số tại x0 khác 0
        if det != 0 and a != 0 and (c * x0 + d) != 0:
            break

    # --- 2. TÍNH TOÁN ĐẠO HÀM TẠI x0 ---
    # f'(x0) = (ad - bc) / (c*x0 + d)^2
    mau_so_tai_x0 = (c * x0 + d)**2
    
    # Rút gọn phân số f'(x0) = det / mau_so_tai_x0 (nếu cần)
    from fractions import Fraction
    res_frac = Fraction(det, mau_so_tai_x0)
    
    def format_frac(f):
        if f.denominator == 1: return f"{f.numerator}"
        return rf"\dfrac{{{f.numerator}}}{{{f.denominator}}}"

    correct_val = f"${format_frac(res_frac)}$"
    
    # --- 3. TẠO CÁC PHƯƠNG ÁN NHIỄU ---
    dssai = []
    # Nhiễu 1: Sai dấu tử số
    dssai.append(f"${format_frac(-res_frac)}$")
    # Nhiễu 2: Quên bình phương mẫu khi tính
    if (c * x0 + d) != 0:
        dssai.append(f"${format_frac(Fraction(det, abs(c * x0 + d)))}$")
    # Nhiễu 3: Tính nhầm tử số thành ad + bc
    dssai.append(f"${format_frac(Fraction(a*d + b*c, mau_so_tai_x0))}$")
    # Nhiễu 4: Các số nguyên ngẫu nhiên
    dssai.extend([f"${random.randint(-5, 5)}$", f"${random.randint(6, 10)}$"])

    # Lọc trùng
    dssai = [s for s in dssai if s != correct_val]
    
    # --- 4. RÁP LATEX ---
    toan = nhanvao_dsdungsai_rachoice_motdung([correct_val], dssai)
    ham_so_tex = rf"\dfrac{{{to_latex_linear(a, b)}}}{{{to_latex_linear(c, d)}}}"

    return rf"""\begin{{ex}}
Cho hàm số $y = {ham_so_tex}$.  
  Đạo hàm của hàm số tại điểm $x_0 = {x0}$ bằng
{toan}
\loigiai{{
Ta có đạo hàm tổng quát: $y' = \dfrac{{ad-bc}}{{(cx+d)^2}} = \dfrac{{{det}}}{{({to_latex_linear(c, d)})^2}}$.
Thay $x_0 = {x0}$ vào biểu thức $y'$, ta được:
$y'({x0}) = \dfrac{{{det}}}{{({c} \cdot {x0} + ({d}))^2}} = \dfrac{{{det}}}{{{mau_so_tai_x0}}} = {correct_val.replace('$', '')}$.
}}
\end{{ex}}"""

print(generate())
