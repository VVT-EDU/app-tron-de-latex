import random
from sympy import symbols, diff, latex, apart, Rational

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    k = random.choice([1, 2, 3])
    
    # Hàm số f(x) = -k / (k + x)
    ham_goc = (-k) / (k + x)
    
    # Phân tích hàm số (apart)
    ham_apart = apart(ham_goc)
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    dham = diff(ham_apart, x)
    
    # Tính giá trị đạo hàm tại x = k
    thay_x = k
    f_prime_k = dham.subs(x, thay_x)
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai_tap = f"Cho hàm số $f(x) = {latex(ham_apart)}$. Tính đạo hàm của hàm số tại điểm $x = {thay_x}$."

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số $f(x) = {latex(ham_apart)}$.",
        r"Sử dụng quy tắc đạo hàm của hàm hợp hoặc công thức $(\\frac{1}{u})' = -\\frac{u'}{u^2}$, ta có:",
        f"$f'(x) = {latex(dham)}$.",
        f"Thay $x = {thay_x}$ vào biểu thức $f'(x)$, ta được:",
        f"$f'({thay_x}) = {latex(f_prime_k)}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai_tap}
    \shortans{{ ${latex(f_prime_k)}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
