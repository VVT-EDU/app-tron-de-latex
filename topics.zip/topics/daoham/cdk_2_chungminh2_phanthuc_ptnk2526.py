import random
from sympy import symbols, diff, latex, simplify, Eq, solve, factor, N
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    """Hàm làm tròn chuẩn toán học"""
    try:
        d = Decimal(str(float(number)))
        if decimals == 0:
            factor_dec = Decimal('1')
        else:
            factor_dec = Decimal('1.' + '0' * decimals)
        return float(d.quantize(factor_dec, rounding=ROUND_HALF_UP))
    except:
        return int(number + 0.5)

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    t = symbols('t') # Biến phụ để giải tìm m
    a_val = random.randint(2, 8)
    
    # Định nghĩa hàm y = (x - a) / (x + a)
    tu = x - a_val
    mau = x + a_val
    f = tu / mau
    
    # 2. TÍNH TOÁN ĐẠO HÀM VÀ CÁC BIỂU THỨC LIÊN QUAN
    f1 = simplify(diff(f, x)) # y'
    f2 = simplify(diff(f1, x)) # y''
    
    ytru1 = simplify(f - 1)
    ytru1binh = simplify(ytru1**2)
    
    # Tìm m thỏa mãn m * y' = (y - 1)^2
    # Eq(t * f1, ytru1binh) => t chính là m
    sol_m = solve(Eq(t * f1, ytru1binh), t)
    m_value = sol_m[0]
    
    # Tính toán thêm hệ số k liên hệ y'' (phần mở rộng trong code của bạn)
    k_sym = symbols('k_sym')
    yf2 = simplify(f * f2)
    f1binh = simplify(f1**2)
    sol_k = solve(Eq(f1binh * k_sym, yf2), k_sym)
    k_expr = factor(sol_k[0])
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    # Yêu cầu tìm m để m.y' = (y-1)^2
    bai_tap = (
        f"Cho hàm số $y = {latex(f)}$. Biết rằng giữa hàm số và đạo hàm của nó có mối liên hệ "
        f"$m \\cdot y' = (y - 1)^2$. Khi đó, giá trị của $m$ bằng bao nhiêu?"
    )

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số: $y = {latex(f)}$.",
        f"Đạo hàm bậc nhất: $y' = {latex(f1)}$.",
        f"Ta có $y - 1 = {latex(f)} - 1 = {latex(ytru1)}$.",
        f"Suy ra $(y - 1)^2 = {latex(ytru1binh)}$.",
        f"Thay vào biểu thức $m \\cdot y' = (y - 1)^2$, ta được:",
        f"$m \\cdot {latex(f1)} = {latex(ytru1binh)}$.",
        f"Giải phương trình trên, ta tìm được $m = {latex(m_value)}$."
    ]
    
    # Nếu muốn bổ sung phần đạo hàm cấp 2 vào lời giải cho đầy đủ
    y_list_extra = [
        f"Mở rộng thêm về đạo hàm cấp hai: $y'' = {latex(f2)}$.",
        f"Mối liên hệ với tích $y \\cdot y''$ là: $y \\cdot y'' = {latex(k_expr)} \\cdot (y')^2$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
    {bai_tap}
    \shortans{{ ${latex(m_value)}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
