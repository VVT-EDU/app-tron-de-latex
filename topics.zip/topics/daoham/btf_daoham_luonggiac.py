import random
import math
from fractions import Fraction

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    return (f"\\choiceTF \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    # f(x) = a*sin(x) + b*cos(x) + c
    a = random.randint(-4, 4)
    if a == 0: a = 2
    b = random.randint(-4, 4)
    c = random.randint(-5, 5)
    
    # Chọn điểm x0 đẹp để giá trị sin, cos là số nguyên (0, pi/2, pi, 3pi/2)
    x0_options = [
        (0, "0", 0, 1), 
        (math.pi/2, r"\frac{\pi}{2}", 1, 0), 
        (math.pi, r"\pi", 0, -1)
    ]
    x0_val, x0_tex, sin_x0, cos_x0 = random.choice(x0_options)

    # --- 2. TÍNH TOÁN ---
    # f(x) = a*sin(x) + b*cos(x) + c
    y0 = a * sin_x0 + b * cos_x0 + c
    
    # f'(x) = a*cos(x) - b*sin(x)
    k = a * cos_x0 - b * sin_x0
    
    # Đạo hàm cấp 2 (để hỏi thêm nếu cần): f''(x) = -a*sin(x) - b*cos(x)
    f_double_prime_x0 = -a * sin_x0 - b * cos_x0

    # --- 3. ĐỊNH DẠNG TEXT ---
    def fmt_lg(val, func, is_first=False):
        if val == 0: return ""
        sign = "" if is_first else (" + " if val > 0 else " - ")
        if is_first and val < 0: sign = "-"
        
        abs_v = abs(val)
        coeff = "" if abs_v == 1 else str(abs_v)
        return f"{sign}{coeff}{func}"

    f_parts = [fmt_lg(a, r"\sin x", True), fmt_lg(b, r"\cos x"), (f" + {c}" if c > 0 else f" - {abs(c)}" if c < 0 else "")]
    f_tex = "".join(f_parts).strip()
    if f_tex.startswith("+ "): f_tex = f_tex[2:]

    # f'(x) = a*cos(x) - b*sin(x)
    f_prime_parts = [fmt_lg(a, r"\cos x", True), fmt_lg(-b, r"\sin x")]
    f_prime_tex = "".join(f_prime_parts).strip()
    if f_prime_tex.startswith("+ "): f_prime_tex = f_prime_tex[2:]

    # --- 4. KHẲNG ĐỊNH ---
    dung_list = [
        rf"Đạo hàm của hàm số đã cho là $f'(x) = {f_prime_tex}$",
        rf"Giá trị đạo hàm tại $x = {x0_tex}$ là $f'({x0_tex}) = {k}$",
        rf"Hệ số góc của tiếp tuyến của đồ thị hàm số tại điểm có hoành độ $x_0 = {x0_tex}$ là $k = {k}$",
        rf"Tọa độ tiếp điểm của đồ thị hàm số tại $x_0 = {x0_tex}$ là $M({x0_tex}; {y0})$",
        rf"Giá trị $f(0) + f'(0) = { (a*0 + b*1 + c) + (a*1 - b*0) }$"
    ]
    
    sai_list = [
        rf"Đạo hàm của hàm số đã cho là $f'(x) = {a}\sin x + {b}\cos x$", # Quên đổi sin->cos, cos->-sin
        rf"Đạo hàm của hàm số đã cho là $f'(x) = {a}\cos x + {b}\sin x$", # Sai dấu đạo hàm cos
        rf"Hệ số góc của tiếp tuyến tại $x_0 = {x0_tex}$ là $k = {y0}$", # Nhầm k với y0
        rf"Giá trị đạo hàm tại $x = {x0_tex}$ là $f'({x0_tex}) = {f_double_prime_x0}$", # Nhầm sang đạo hàm cấp 2
        rf"Phương trình tiếp tuyến tại $x_0 = {x0_tex}$ là $y = {k}x$" # Thiếu hệ số tự do
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 5. RENDER ---
    return rf"""\begin{{ex}}
    Cho hàm số $f(x) = {f_tex}$. Gọi $(C)$ là đồ thị của hàm số.
    \textbf{{Xét tính đúng sai của các khẳng định sau tại điểm $x_0 = {x0_tex}$:}}
    {choice_tf}
    \loigiai{{
        \begin{{itemize}}
            \item Sử dụng quy tắc đạo hàm: $(\sin x)' = \cos x$ và $(\cos x)' = -\sin x$.
            \item Ta có: $f'(x) = ({f_tex})' = {f_prime_tex}$.
            \item Thay $x_0 = {x0_tex}$ vào hàm số: $f({x0_tex}) = {y0} \Rightarrow$ Tiếp điểm $M({x0_tex}; {y0})$.
            \item Thay $x_0 = {x0_tex}$ vào đạo hàm: $k = f'({x0_tex}) = {k}$.
            \item Vậy hệ số góc của tiếp tuyến tại $M$ là $k = {k}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
