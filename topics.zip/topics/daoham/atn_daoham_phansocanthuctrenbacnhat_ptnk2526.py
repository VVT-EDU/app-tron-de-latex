import random
from fractions import Fraction
import math

def to_latex_linear(a, b, var='x'):
    """Hiển thị biểu thức ax + b dạng LaTeX đẹp."""
    if a == 0: return f"{b}"
    if a == 1: ax = var
    elif a == -1: ax = f"-{var}"
    else: ax = f"{a}{var}"
    if b == 0: return ax
    return f"{ax} + {b}" if b > 0 else f"{ax} - {abs(b)}"

def nhanvao_dsdungsai_rachoice_motdung(dung, sai):
    """Trộn 1 đúng, 3 sai theo định dạng \\choice."""
    selected_dung = dung[0]
    clean_sai = list(set([s for s in sai if s != selected_dung]))
    selected_sai = random.sample(clean_sai, 3)
    choices = [r'\True ' + selected_dung] + selected_sai
    random.shuffle(choices)
    return (f"\\choice \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def generate():
    # --- 1. THIẾT KẾ HÀM SỐ y = sqrt(x) / (ax + b) ---
    while True:
        a = random.choice([-3, -2, -1, 1, 2, 3])
        b = random.randint(-5, 5)
        # Chọn x0 là số chính phương để sqrt(x0) là số nguyên
        sqrt_x0 = random.randint(1, 4) 
        x0 = sqrt_x0**2
        
        mau_so_tai_x0 = a * x0 + b
        # Đảm bảo mẫu số khác 0
        if mau_so_tai_x0 != 0:
            break

    # --- 2. TÍNH TOÁN ĐẠO HÀM ---
    # y' = [ (1/(2*sqrt(x)))*(ax+b) - sqrt(x)*a ] / (ax+b)^2
    # y' = (ax + b - 2ax) / [ 2*sqrt(x)*(ax+b)^2 ]
    # y' = (b - ax) / [ 2*sqrt(x)*(ax+b)^2 ]
    
    tu_so_dao_ham = b - a * x0
    mau_so_dao_ham = 2 * sqrt_x0 * (mau_so_tai_x0**2)
    
    res_frac = Fraction(tu_so_dao_ham, mau_so_dao_ham)
    
    def format_frac(f):
        if f.denominator == 1: return f"{f.numerator}"
        return rf"\dfrac{{{f.numerator}}}{{{f.denominator}}}"

    correct_val = f"${format_frac(res_frac)}$"

    # --- 3. TẠO CÁC PHƯƠNG ÁN NHIỄU ---
    dssai = []
    dssai.append(f"${format_frac(-res_frac)}$") # Sai dấu
    # Lỗi: Quên số 2 ở mẫu của đạo hàm sqrt(x)
    dssai.append(f"${format_frac(Fraction(tu_so_dao_ham, sqrt_x0 * (mau_so_tai_x0**2)))}$")
    # Lỗi: Nhầm công thức đạo hàm tích (b + ax)
    dssai.append(f"${format_frac(Fraction(b + a * x0, mau_so_dao_ham))}$")
    
    while len(set(dssai)) < 5:
        dssai.append(f"${random.randint(-5, 5)}$")

    # --- 4. RÁP LATEX ---
    toan = nhanvao_dsdungsai_rachoice_motdung([correct_val], dssai)
    mau_tex =罩 = to_latex_linear(a, b)

    return rf"""\begin{{ex}}
Cho hàm số $y = \dfrac{{\sqrt{{x}}}}{{{mau_tex}}}$. Đạo hàm của hàm số tại điểm $x_0 = {x0}$ bằng
{toan}
\loigiai{{
Ta có $y' = \left( \dfrac{{\sqrt{{x}}}}{{{mau_tex}}} \right)' = \dfrac{{(\sqrt{{x}})'({mau_tex}) - \sqrt{{x}}({mau_tex})'}}{{({mau_tex})^2}}$
$= \dfrac{{\dfrac{{1}}{{2\sqrt{{x}}}}({mau_tex}) - a\sqrt{{x}}}}{{({mau_tex})^2}} = \dfrac{{{b} - {a}x}}{{2\sqrt{{x}}({mau_tex})^2}}$.
Thay $x_0 = {x0}$ vào ta được:
$y'({x0}) = \dfrac{{{b} - {a} \cdot {x0}}}{{2\sqrt{{{x0}}}({a} \cdot {x0} + {b})^2}} = \dfrac{{{tu_so_dao_ham}}}{{{mau_so_dao_ham}}} = {correct_val.replace('$', '')}$.
}}
\end{{ex}}"""

print(generate())
