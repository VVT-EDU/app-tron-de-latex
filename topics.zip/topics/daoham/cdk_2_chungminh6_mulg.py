import random
from sympy import symbols, diff, latex, simplify, exp, sin, cos, pi, N, expand, Rational
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    """Hàm làm tròn chuẩn toán học (0.5 lên 1)"""
    try:
        d = Decimal(str(float(number)))
        if decimals == 0:
            factor_dec = Decimal('1')
        else:
            factor_dec = Decimal('1.' + '0' * decimals)
        return float(d.quantize(factor_dec, rounding=ROUND_HALF_UP))
    except:
        return int(number + 0.5)

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    a_val = random.choice([20, 40, 60, 80])
    # Sử dụng Rational để biểu thức luôn ở dạng phân số tối giản
    he_so_f = Rational(1, a_val) 
    
    # Điểm thay thế (k*pi)
    thay = random.choice([pi, 2*pi, 3*pi])
    
    # 2. ĐỊNH NGHĨA HÀM SỐ
    # y = (1/a) * e^x * (cos x - sin x)
    f = he_so_f * exp(x) * (cos(x) - sin(x))
    
    # 3. TÍNH TOÁN ĐẠO HÀM
    f1 = diff(f, x)        
    rgf1 = expand(f1)      # y' = (-2/a) * e^x * sin x
    
    f2 = diff(f1, x)       
    rgf2 = expand(f2)      # y'' = (-2/a) * e^x * (sin x + cos x)
    
    # Biểu thức cần tính: m = y'' - y'
    m_expr = simplify(f2 - f1)
    
    # 4. TÍNH GIÁ TRỊ VÀ LÀM TRÒN
    m_at_thay = m_expr.subs(x, thay)
    m_float = float(N(m_at_thay))
    m_rounded = int(round_half_up(m_float, 0))
    
    # 5. TRÌNH BÀY ĐỀ BÀI
    bai = (
        f"Cho hàm số $y = {latex(f)}$. Biết rằng tại $x = {latex(thay)}$, "
        f"biểu thức $y'' - y' = m$. "
        f"Tính giá trị của $m$ (làm tròn kết quả đến hàng đơn vị)."
    )

    # 6. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số: $y = {latex(f)}$.",
        f"Đạo hàm bậc nhất: $y' = {latex(rgf1)}$.",
        f"Đạo hàm bậc hai: $y'' = {latex(rgf2)}$.",
        f"Thiết lập biểu thức: $y'' - y' = ({latex(rgf2)}) - ({latex(rgf1)})$.",
        f"Rút gọn biểu thức liên hệ: $y'' - y' = {latex(m_expr)}$.",
        f"Thay $x = {latex(thay)}$ vào biểu thức trên ta được:",
        f"$m = {latex(m_at_thay)}$.",
        f"Giá trị thập phân: $m \\approx {m_float:.3f}$.",
        f"Làm tròn đến hàng đơn vị: $m = {m_rounded}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 7. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
    {bai}
    \shortans{{ ${m_rounded}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
