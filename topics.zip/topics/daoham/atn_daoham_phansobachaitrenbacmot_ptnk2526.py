import random
from fractions import Fraction

def to_latex_poly(coeffs, var='x'):
    """
    Chuyển danh sách hệ số [a, b, c] thành chuỗi ax^2 + bx + c đẹp.
    coeffs: list các hệ số từ bậc cao đến thấp.
    """
    res = ""
    degree = len(coeffs) - 1
    for i, p in enumerate(coeffs):
        curr_deg = degree - i
        if p == 0: continue
        
        # Xử lý dấu
        sign = "+" if p > 0 and res != "" else ""
        if p < 0: sign = "-"
        
        # Xử lý hệ số
        abs_p = abs(p)
        if abs_p == 1 and curr_deg > 0:
            coeff_str = ""
        else:
            coeff_str = str(abs_p)
            
        # Xử lý biến
        if curr_deg == 1:
            var_str = var
        elif curr_deg > 1:
            var_str = f"{var}^{{{curr_deg}}}"
        else:
            var_str = ""
            
        res += f"{sign}{coeff_str}{var_str}"
    return res

def nhanvao_dsdungsai_rachoice_motdung(dung, sai):
    """Trộn 1 đúng, 3 sai theo định dạng \\choice."""
    selected_dung = dung[0]
    # Lọc bỏ phần tử trùng và lấy 3 mẫu sai
    clean_sai = list(set([s for s in sai if s != selected_dung]))
    selected_sai = random.sample(clean_sai, 3)
    
    choices = [r'\True ' + selected_dung] + selected_sai
    random.shuffle(choices)
    
    return (f"\\choice \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def generate():
    # --- 1. THIẾT KẾ HÀM SỐ y = (ax^2) / (bx + c) ---
    while True:
        a = random.randint(-4, 4)
        b = random.choice([-3, -2, -1, 1, 2, 3])
        c = random.randint(-5, 5)
        x0 = random.randint(-3, 3)
        
        # Đảm bảo mẫu số tại x0 khác 0 và tử số không bằng 0
        if a != 0 and (b * x0 + c) != 0:
            break

    # --- 2. TÍNH TOÁN ĐẠO HÀM ---
    # Công thức: y' = [ (ax^2)'*(bx+c) - (ax^2)*(bx+c)' ] / (bx+c)^2
    # y' = [ 2ax*(bx+c) - a*b*x^2 ] / (bx+c)^2
    # y' = (abx^2 + 2acx) / (bx+c)^2
    
    tu_tai_x0 = (a * b * (x0**2)) + (2 * a * c * x0)
    mau_tai_x0 = (b * x0 + c)**2
    
    res_frac = Fraction(tu_tai_x0, mau_tai_x0)
    
    def format_frac(f):
        if f.denominator == 1: return f"{f.numerator}"
        return rf"\dfrac{{{f.numerator}}}{{{f.denominator}}}"

    correct_val = f"${format_frac(res_frac)}$"

    # --- 3. TẠO CÁC PHƯƠNG ÁN NHIỄU ---
    dssai = []
    dssai.append(f"${format_frac(-res_frac)}$") # Sai dấu
    dssai.append(f"${format_frac(Fraction(a * x0, b))}$") # Đạo hàm tử / đạo hàm mẫu
    dssai.append(f"${format_frac(Fraction(tu_tai_x0, abs(b * x0 + c)))}$") # Quên bình phương mẫu
    # Nhiễu số nguyên ngẫu nhiên
    while len(set(dssai)) < 5:
        dssai.append(f"${random.randint(-5, 5)}$")

    # --- 4. RÁP LATEX ---
    toan = nhanvao_dsdungsai_rachoice_motdung([correct_val], dssai)
    tu_tex = to_latex_poly([a, 0, 0]) # ax^2
    mau_tex = to_latex_poly([b, c])    # bx + c

 
    return rf"""\begin{{ex}}
Cho hàm số $y = \dfrac{{{tu_tex}}}{{{mau_tex}}}$. Đạo hàm của hàm số tại điểm $x_0 = {x0}$ bằng
{toan}
\loigiai{{
Ta có đạo hàm: $y' = \dfrac{{({tu_tex})'({mau_tex}) - ({tu_tex})({mau_tex})'}}{{({mau_tex})^2}} = \dfrac{{{to_latex_poly([a*b, 2*a*c, 0])}}}{{({mau_tex})^2}}$.
Thay $x_0 = {x0}$ vào biểu thức đạo hàm:
$y'({x0}) = \dfrac{{{a} \cdot {b} \cdot ({x0})^2 + 2 \cdot {a} \cdot {c} \cdot ({x0})}}{{({b} \cdot {x0} + {c})^2}} = \dfrac{{{tu_tai_x0}}}{{{mau_tai_x0}}} = {correct_val.replace('$', '')}$.
}}
\end{{ex}}"""
print(generate())
