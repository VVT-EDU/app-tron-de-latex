import random
from sympy import symbols, sin, cos, pi, diff, latex, simplify

def nhanvao_dsdungsai_rachoice_motdung(dung, sai):
    """Trộn 1 đúng, 3 sai theo định dạng \\choice."""
    selected_dung = dung[0]
    clean_sai = list(set([s for s in sai if s != selected_dung]))
    selected_sai = random.sample(clean_sai, 3)
    choices = [r'\True ' + selected_dung] + selected_sai
    random.shuffle(choices)
    return (f"\\choice \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def to_latex_trig_sum(a, b):
    """Hiển thị a*sin(x) + b*cos(x) dạng LaTeX đẹp."""
    res = ""
    # Xử lý a*sin(x)
    if a != 0:
        if a == 1: res += r"\sin x"
        elif a == -1: res += r"-\sin x"
        else: res += rf"{a}\sin x"
    
    # Xử lý b*cos(x)
    if b != 0:
        sign = "+" if b > 0 and res != "" else ""
        if b == -1: coeff = "-"
        elif b == 1: coeff = "" if res == "" else "+"
        else: coeff = str(b) if res == "" or b < 0 else f"+{b}"
        res += rf"{coeff}\cos x"
    return res

def generate():
    x = symbols('x')
    
    # --- 1. THIẾT KẾ HÀM SỐ y = a*sin(x) + b*cos(x) ---
    while True:
        a = random.randint(-5, 5)
        b = random.randint(-5, 5)
        if a != 0 or b != 0: break

    # Chọn điểm x0 đặc biệt
    x0_val, x0_tex = random.choice([
        (0, "0"),
        (pi/2, r"\dfrac{\pi}{2}"),
        (pi, r"\pi"),
        (pi/3, r"\dfrac{\pi}{3}"),
        (pi/4, r"\dfrac{\pi}{4}"),
        (pi/6, r"\dfrac{\pi}{6}")
    ])

    # --- 2. TÍNH TOÁN ĐẠO HÀM ---
    f = a*sin(x) + b*cos(x)
    f_prime = diff(f, x) # a*cos(x) - b*sin(x)
    
    # Giá trị đạo hàm tại x0
    res_val = f_prime.subs(x, x0_val)
    correct_val = f"${latex(simplify(res_val))}$"

    # --- 3. TẠO NHIỄU ---
    dssai = []
    # Nhiễu 1: Đạo hàm sai dấu (nhầm đạo hàm cos thành sin thay vì -sin)
    wrong_f_prime = a*cos(x) + b*sin(x)
    dssai.append(f"${latex(simplify(wrong_f_prime.subs(x, x0_val)))}$")
    
    # Nhiễu 2: Nhầm đạo hàm sin thành -cos
    wrong_f_prime2 = -a*cos(x) - b*sin(x)
    dssai.append(f"${latex(simplify(wrong_f_prime2.subs(x, x0_val)))}$")
    
    # Nhiễu 3: Giá trị của chính hàm số tại x0 (quên chưa đạo hàm)
    dssai.append(f"${latex(simplify(f.subs(x, x0_val)))}$")
    
    # Thêm nhiễu ngẫu nhiên nếu thiếu
    while len(set(dssai)) < 5:
        dssai.append(f"${random.randint(-5, 5)}$")

    # --- 4. RÁP LATEX ---
    toan = nhanvao_dsdungsai_rachoice_motdung([correct_val], dssai)
    ham_so_tex = to_latex_trig_sum(a, b)

    return rf"""\begin{{ex}}
Cho hàm số $y = {ham_so_tex}$. Đạo hàm của hàm số tại điểm $x_0 = {x0_tex}$ bằng
{toan}
\loigiai{{
Ta có đạo hàm $y' = ({ham_so_tex})' = {latex(simplify(f_prime))}$.
Thay $x_0 = {x0_tex}$ vào biểu thức đạo hàm:
$y'({x0_tex}) = {latex(f_prime).replace('x', x0_tex)} = {correct_val.replace('$', '')}$.
}}
\end{{ex}}"""

print(generate())
