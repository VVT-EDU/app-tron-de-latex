import random
from sympy import symbols, diff, latex, Rational, simplify

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    # Chọn giá trị a để tạo k = Rational(a)
    a = random.choice([1, 2, 3, 4, 5])
    k = Rational(a)
    
    # Hàm số f(x) = (kx - 1) / (2x + 1)
    ham_so = (k * x - 1) / (2 * x + 1)
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    dham = diff(ham_so, x)
    dham = simplify(dham) # Rút gọn đạo hàm
    
    # Tính giá trị đạo hàm tại x = k
    thay_x = k
    f_prime_k = dham.subs(x, thay_x)
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai_tap = f"Cho hàm số $f(x) = {latex(ham_so)}$. Tính đạo hàm của hàm số tại điểm $x = {latex(k)}$."

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    # Công thức đạo hàm nhanh: ((ax+b)/(cx+d))' = (ad-bc)/(cx+d)^2
    y_list = [
        f"Ta có hàm số $f(x) = {latex(ham_so)}$.",
        f"Sử dụng quy tắc đạo hàm của thương $\\left(\\dfrac{u}{v}\\right)' = \\dfrac{u'v - uv'}{v^2}$, ta có:",
        f"$f'(x) = {latex(dham)}$.",
        f"Thay $x = {latex(thay_x)}$ vào biểu thức đạo hàm, ta được:",
        f"$f'({latex(thay_x)}) = {latex(f_prime_k)}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai_tap}
    \shortans{{ ${latex(f_prime_k)}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
