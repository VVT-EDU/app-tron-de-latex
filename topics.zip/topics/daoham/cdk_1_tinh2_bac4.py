import random
from sympy import symbols, diff, latex, Rational

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    a = random.choice([1, 2, 3, 5, 7, 9])
    b = random.choice([2, 4, 6, 8])
    c = random.choice([1, 2, 3, 5, 7, 9])
    
    # Hàm số f(x) = (1/2)x^4 - bx^2 - c
    # Sử dụng Rational(1, 2) để hiển thị \frac{1}{2} thay vì 0.5
    ham_so = Rational(1, 2) * x**4 - b * x**2 - c
    
    # 2. TÍNH TOÁN ĐẠO HÀM
    dham = diff(ham_so, x)
    
    # Tính giá trị đạo hàm tại x = a
    thay_x = a
    f_prime_a = dham.subs(x, thay_x)
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai_tap = f"Cho hàm số $f(x) = {latex(ham_so)}$. Tính đạo hàm của hàm số tại điểm $x = {thay_x}$."

    # 4. DANH SÁCH CÁC BƯỚC GIẢI
    y_list = [
        f"Ta có hàm số $f(x) = {latex(ham_so)}$.",
        f"Đạo hàm của hàm số là: $f'(x) = ({latex(ham_so)})' = {latex(dham)}$.",
        f"Thay $x = {thay_x}$ vào biểu thức $f'(x)$, ta được:",
        f"$f'({thay_x}) = 2 \\cdot {thay_x}^3 - 2 \\cdot {b} \\cdot {thay_x} = {f_prime_a}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai_tap}
    \shortans{{ ${f_prime_a}$ }}
    \loigiai{{
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
