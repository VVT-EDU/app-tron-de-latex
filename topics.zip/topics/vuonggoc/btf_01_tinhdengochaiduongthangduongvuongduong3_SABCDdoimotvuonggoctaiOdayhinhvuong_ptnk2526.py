from sympy import symbols, Interval, latex, solveset, S, Eq, Ne, expand, Plane
from sympy.sets import Complement, FiniteSet
import os, re, random
from sympy import Line, Point, symbols, Eq, solve, pi, sqrt
from sympy import symbols, Interval, latex
from sympy import FiniteSet
import os, re
from sympy import Point3D, Line, latex, simplify, Matrix
from sympy.geometry import Point
import sympy as sp
from math import gcd
from functools import reduce
from sympy import Point3D
from sympy.vector import CoordSys3D, cross
from sympy import Matrix, Rational, cos, sin , pi, deg

# Hệ tọa độ
N = CoordSys3D('N')

x, y, z, t = symbols('x y z t')


import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    r"""
    Trộn 2 đúng, 2 sai theo định dạng \choiceTF.
    Đảm bảo chỉ số đã chọn trong danh sách đúng không bị lấy lại từ danh sách sai.
    """
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
        
    # Chọn 2 đúng
    indices_dung = random.sample(range(len(dung)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    
    # Loại bỏ các chỉ số trùng với indices_dung trong danh sách sai
    indices_sai_available = [i for i in range(len(sai)) if i not in indices_dung]
    
    if len(indices_sai_available) < 2:
        return ["Không đủ sai sau khi loại trùng", []]
    
    # Chọn 2 sai từ danh sách đã loại trùng
    indices_sai = random.sample(indices_sai_available, 2)
    selected_sai = [sai[i] for i in indices_sai]
    
    # Gắn nhãn \True cho đúng
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return choice_str
 
import random
from sympy import Rational, latex

def ds_tudien_doimotvuonggoc_dinhday_hoigoc(A,B,C,D, ten1="A", ten2="B", ten3="C", ten4="D"):
 
    ab=A.distance(B)
    ac=A.distance(C)
    ad=A.distance(D)
    bc=B.distance(C)
    bd=B.distance(D)
    cd=C.distance(D)

    vtDC=C-D
    vtDB=B-D
    vtDA=A-D
    vtBD=D-B
    vtBA=A-B
    vtBC=C-B

    cosADC=abs((vtDA.dot(vtDC))/(ad*cd))
    cosBDC=abs((vtDB.dot(vtDC))/(bd*cd))
    cosADB=abs((vtDB.dot(vtDA))/(bd*ad))
    cosABD=abs((vtBA.dot(vtBD))/(ab*bd))
    cosABC=abs((vtBA.dot(vtBC))/(ab*bc))
    cosDBC=abs((vtBD.dot(vtBC))/(bd*bc))

    # Các công thức đúng
    y1 = f"Gọi $x_{ten1}$ là góc giữa hai đường thẳng ${ten4}{ten1}$ và ${ten4}{ten3}$, lúc đó $\\cos{{x_{ten1}}}={latex(cosADC)}$"
    y2 = f"Gọi $y_{ten1}$ là góc giữa hai đường thẳng ${ten4}{ten2}$ và ${ten4}{ten3}$, lúc đó $\\cos{{y_{ten1}}}={latex(cosBDC)}$"
    y3 = f"Gọi $z_{ten1}$ là góc giữa hai đường thẳng ${ten4}{ten1}$ và ${ten4}{ten2}$, lúc đó $\\cos{{z_{ten1}}}={latex(cosADB)}$"
    y4 = f"Gọi $u_{ten1}$ là góc giữa hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten4}$, lúc đó $\\cos{{u_{ten1}}}={latex(cosABD)}$"
    y5 = f"Gọi $v_{ten1}$ là góc giữa hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten3}$, lúc đó $\\cos{{v_{ten1}}}={latex(cosABC)}$"
    y6 = f"Gọi $w_{ten1}$ là góc giữa hai đường thẳng ${ten2}{ten4}$ và ${ten2}{ten3}$, lúc đó $\\cos{{w_{ten1}}}={latex(cosDBC)}$"
    
    dsdung=[y1, y2, y3, y4, y5, y6]

    # Các công thức sai
    saii = Rational(1, random.choice([2,3,4,5]))
    y1s = f"Gọi $x_{ten1}$ là góc giữa hai đường thẳng ${ten4}{ten1}$ và ${ten4}{ten3}$, lúc đó $\\cos{{x_{ten1}}}={latex(cosADC*saii)}$"
    y2s = f"Gọi $y_{ten1}$ là góc giữa hai đường thẳng ${ten4}{ten2}$ và ${ten4}{ten3}$, lúc đó $\\cos{{y_{ten1}}}={latex(cosBDC*saii)}$"
    y3s = f"Gọi $z_{ten1}$ là góc giữa hai đường thẳng ${ten4}{ten1}$ và ${ten4}{ten2}$, lúc đó $\\cos{{z_{ten1}}}={latex(cosADB*saii)}$"
    y4s = f"Gọi $u_{ten1}$ là góc giữa hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten4}$, lúc đó $\\cos{{u_{ten1}}}={latex(cosABD*saii)}$"
    y5s = f"Gọi $v_{ten1}$ là góc giữa hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten3}$, lúc đó $\\cos{{v_{ten1}}}={latex(cosABC*saii)}$"
    y6s = f"Gọi $w_{ten1}$ là góc giữa hai đường thẳng ${ten2}{ten4}$ và ${ten2}{ten3}$, lúc đó $\\cos{{w_{ten1}}}={latex(cosDBC*saii)}$"
    y7s=f"Hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten4}$ vuông góc với nhau"
    y8s=f"Hai đường thẳng ${ten1}{ten3}$ và ${ten3}{ten4}$ vuông góc với nhau"
    y9s=f"Hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten3}$ vuông góc với nhau"
    y10s=f"Hai đường thẳng ${ten3}{ten2}$ và ${ten2}{ten4}$ vuông góc với nhau"
    dssai=[y1s, y2s, y3s, y4s, y5s, y6s, y7s, y8s, y9s, y10s]

    return [dsdung, dssai]


def generate():
    a_val, s_val = random.sample([2, 3, 4, 5, 6], 2)
    
    # Tọa độ các điểm với O là gốc (0,0,0)
    O = Point3D(0, 0, 0)
    S = Point3D(0, 0, s_val)
    A = Point3D(a_val, 0, 0)
    B = Point3D(0, a_val, 0)
    C = Point3D(-a_val, 0, 0)
    D = Point3D(0, -a_val, 0)
    ab=A.distance(B)
    # DANH SÁCH BỘ 4: (Gốc vuông, Đỉnh 1, Đỉnh 2, Đỉnh 3, Tên Gốc, Tên 1, Tên 2, Tên 3)
    cac_bo_diem = [
        (O, A, B, S, "O", "A", "B", "S"),
        (O, B, C, S, "O", "B", "C", "S"),
        (O, C, D, S, "O", "C", "D", "S"),
        (O, D, A, S, "O", "D", "A", "S")
    ]
    
    # Chọn ngẫu nhiên bộ điểm
    bo = random.choice(cac_bo_diem)
    
    # Truyền tham số: bo[0] (tâm O) luôn vào vị trí tham số đầu tiên của hàm xử lý
    dung, sai = ds_tudien_doimotvuonggoc_dinhday_hoigoc(
        bo[0], bo[1], bo[2], bo[3], 
        ten1=bo[4], ten2=bo[5], ten3=bo[6], ten4=bo[7]
    )
    
    # Trộn đáp án (dung là list, sai là list)
    toan = nhanvao_dsdungsai_rachoice_dungsai(dung, sai)

    # Tính độ dài các cạnh để đưa vào đề bài cho sinh động
    canh_day = bo[0].distance(bo[1])
    canh_cao = bo[0].distance(bo[3])
    loigiai_str = "\\\\\n".join(dung)
    return rf"""\begin{{ex}}
Cho hình chóp $S.ABCD$ có đáy $ABCD$ là hình vuông tâm ${bo[4]}$.
Biết các cạnh ${bo[4]}{bo[5]}, {bo[4]}{bo[6]}, {bo[4]}{bo[7]}$ đôi một vuông góc với nhau tại ${bo[4]}$.
Cho $AB={latex(ab)}$  và ${bo[4]}{bo[7]} = {latex(canh_cao)}$.
\textbf{{Xác định tính đúng sai của mỗi khẳng định sau}}
{toan}
\loigiai{{
{loigiai_str }
}}
\end{{ex}}"""

print(generate())






















