from sympy import symbols, Interval, latex, solveset, S, Eq, Ne, expand, Plane
from sympy.sets import Complement, FiniteSet
import os, re, random
from sympy import Line, Point, symbols, Eq, solve, pi, sqrt
from sympy import symbols, Interval, latex
from sympy import FiniteSet
import os, re
from sympy import Point3D, Line, latex, simplify, Matrix
from sympy.geometry import Point
import sympy as sp
from math import gcd
from functools import reduce
from sympy import Point3D
from sympy.vector import CoordSys3D, cross
from sympy import Matrix, Rational, cos, sin , pi, deg
from decimal import Decimal, ROUND_HALF_UP

# Hệ tọa độ
N = CoordSys3D('N')

x, y, z, t = symbols('x y z t')
# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))
def cdk_tamgiac_hoigoc(B,C,D, ten1="B", ten2="C", ten3="D"):
    r"""hoi goc BCD ten2ten3ten4
"""
    cb=C.distance(B)
    cd=C.distance(D)
    bd=B.distance(D)
    vtCB=B-C
    vtCD=D-C   
    cosBCD=abs((vtCB.dot(vtCD))/(cb*cd))
    kq=cosBCD
    y1=f"Góc giữa ${ten1}{ten2}$ và ${ten2}{ten3}$ là $\\widehat{{ {ten1}{ten2}{ten3} }}$"
    y2=f"${ten1}{ten2}={latex(cb)}$, ${ten2}{ten3}={latex(cd)}$ và ${ten1}{ten3}={latex(bd)}$"
    y3=f"$\\cos{{ \\widehat{{ {ten1}{ten2}{ten3} }} }}={latex(cosBCD)}$  "  
    return [y1,y2,y3,kq]
def generate():
    a, d = random.sample([1,2,3,4 ], 2)
    # Tọa độ các điểm với O là gốc (0,0,0)
    a=a*6*sqrt(3)
    t1, t2, y1=a*sqrt(3)/3, a*sqrt(3)/6, a/2
    O = Point3D(0, 0, 0)
    A = Point3D(t1, 0, 0)
    B = Point3D(-t2, y1, 0)
    C = Point3D(-t2, -y1, 0)
    D=Point3D(t1,0,d)
    I=(B+C)/2

    # Tính độ dài các cạnh
    ab = A.distance(B)
    ac = A.distance(C)
    ad = A.distance(D)

    # Lấy danh sách đúng/sai
    gocBID= cdk_tamgiac_hoigoc(B,I,D,ten1="B", ten2="I", ten3="D")
    kq1=gocBID[-1]
    gocBID.remove(kq1)
    loigiai1=gocBID
    # Lấy danh sách đúng/sai
    gocIDC= cdk_tamgiac_hoigoc(B,I,D,ten1="I", ten2="D", ten3="C")
    kq2=gocIDC[-1]
    gocIDC.remove(kq2)
    loigiai2=gocIDC
    kq=kq1+kq2
    m=random.choice([10,20,30])
    kq=int(round_half_up(float(kq*m),0))
    loigiai=loigiai1+loigiai2
    lg1=f"$M={latex(m*cos(x))} \\approx {latex(kq)}$"
    loigiai.append(lg1)
    loigiai_str = "\\\\\n".join(loigiai)
    return rf"""\begin{{ex}}
Cho hình chóp $ABCD$ có $AD$ vuông góc $AB$ và $AC$. Tam giác $ABC$ đều. 
Biết $AB={latex(ab)}$ và $AD={latex(ad)}$.
Trung điểm $BC$ là $I$. 

Gọi các góc ($BC; ID$) và ($DI; DC$) lần lượt là $x$ và $y$
Tính $M={latex(m*(cos(x)+cos(y)))}$ (làm tròn đến hàng đơn vị)
\shortans{{ ${latex(kq)}$ }}
\loigiai{{
{loigiai_str}
  }}
\end{{ex}}"""

    
print(generate())
 
