from sympy import symbols, Interval, latex, solveset, S, Eq, Ne, expand, Plane
from sympy.sets import Complement, FiniteSet
import os, re, random
from sympy import Line, Point, symbols, Eq, solve, pi, sqrt
from sympy import symbols, Interval, latex
from sympy import FiniteSet
import os, re
from sympy import Point3D, Line, latex, simplify, Matrix
from sympy.geometry import Point
import sympy as sp
from math import gcd
from functools import reduce
from sympy import Point3D
from sympy.vector import CoordSys3D, cross
from sympy import Matrix, Rational, cos, sin , pi, deg

# Hệ tọa độ
N = CoordSys3D('N')

x, y, z, t = symbols('x y z t')


import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    r"""
    Trộn 2 đúng, 2 sai theo định dạng \choiceTF.
    Đảm bảo chỉ số đã chọn trong danh sách đúng không bị lấy lại từ danh sách sai.
    """
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
        
    # Chọn 2 đúng
    indices_dung = random.sample(range(len(dung)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    
    # Loại bỏ các chỉ số trùng với indices_dung trong danh sách sai
    indices_sai_available = [i for i in range(len(sai)) if i not in indices_dung]
    
    if len(indices_sai_available) < 2:
        return ["Không đủ sai sau khi loại trùng", []]
    
    # Chọn 2 sai từ danh sách đã loại trùng
    indices_sai = random.sample(indices_sai_available, 2)
    selected_sai = [sai[i] for i in indices_sai]
    
    # Gắn nhãn \True cho đúng
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return choice_str
 
import random
from sympy import Rational, latex

def ds_tudien_doimotvuonggoc_dinhday_hoigoc(A,B,C,D, ten1="A", ten2="B", ten3="C", ten4="D"):
 
    ab=A.distance(B)
    ac=A.distance(C)
    ad=A.distance(D)
    bc=B.distance(C)
    bd=B.distance(D)
    cd=C.distance(D)

    vtDC=C-D
    vtDB=B-D
    vtDA=A-D
    vtBD=D-B
    vtBA=A-B
    vtBC=C-B

    cosADC=abs((vtDA.dot(vtDC))/(ad*cd))
    cosBDC=abs((vtDB.dot(vtDC))/(bd*cd))
    cosADB=abs((vtDB.dot(vtDA))/(bd*ad))
    cosABD=abs((vtBA.dot(vtBD))/(ab*bd))
    cosABC=abs((vtBA.dot(vtBC))/(ab*bc))
    cosDBC=abs((vtBD.dot(vtBC))/(bd*bc))

    # Các công thức đúng
    y1 = f"Gọi $x_{ten1}$ là góc giữa hai đường thẳng ${ten4}{ten1}$ và ${ten4}{ten3}$, lúc đó $\\cos{{x_{ten1}}}={latex(cosADC)}$"
    y2 = f"Gọi $y_{ten1}$ là góc giữa hai đường thẳng ${ten4}{ten2}$ và ${ten4}{ten3}$, lúc đó $\\cos{{y_{ten1}}}={latex(cosBDC)}$"
    y3 = f"Gọi $z_{ten1}$ là góc giữa hai đường thẳng ${ten4}{ten1}$ và ${ten4}{ten2}$, lúc đó $\\cos{{z_{ten1}}}={latex(cosADB)}$"
    y4 = f"Gọi $u_{ten1}$ là góc giữa hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten4}$, lúc đó $\\cos{{u_{ten1}}}={latex(cosABD)}$"
    y5 = f"Gọi $v_{ten1}$ là góc giữa hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten3}$, lúc đó $\\cos{{v_{ten1}}}={latex(cosABC)}$"
    y6 = f"Gọi $w_{ten1}$ là góc giữa hai đường thẳng ${ten2}{ten4}$ và ${ten2}{ten3}$, lúc đó $\\cos{{w_{ten1}}}={latex(cosDBC)}$"
    
    dsdung=[y1, y2, y3, y4, y5, y6]

    # Các công thức sai
    saii = Rational(1, random.choice([2,3,4,5]))
    y1s = f"Gọi $x_{ten1}$ là góc giữa hai đường thẳng ${ten4}{ten1}$ và ${ten4}{ten3}$, lúc đó $\\cos{{x_{ten1}}}={latex(cosADC*saii)}$"
    y2s = f"Gọi $y_{ten1}$ là góc giữa hai đường thẳng ${ten4}{ten2}$ và ${ten4}{ten3}$, lúc đó $\\cos{{y_{ten1}}}={latex(cosBDC*saii)}$"
    y3s = f"Gọi $z_{ten1}$ là góc giữa hai đường thẳng ${ten4}{ten1}$ và ${ten4}{ten2}$, lúc đó $\\cos{{z_{ten1}}}={latex(cosADB*saii)}$"
    y4s = f"Gọi $u_{ten1}$ là góc giữa hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten4}$, lúc đó $\\cos{{u_{ten1}}}={latex(cosABD*saii)}$"
    y5s = f"Gọi $v_{ten1}$ là góc giữa hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten3}$, lúc đó $\\cos{{v_{ten1}}}={latex(cosABC*saii)}$"
    y6s = f"Gọi $w_{ten1}$ là góc giữa hai đường thẳng ${ten2}{ten4}$ và ${ten2}{ten3}$, lúc đó $\\cos{{w_{ten1}}}={latex(cosDBC*saii)}$"
    y7s=f"Hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten4}$ vuông góc với nhau"
    y8s=f"Hai đường thẳng ${ten1}{ten3}$ và ${ten3}{ten4}$ vuông góc với nhau"
    y9s=f"Hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten3}$ vuông góc với nhau"
    y10s=f"Hai đường thẳng ${ten3}{ten2}$ và ${ten2}{ten4}$ vuông góc với nhau"
    dssai=[y1s, y2s, y3s, y4s, y5s, y6s, y7s, y8s, y9s, y10s]

    return [dsdung, dssai]

def generate():
    b, c,d = random.sample([1,2,3,4,5,6,7], 3)

    A = Point3D(0,0,0)
    B = Point3D(b,0,0)
    C = Point3D(0,c,0)
    D = Point3D(0,0,d)

    # Tính độ dài các cạnh
    ab = A.distance(B)
    ad = A.distance(D)
    ac = A.distance(C)

    # Lấy danh sách đúng/sai
    dung1, sai1= ds_tudien_doimotvuonggoc_dinhday_hoigoc(A,B,C,D, ten1="A", ten2="B", ten3="C", ten4="D")
    dung, sai=dung1 , sai1 
    toan = nhanvao_dsdungsai_rachoice_dungsai(dung, sai)

    # Ghép LaTeX
    loigiai_str = "\\\\\n".join(dung)
    return rf"""\begin{{ex}}
Cho hình chóp ABCD có $AB, AC, AD$ đôi một vuông góc với nhau tại $A$. 
Biết $AB={latex(ab)}$, $AC={latex(ac)}$ và $AD={latex(ad)}$.
\textbf{{Xác định tính đúng sai của mỗi khẳng định sau}}
{toan}
\loigiai{{
{loigiai_str}
}}
\end{{ex}}"""
#\textbf{{Khẳng định nào sau đây là đúng}}
    
print(generate())




























