from sympy import symbols, Interval, latex, solveset, S, Eq, Ne, expand, Plane
from sympy.sets import Complement, FiniteSet
import os, re, random
from sympy import Line, Point, symbols, Eq, solve, pi, sqrt
from sympy import symbols, Interval, latex
from sympy import FiniteSet
import os, re
from sympy import Point3D, Line, latex, simplify, Matrix
from sympy.geometry import Point
import sympy as sp
from math import gcd
from functools import reduce
from sympy import Point3D
from sympy.vector import CoordSys3D, cross
from sympy import Matrix, Rational, cos, sin , pi, deg
from decimal import Decimal, ROUND_HALF_UP

# Hệ tọa độ
N = CoordSys3D('N')

x, y, z, t = symbols('x y z t')
# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))
def cdk_tamgiac_hoigoc(B,C,D, ten1="B", ten2="C", ten3="D"):
    r"""hoi goc BCD ten2ten3ten4
"""
    cb=C.distance(B)
    cd=C.distance(D)
    bd=B.distance(D)
    vtCB=B-C
    vtCD=D-C 
    cosBCD=abs((vtCB.dot(vtCD))/(cb*cd))
    kq=cosBCD
    y1=f"Góc giữa ${ten1}{ten2}$ và ${ten2}{ten3}$ là $\\widehat{{ {ten1}{ten2}{ten3} }}$"
    y2=f"${ten1}{ten2}={latex(cb)}$, ${ten2}{ten3}={latex(cd)}$ và ${ten1}{ten3}={latex(bd)}$"
    y3=f"$\\cos{{ \\widehat{{ {ten1}{ten2}{ten3} }} }}={latex(cosBCD)}$  "  
    return [y1,y2,y3,kq]

def generate():
    b,s1 = random.sample([1,2,3,4,5 ], 2)
    A = Point3D(0,0,0)
    B = Point3D(b,0,0)
    D = Point3D(0,b,0)
    S = Point3D(0,0,s1)
    C=B+D-A
    I=(A+C)/2

    # Tính độ dài các cạnh
    ab = A.distance(B)
    bc = B.distance(C)
    sa = A.distance(S)
     
    dtSI=Line(S,I)
    J=dtSI.projection(A)
    aj=A.distance(J)
    kq1=aj
    kq2=bc/2
    kq=kq1+kq2
    kq=int(round_half_up(float(kq),0))
    y1=f"$CB \\perp (SAB)$"
    y2=f"$BD \\perp (AIS)$ và $AJ \\perp (BSD)$"
    y3=f"$x=AJ={latex(aj)}$"
    y4a=f"$\\dfrac{{d(I; (BSA)) }}{{d(C; (BSA))}}=\\dfrac{{1}}{{2}}"
    y4=f"$y=\\dfrac{{BC}}{{2}}={latex(bc/2)}$"
    y5=f"$M={latex(kq1+kq2)} \\approx {latex(kq)}$"
    loigiai=[y1,y2,y3,y4a,y4,y5]
    loigiai_str = "\\\\\n".join(loigiai)
    hinhve = rf"""
        \begin{{tikzpicture}}[scale=0.6,yscale=0.7,font=\footnotesize, line join=round, line cap=round, >=stealth] 
         \def \day{{-120}} 
         \def \dinh{{90}} 
         \def \dai{{8}} 
         \def \rong{{5}} 
         \def \cao{{7}}
         
        \path (0,0) coordinate(A)
        (\dai,0)coordinate(B) 
        ($(A)+(\day:\rong)$)coordinate(D)
        ($(A)+(\dinh:\cao)$)coordinate(S)
        ($(B)+(D)-(A)$)coordinate(C)
          ;
         
        \draw (D)--(C)--(B)--(S)--(C) (S)--(D);
        
        \draw[dashed](D)--(A)--(B) (S)--(A)    ;
        \path ($(C)!0.5!(A)$)coordinate(I)  ;
        \path ($(S)!0.4!(I)$)coordinate(J)  ;
        \draw[dashed](S)--(I) (A)--(J) (B)--(D) (A)--(C);
         
        \foreach \i/\g in{{S/90, A/40, B/0, C/-90, D/-90, I/0,J/0}}{{ \fill(\i) circle(1.5pt); \path ($(\i)+(\g:0.8)$)node{{$\i$}}; }}
        \end{{tikzpicture}}
    """
    return rf"""\begin{{ex}}
Cho hình chóp $SABCD$ có các cạnh $AB, AD, AS$ đôi một vuông góc với nhau tại $A$.
Đáy $ABCD$ là hình vuông. 
Biết $AB={latex(ab)}$  và $AS={latex(sa)}$.
Có $I \in BD$, $J \in SI$, $AI \perp BD$ và $AJ \perp SI$. 
Gọi $x; y $ lần lượt là khoảng cách từ $A$ đến $(BSD)$ và từ $I$ đến $(BSA)$. 
Tính $M={latex(x+y)}$ (làm tròn đến hàng đơn vị)
\shortans{{ ${latex(kq)}$ }}
\loigiai{{
\begin{{center}} {hinhve} \end{{center}}
{loigiai_str}
  }}
\end{{ex}}"""

    
print(generate())
 
