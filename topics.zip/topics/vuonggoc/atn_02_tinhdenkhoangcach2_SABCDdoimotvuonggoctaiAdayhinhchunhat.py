from sympy import symbols, Interval, latex, solveset, S, Eq, Ne, expand, Plane
from sympy.sets import Complement, FiniteSet
import os, re, random
from sympy import Line, Point, symbols, Eq, solve, pi, sqrt
from sympy import symbols, Interval, latex
from sympy import FiniteSet
import os, re
from sympy import Point3D, Line, latex, simplify, Matrix
from sympy.geometry import Point
import sympy as sp
from math import gcd
from functools import reduce
from sympy import Point3D
from sympy.vector import CoordSys3D, cross
from sympy import Matrix, Rational, cos, sin , pi, deg

# Hệ tọa độ
N = CoordSys3D('N')

x, y, z, t = symbols('x y z t')


import random

def nhanvao_dsdungsai_rachoice_motdung(dung, sai):
    r"""
    Trộn 1 đúng, 3 sai theo định dạng \choiceTF.
    Đảm bảo chỉ số đã chọn trong danh sách đúng không bị lấy lại từ danh sách sai.
    """
    if len(dung) < 1 or len(sai) < 3:
        return ["Lỗi danh sách", []]
        
    # Chọn 1 đúng
    index_dung = random.choice(range(len(dung)))
    selected_dung = dung[index_dung]
    
    # Loại bỏ phần tử sai có cùng chỉ số với phần tử đúng (nếu danh sách sai cùng gốc với dung)
    indices_sai = [i for i in range(len(sai)) if i != index_dung]
    
    if len(indices_sai) < 3:
        return ["Không đủ sai sau khi loại trùng", []]
    
    # Chọn 3 sai từ danh sách sai đã loại trùng
    selected_sai = [sai[i] for i in random.sample(indices_sai, 3)]
    
    # Gắn nhãn \True cho đúng
    choices = [r'\True ' + selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choice \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return choice_str



 
import random
from sympy import Rational, latex

def ds_tudien_doimotvuonggoc_dinhday_hoikhoangcach(A,B,C,D, ten1="A", ten2="B", ten3="C", ten4="D"):
    # ... (giữ nguyên phần tính toán độ dài và cos) ...
    ab=A.distance(B)
    ac=A.distance(C)
    ad=A.distance(D)
     
    # Cấu trúc lưu trữ: txt là chuỗi văn bản, val là giá trị SymPy
    y1 = {"txt": f"Khoảng cách từ ${ten2}$ đến $({ten1}{ten3}{ten4})$ bằng", "val": ab}
    y2 = {"txt": f"Khoảng cách từ ${ten3}$ đến $({ten1}{ten2}{ten4})$ bằng", "val": ac}
    y3 = {"txt": f"Khoảng cách từ ${ten4}$ đến $({ten1}{ten3}{ten2})$ bằng", "val": ad}
    
    trunggiandung = random.choice([y1, y2, y3])
    
    dsdung = [f"${latex(trunggiandung['val'])}$"]
    ycde = trunggiandung['txt'] # KHÔNG bọc latex() ở đây vì nó là chuỗi văn bản chứa $ $ bên trong

    # Tạo 3 đáp án sai bằng cách nhân với các phân số ngẫu nhiên
    numbers = random.sample([2, 3, 4, 5, 6, 7], 3)
    s = [Rational(1, n) for n in numbers]
    
    # Tạo danh sách sai (không để phần tử rỗng)
    dssai = [f""]+[f"${latex(simplify(trunggiandung['val'] * si))}$" for si in s]

    return [dsdung, dssai, ycde]

def generate():
    b, d, s = random.sample([1,2,3,4,5,6,7], 3)

    A = Point3D(0,0,0)
    B = Point3D(b,0,0)
    D = Point3D(0,d,0)
    S = Point3D(0,0,s)
    C=B+D-A

    # Tính độ dài các cạnh
    ab = A.distance(B)
    sa = A.distance(S)
    ad = A.distance(D)

    # Lấy danh sách đúng/sai
    dung1, sai1, ycde = ds_tudien_doimotvuonggoc_dinhday_hoikhoangcach(A,B,D,S, ten1="A", ten2="B", ten3="D", ten4="S")
    dung, sai=dung1 , sai1 
    toan = nhanvao_dsdungsai_rachoice_motdung(dung, sai)

    # Ghép LaTeX
    loigiai_str = "\\\\\n".join(dung)
    return rf"""\begin{{ex}}
Cho hình chóp SABCD có $AB, AD, AS$ đôi một vuông góc với nhau tại $A$.
Đáy $ABCD$ là hình chữ nhật. 
Biết $AB={latex(ab)}$, $AD={latex(ad)}$ và $AS={latex(sa)}$.
{ycde}
{toan}
\loigiai{{
{loigiai_str}
}}
\end{{ex}}"""
#\textbf{{Khẳng định nào sau đây là đúng}}
    
print(generate())




























