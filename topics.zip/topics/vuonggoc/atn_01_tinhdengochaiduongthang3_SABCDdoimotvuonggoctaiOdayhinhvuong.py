from sympy import symbols, Interval, latex, solveset, S, Eq, Ne, expand, Plane
from sympy.sets import Complement, FiniteSet
import os, re, random
from sympy import Line, Point, symbols, Eq, solve, pi, sqrt
from sympy import symbols, Interval, latex
from sympy import FiniteSet
import os, re
from sympy import Point3D, Line, latex, simplify, Matrix
from sympy.geometry import Point
import sympy as sp
from math import gcd
from functools import reduce
from sympy import Point3D
from sympy.vector import CoordSys3D, cross
from sympy import Matrix, Rational, cos, sin , pi, deg

# Hệ tọa độ
N = CoordSys3D('N')

x, y, z, t = symbols('x y z t')


import random

def nhanvao_dsdungsai_rachoice_motdung(dung, sai):
    r"""
    Trộn 1 đúng, 3 sai theo định dạng \choiceTF.
    Đảm bảo chỉ số đã chọn trong danh sách đúng không bị lấy lại từ danh sách sai.
    """
    if len(dung) < 1 or len(sai) < 3:
        return ["Lỗi danh sách", []]
        
    # Chọn 1 đúng
    index_dung = random.choice(range(len(dung)))
    selected_dung = dung[index_dung]
    
    # Loại bỏ phần tử sai có cùng chỉ số với phần tử đúng (nếu danh sách sai cùng gốc với dung)
    indices_sai = [i for i in range(len(sai)) if i != index_dung]
    
    if len(indices_sai) < 3:
        return ["Không đủ sai sau khi loại trùng", []]
    
    # Chọn 3 sai từ danh sách sai đã loại trùng
    selected_sai = [sai[i] for i in random.sample(indices_sai, 3)]
    
    # Gắn nhãn \True cho đúng
    choices = [r'\True ' + selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choice \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return choice_str



 
import random
from sympy import Rational, latex

def ds_tudien_doimotvuonggoc_dinhday_hoigoc(A,B,C,D, ten1="A", ten2="B", ten3="C", ten4="D"):
    # ... (giữ nguyên phần tính toán độ dài và cos) ...
    ab=A.distance(B)
    ac=A.distance(C)
    ad=A.distance(D)
    bc=B.distance(C)
    bd=B.distance(D)
    cd=C.distance(D)

    vtDC=C-D
    vtDB=B-D
    vtDA=A-D
    vtBD=D-B
    vtBA=A-B
    vtBC=C-B

    cosADC=abs((vtDA.dot(vtDC))/(ad*cd))
    cosBDC=abs((vtDB.dot(vtDC))/(bd*cd))
    cosADB=abs((vtDB.dot(vtDA))/(bd*ad))
    cosABD=abs((vtBA.dot(vtBD))/(ab*bd))
    cosABC=abs((vtBA.dot(vtBC))/(ab*bc))
    cosDBC=abs((vtBD.dot(vtBC))/(bd*bc))



    # Cấu trúc lưu trữ: txt là chuỗi văn bản, val là giá trị SymPy
    y1 = {"txt": f"Gọi $x_{{{ten1}}}$ là góc giữa hai đường thẳng ${ten4}{ten1}$ và ${ten4}{ten3}$, lúc đó $\\cos x_{{{ten1}}}$ bằng", "val": cosADC}
    y2 = {"txt": f"Gọi $y_{{{ten1}}}$ là góc giữa hai đường thẳng ${ten4}{ten2}$ và ${ten4}{ten3}$, lúc đó $\\cos y_{{{ten1}}}$ bằng", "val": cosBDC}
    y3 = {"txt": f"Gọi $z_{{{ten1}}}$ là góc giữa hai đường thẳng ${ten4}{ten1}$ và ${ten4}{ten2}$, lúc đó $\\cos z_{{{ten1}}}$ bằng", "val": cosADB}
    y4 = {"txt": f"Gọi $u_{{{ten1}}}$ là góc giữa hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten4}$, lúc đó $\\cos u_{{{ten1}}}$ bằng", "val": cosABD}
    y5 = {"txt": f"Gọi $v_{{{ten1}}}$ là góc giữa hai đường thẳng ${ten1}{ten2}$ và ${ten2}{ten3}$, lúc đó $\\cos v_{{{ten1}}}$ bằng", "val": cosABC}
    y6 = {"txt": f"Gọi $w_{{{ten1}}}$ là góc giữa hai đường thẳng ${ten2}{ten4}$ và ${ten2}{ten3}$, lúc đó $\\cos w_{{{ten1}}}$ bằng", "val": cosDBC}

    trunggiandung = random.choice([y1, y2, y3, y4, y5, y6])
    
    dsdung = [f"${latex(trunggiandung['val'])}$"]
    ycde = trunggiandung['txt'] # KHÔNG bọc latex() ở đây vì nó là chuỗi văn bản chứa $ $ bên trong

    # Tạo 3 đáp án sai bằng cách nhân với các phân số ngẫu nhiên
    numbers = random.sample([2, 3, 4, 5, 6, 7], 3)
    s = [Rational(1, n) for n in numbers]
    
    # Tạo danh sách sai (không để phần tử rỗng)
    dssai = [f""]+[f"${latex(simplify(trunggiandung['val'] * si))}$" for si in s]

    return [dsdung, dssai, ycde]

def generate():
    a_val, s_val = random.sample([2, 3, 4, 5, 6], 2)
    
    # Tọa độ các điểm với O là gốc (0,0,0)
    O = Point3D(0, 0, 0)
    S = Point3D(0, 0, s_val)
    A = Point3D(a_val, 0, 0)
    B = Point3D(0, a_val, 0)
    C = Point3D(-a_val, 0, 0)
    D = Point3D(0, -a_val, 0)
    ab=A.distance(B)
    # DANH SÁCH BỘ 4: (Gốc vuông, Đỉnh 1, Đỉnh 2, Đỉnh 3, Tên Gốc, Tên 1, Tên 2, Tên 3)
    cac_bo_diem = [
        (O, A, B, S, "O", "A", "B", "S"),
        (O, B, C, S, "O", "B", "C", "S"),
        (O, C, D, S, "O", "C", "D", "S"),
        (O, D, A, S, "O", "D", "A", "S")
    ]
    
    # Chọn ngẫu nhiên bộ điểm
    bo = random.choice(cac_bo_diem)
    
    # Truyền tham số: bo[0] (tâm O) luôn vào vị trí tham số đầu tiên của hàm xử lý
    dung, sai, ycde = ds_tudien_doimotvuonggoc_dinhday_hoigoc(
        bo[0], bo[1], bo[2], bo[3], 
        ten1=bo[4], ten2=bo[5], ten3=bo[6], ten4=bo[7]
    )
    
    # Trộn đáp án (dung là list, sai là list)
    toan = nhanvao_dsdungsai_rachoice_motdung(dung, sai)

    # Tính độ dài các cạnh để đưa vào đề bài cho sinh động
    canh_day = bo[0].distance(bo[1])
    canh_cao = bo[0].distance(bo[3])

    return rf"""\begin{{ex}}
Cho hình chóp $S.ABCD$ có đáy $ABCD$ là hình vuông tâm ${bo[4]}$.
Biết các cạnh ${bo[4]}{bo[5]}, {bo[4]}{bo[6]}, {bo[4]}{bo[7]}$ đôi một vuông góc với nhau tại ${bo[4]}$.
Cho $AB={latex(ab)}$  và ${bo[4]}{bo[7]} = {latex(canh_cao)}$.
{ycde}
{toan}
\loigiai{{
Xét tứ diện vuông ${bo[4]}.{bo[5]}{bo[6]}{bo[7]}$ vuông tại ${bo[4]}$.
Áp dụng công thức tính góc trong tứ diện vuông, ta có đáp án đúng là {dung[0]}.
}}
\end{{ex}}"""

print(generate())






















