from sympy import symbols, Interval, latex, solveset, S, Eq, Ne, expand, Plane
from sympy.sets import Complement, FiniteSet
import os, re, random
from sympy import Line, Point, symbols, Eq, solve, pi, sqrt
from sympy import symbols, Interval, latex
from sympy import FiniteSet
import os, re
from sympy import Point3D, Line, latex, simplify, Matrix
from sympy.geometry import Point
import sympy as sp
from math import gcd
from functools import reduce
from sympy import Point3D
from sympy.vector import CoordSys3D, cross
from sympy import Matrix, Rational, cos, sin , pi, deg
from decimal import Decimal, ROUND_HALF_UP

# Hệ tọa độ
N = CoordSys3D('N')

x, y, z, t = symbols('x y z t')
# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))
def cdk_tamgiac_hoigoc(B,C,D, ten1="B", ten2="C", ten3="D"):
    r"""hoi goc BCD ten2ten3ten4
"""
    cb=C.distance(B)
    cd=C.distance(D)
    bd=B.distance(D)
    vtCB=B-C
    vtCD=D-C   
    cosBCD=abs((vtCB.dot(vtCD))/(cb*cd))
    kq=cosBCD
    y1=f"Góc giữa ${ten1}{ten2}$ và ${ten2}{ten3}$ là $\\widehat{{ {ten1}{ten2}{ten3} }}$"
    y2=f"${ten1}{ten2}={latex(cb)}$, ${ten2}{ten3}={latex(cd)}$ và ${ten1}{ten3}={latex(bd)}$"
    y3=f"$\\cos{{ \\widehat{{ {ten1}{ten2}{ten3} }} }}={latex(cosBCD)}$  "  
    return [y1,y2,y3,kq]
def tichcohuong(p1, p2):
    N = CoordSys3D('N')
    v1 = p1.x * N.i + p1.y * N.j + p1.z * N.k
    v2 = p2.x * N.i + p2.y * N.j + p2.z * N.k
    result = cross(v1, v2)
    # Lấy hệ số theo từng trục và gom thành tuple
    x = result.dot(N.i)
    y = result.dot(N.j)
    z = result.dot(N.k)
    return Point3D(x, y, z)

def generate():
    b, c, d = random.sample([1,2,3,4,5,6,7], 3)
    A = Point3D(0,0,0)
    B = Point3D(b,0,0)
    C = Point3D(0,c,0)
    D = Point3D(0,0,d)
    I=(B+C)/2

    # Tính độ dài các cạnh
    ab = A.distance(B)
    ac = A.distance(C)
    ad = A.distance(D)

    ci=C.distance(I)
    kq1=ci
    dtDI=Line(D,I)
    A1=dtDI.projection(A)
    aa1=A.distance(A1)
    kq2=aa1
    kq=kq1+kq2
    kq=int(round_half_up(float(kq),0))
    y1=f"$A'A \\perp DI$, $A' \\in DI$"
    y2=f"$BC \\perp (AID)$ và $AA' \\perp (BCD)$"
    y3=f"$x=CI={latex(ci)}$"
    y4=f"$y=AA'={latex(aa1)}$"
    y5=f"$M={latex(ci+aa1)} \\approx {latex(kq)}$"
    loigiai=[y1,y2,y3,y4,y5]
     
    loigiai_str = "\\\\\n".join(loigiai)
    hinhve = rf"""
        \begin{{tikzpicture}}[scale=0.6,yscale=0.7,font=\footnotesize, line join=round, line cap=round, >=stealth] 
         \def \day{{-60}} 
         \def \dinh{{90}} 
         \def \dai{{8}} 
         \def \rong{{5}} 
         \def \cao{{7}}
         
        \path (0,0) coordinate(A) (\dai,0)coordinate(B) 
         ($(A)+(\day:\rong)$)coordinate(C) ($(A)+(\dinh:\cao)$)coordinate(D) 
          ;
         
        \draw (C)--(B)--(D)--(B) (C)--(D)--(C)--(A)--(D) ;
        
        \draw[dashed](A)--(B)    ;
        \path ($(C)!0.4!(B)$)coordinate(I) node[below]{{$I$}};
        \path ($(D)!0.4!(I)$)coordinate(J) node[above right]{{$J$}};
        \draw[dashed](A)--(I) (A)--(J);
         \draw (D)--(I);
        \foreach \i/\g in{{D/180,A/170,B/-90,C/180}}{{ \fill(\i) circle(1.5pt); \path ($(\i)+(\g:0.8)$)node{{$\i$}}; }}
        \end{{tikzpicture}}
    """
    return rf"""\begin{{ex}}
Cho hình chóp $ABCD$ có các cạnh $AB, AC, AD$ đôi một vuông góc với nhau tại $A$.
Biết $AB={latex(ab)}$, $AC={latex(ac)}$ và $AD={latex(ad)}$. 
Có $I \in BC$, $J \in DI$, $AI \perp BC$ và $AJ \perp DI$. 
Gọi $x; y $ lần lượt là khoảng cách từ $C$ đến $(AID)$ và từ $A$ đến $(BCD)$. 
Tính $M={latex(x+y)}$ (làm tròn đến hàng đơn vị)
\shortans{{ ${latex(kq)}$ }}
\loigiai{{
\begin{{center}} {hinhve} \end{{center}}
{loigiai_str}
  }}
\end{{ex}}"""

    
print(generate())
 
