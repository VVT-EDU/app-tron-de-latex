from sympy import symbols, Interval, latex, solveset, S, Eq, Ne, expand, Plane
from sympy.sets import Complement, FiniteSet
import os, re, random
from sympy import Line, Point, symbols, Eq, solve, pi, sqrt
from sympy import symbols, Interval, latex
from sympy import FiniteSet
import os, re
from sympy import Point3D, Line, latex, simplify, Matrix
from sympy.geometry import Point
import sympy as sp
from math import gcd
from functools import reduce
from sympy import Point3D
from sympy.vector import CoordSys3D, cross
from sympy import Matrix, Rational, cos, sin , pi, deg

# Hệ tọa độ
N = CoordSys3D('N')

x, y, z, t = symbols('x y z t')


import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    r"""
    Trộn 2 đúng, 2 sai theo định dạng \choiceTF.
    Đảm bảo chỉ số đã chọn trong danh sách đúng không bị lấy lại từ danh sách sai.
    """
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
        
    # Chọn 2 đúng
    indices_dung = random.sample(range(len(dung)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    
    # Loại bỏ các chỉ số trùng với indices_dung trong danh sách sai
    indices_sai_available = [i for i in range(len(sai)) if i not in indices_dung]
    
    if len(indices_sai_available) < 2:
        return ["Không đủ sai sau khi loại trùng", []]
    
    # Chọn 2 sai từ danh sách đã loại trùng
    indices_sai = random.sample(indices_sai_available, 2)
    selected_sai = [sai[i] for i in indices_sai]
    
    # Gắn nhãn \True cho đúng
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return choice_str
 
import random
from sympy import Rational, latex

def ds_tudien_doimotvuonggoc_dinhday_hoikhoangcach(A,B,C,D, ten1="A", ten2="B", ten3="C", ten4="D"):
 
    ab=A.distance(B)
    ac=A.distance(C)
    ad=A.distance(D)
    bd=B.distance(D)
    cd=C.distance(D)
     
    vtBD=D-B
    vtBA=A-B
    vtCA=C-A
    vtCD=C-D

    cosABD=abs((vtBA.dot(vtBD))/(ab*bd))
    cosACD=abs((vtCA.dot(vtCD))/(ac*cd))
       

    # Các công thức đúng
    y1 = f"Khoảng cách từ ${ten2}$ đến $({ten1}{ten3}{ten4})$ bằng ${latex(ab)}$" 
    y2 = f"Khoảng cách từ ${ten3}$ đến $({ten1}{ten2}{ten4})$ bằng ${latex(ac)}$" 
    y3 = f"Khoảng cách từ ${ten4}$ đến $({ten1}{ten3}{ten2})$ bằng ${latex(ad)}$" 
    y4 = f"Gọi $x_{ten1}$ là góc giữa đường thẳng ${ten4}{ten2}$ và mặt phẳng $({ten1}{ten2}{ten3})$, lúc đó $\\cos{{x_{ten1}}}={latex(cosABD)}$"
    y5 = f"Gọi $y_{ten1}$ là góc giữa đường thẳng ${ten4}{ten3}$ và mặt phẳng $({ten1}{ten2}{ten3})$, lúc đó $\\cos{{x_{ten1}}}={latex(cosACD)}$"
    y6= f"${ten1}{ten2} \\perp ({ten1}{ten3}{ten4})$"
    y7= f"${ten1}{ten3} \\perp ({ten1}{ten2}{ten4})$"
    y8= f"${ten1}{ten4} \\perp ({ten1}{ten3}{ten2})$"
    y9= f"${ten1}{ten2}$ và ${ten3}{ten4}$ là hai đường thẳng vuông góc"
    y10= f"${ten1}{ten4}$ và ${ten3}{ten2}$ là hai đường thẳng vuông góc"
    
    dsdung=[y1, y2, y3, y4, y5, y6, y7,y8,y9,y10]

    # Các công thức sai
    saii = Rational(1, random.choice([2,3,4,5]))
    y1s = f"Khoảng cách từ ${ten2}$ đến $({ten1}{ten3}{ten4})$ bằng ${latex(ab*saii)}$" 
    y2s = f"Khoảng cách từ ${ten3}$ đến $({ten1}{ten2}{ten4})$ bằng ${latex(ac*saii)}$" 
    y3s = f"Khoảng cách từ ${ten4}$ đến $({ten1}{ten3}{ten2})$ bằng ${latex(ad*saii)}$" 
    y4s = f"Gọi $x_{ten1}$ là góc giữa đường thẳng ${ten4}{ten2}$ và mặt phẳng $({ten1}{ten2}{ten3})$,   lúc đó $\\cos{{x_{ten1}}}={latex(cosABD*saii)}$"
    y5s = f"Gọi $y_{ten1}$ là góc giữa đường thẳng ${ten4}{ten3}$ và mặt phẳng $({ten1}{ten2}{ten3})$,   lúc đó $\\cos{{x_{ten1}}}={latex(cosACD*saii)}$"
    y6s= f"${ten1}{ten2} \\perp ({ten2}{ten3}{ten4})$"
    y7s= f"${ten1}{ten3} \\perp ({ten3}{ten2}{ten4})$"
    y8s= f"${ten1}{ten4} \\perp ({ten4}{ten3}{ten2})$"
    y9s= f"${ten1}{ten2}$ và ${ten2}{ten4}$ là hai đường thẳng vuông góc"
    y10s= f"${ten1}{ten4}$ và ${ten3}{ten4}$ là hai đường thẳng vuông góc"
    dssai=[y1s, y2s, y3s, y4s, y5s, y6s, y7s, y8s, y9s, y10s]

    return [dsdung, dssai]

def generate():
    b, d, s = random.sample([1,2,3,4,5,6,7], 3)

    A = Point3D(0,0,0)
    B = Point3D(b,0,0)
    D = Point3D(0,d,0)
    S = Point3D(0,0,s)
    C=B+D-A

    # Tính độ dài các cạnh
    ab = A.distance(B)
    sa = A.distance(S)
    ad = A.distance(D)

    # Lấy danh sách đúng/sai
    # Lấy danh sách đúng/sai

    # Lấy danh sách đúng/sai
    dung1, sai1= ds_tudien_doimotvuonggoc_dinhday_hoikhoangcach(A,B,D,S, ten1="A", ten2="B", ten3="D", ten4="S")
    dung, sai=dung1 , sai1 
    toan = nhanvao_dsdungsai_rachoice_dungsai(dung, sai)

    # Ghép LaTeX
    loigiai_str = "\\\\\n".join(dung)
    return rf"""\begin{{ex}}
Cho hình chóp SABCD có $AB, AD, AS$ đôi một vuông góc với nhau tại $A$.
Đáy $ABCD$ là hình chữ nhật. 
Biết $AB={latex(ab)}$, $AD={latex(ad)}$ và $AS={latex(sa)}$.
\textbf{{Xác định tính đúng sai của mỗi khẳng định sau}}
{toan}
\loigiai{{
{loigiai_str}
}}
\end{{ex}}"""
#\textbf{{Khẳng định nào sau đây là đúng}}
    
print(generate())



























