import random
import math
from sympy import symbols, latex
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP THAM SỐ
    p0_trieu = random.choice([40, 50, 60, 80]) 
    p0 = p0_trieu * 1_000_000
    
    ky_han = 3 # Kỳ hạn 3 tháng
    so_ky_trong_nam = 12 // ky_han
    
    # Giai đoạn 1
    r1_nam = 8.4 
    r1_ky = r1_nam / so_ky_trong_nam / 100
    n1 = 3 
    
    # Giai đoạn 2
    r2_nam = 12.0 
    r2_ky = r2_nam / so_ky_trong_nam / 100
    thang2 = 12 
    n2 = thang2 // ky_han 
    
    # 2. TÍNH TOÁN
    p1 = p0 * (1 + r1_ky)**n1
    p_final = p1 * (1 + r2_ky)**n2
    
    # Làm tròn kết quả đến hàng đơn vị, trả về kiểu int để không có dấu phân cách
    kq_cuoi = int(round_half_up(p_final, 0))
    
    # 3. TRÌNH BÀY ĐỀ BÀI VÀ LỜI GIẢI
    r1_str = str(r1_nam).replace('.', ',')
    r2_str = str(r2_nam).replace('.', ',')
    r1_ky_str = str(round(r1_ky*100, 2)).replace('.', ',')
    r2_ky_str = str(round(r2_ky*100, 2)).replace('.', ',')

    bai_tap = (
        f"Ông An gửi tiết kiệm ${p0_trieu}$ triệu đồng vào ngân hàng với kỳ hạn ${ky_han}$ tháng, "
        f"lãi suất ${r1_str}\\%$ một năm theo hình thức lãi kép. Ông gửi được đúng ${n1}$ kỳ hạn thì "
        f"ngân hàng thay đổi lãi suất, ông gửi tiếp ${thang2}$ tháng nữa với kỳ hạn như cũ và lãi suất "
        f"trong thời gian này là ${r2_str}\\%$ một năm thì ông rút tiền về. Số tiền ông An nhận được "
        f"cả gốc lẫn lãi là bao nhiêu? (đơn vị đồng, làm tròn đến hàng đơn vị)"
    )

    y_list = [
        f"Đợt I, ông An gửi số tiền $P_0 = {p0_trieu}$ triệu đồng, lãi suất ${r1_str}\\%$/năm tức là ${r1_ky_str}\\%$ mỗi kỳ hạn.",
        f"Số tiền cả gốc và lãi ông thu được sau ${n1}$ kỳ hạn là: $P_{{{n1}}} = {int(p0)} \\cdot (1 + {r1_ky:g})^{{{n1}}}$.",
        f"Đợt II, số tiền $P_{{{n1}}}$ được xem là số tiền gửi ban đầu, lãi suất đợt II là ${r2_str}\\%$/năm tức là ${r2_ky_str}\\%$ mỗi kỳ hạn.",
        f"Ông gửi tiếp ${thang2}$ tháng, tương ứng với $n_2 = {thang2} : {ky_han} = {n2}$ kỳ hạn.",
        f"Số tiền thu được cuối cùng là: $P = P_{{{n1}}} \\cdot (1 + {r2_ky:g})^{{{n2}}} = {int(p0)} \\cdot (1 + {r1_ky:g})^{{{n1}}} \\cdot (1 + {r2_ky:g})^{{{n2}}}$.",
        f"Tính toán giá trị: $P \\approx {kq_cuoi}$ (đồng)."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 4. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
{bai_tap}
\shortans{{ ${kq_cuoi}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
