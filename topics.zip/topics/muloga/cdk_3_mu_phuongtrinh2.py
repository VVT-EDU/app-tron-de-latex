import random
from sympy import symbols, Eq, expand, simplify, solveset, latex, Rational
from decimal import Decimal, ROUND_HALF_UP

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THÔNG SỐ
    x = symbols('x')
    a_val = random.choice([2, 3, 4, 5, 6])
    
    # a1 = 1/a, b1 = a
    # Sử dụng Rational để hiển thị phân số đẹp trong LaTeX
    a1_sym = Rational(1, a_val)
    b1_sym = a_val
    
    # mu1 = (x - a)(x + 1)
    # mu2 = (x - a)(x + a)
    mu1 = (x - a_val) * (x + 1)
    mu2 = (x - a_val) * (x + a_val)
    
    # 2. XÂY DỰNG PHƯƠNG TRÌNH
    # pt1: (1/a)^mu1 = a^mu2
    pt1 = Eq(a1_sym**expand(mu1), b1_sym**expand(mu2))
    
    # 3. GIẢI CHI TIẾT
    # Đưa về cùng cơ số a: a^(-mu1) = a^mu2 => -mu1 = mu2
    mu1_expanded = expand(mu1)
    mu1_negated = -mu1_expanded
    mu2_expanded = expand(mu2)
    
    pt_logic = Eq(mu1_negated, mu2_expanded)
    pt_final = simplify(Eq(mu1_negated - mu2_expanded, 0))
    
    # Tìm tập nghiệm
    nghiem = solveset(pt_logic, x)
    danh_sach_nghiem = list(nghiem)
    tong_nghiem = sum(danh_sach_nghiem)
    
    # Kết quả làm tròn
    res_final = int(round_half_up(float(tong_nghiem), 0))
    
    # 4. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Phương trình: ${latex(pt1)}$",
        f"Ta có: $\\left(\\frac{{1}}{{{a_val}}}\\right)^{{{latex(mu1_expanded)}}} = {a_val}^{{{latex(mu2_expanded)}}}$",
        f"$\\Leftrightarrow {a_val}^{{{latex(mu1_negated)}}} = {a_val}^{{{latex(mu2_expanded)}}}$",
        f"$\\Leftrightarrow {latex(mu1_negated)} = {latex(mu2_expanded)}$",
        f"$\\Leftrightarrow {latex(pt_final.lhs)} = 0$",
        f"Tập nghiệm của phương trình là $S = \\{{ {', '.join([latex(n) for n in danh_sach_nghiem])} \\}}$",
        f"Tổng các nghiệm là: $S = {latex(tong_nghiem)}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
Cho phương trình ${latex(pt1)}$. Tính tổng các nghiệm của phương trình đã cho.
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

# Thực thi
if __name__ == "__main__":
    print(generate())
