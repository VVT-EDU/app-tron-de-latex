import random
from sympy import symbols, latex, Rational, simplify
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    factor = Decimal('1') if decimals == 0 else Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP THAM SỐ
    # Số tiền gửi ban đầu (triệu đồng)
    p0_trieu = random.choice([20, 50, 100, 200]) 
    # Lãi suất mỗi năm (%)
    r_num = random.choice([5, 6, 7, 8])
    # Số năm gửi
    n_year = random.choice([2, 3, 5])
    
    # Chuyển sang đơn vị đồng và dùng Rational để tính toán chính xác
    p0_dong = p0_trieu * 1_000_000
    p0 = Rational(p0_dong)
    rate_rational = Rational(r_num, 100)
    
    # 2. TÍNH TOÁN KẾT QUẢ
    # Số tiền sau n năm: P(n) = P0 * (1 + r)^n
    growth_factor = 1 + rate_rational
    pn_val = p0 * (growth_factor**n_year)
    
    kq_so_thuc = float(pn_val.evalf())
    kq_final = int(round_half_up((kq_so_thuc)/1000000, 0))
    
    # 3. TRÌNH BÀY NỘI DUNG
    bai_tap = (
        f"Một người gửi {p0_trieu:,} triệu đồng vào ngân hàng với lãi suất {r_num}% mỗi năm. "
        f"Biết rằng nếu không rút tiền ra khỏi ngân hàng thì cứ sau mỗi năm, số tiền lãi sẽ được nhập vào vốn ban đầu "
        f"để tính lãi cho năm tiếp theo. Tính tổng số tiền người đó nhận được sau {n_year} năm gửi "
        f"(giả sử lãi suất không thay đổi trong suốt thời gian gửi). "
        f"(Kết quả làm tròn đến hàng đơn vị, đơn vị tính: triệu đồng)."
    )

    # Định dạng số có dấu phẩy cho lời giải
    p0_formatted = f"{p0_dong:,}"
    kq_formatted = f"{kq_final:,}"

    # 4. RÁP CHUỖI LATEX
    return rf"""\begin{{ex}}
{bai_tap}
\shortans{{ {kq_final} }}
\loigiai{{
    \begin{{itemize}}
        \item Số tiền gửi ban đầu là: $P_0 = {p0_formatted}$ đồng.
        \item Lãi suất mỗi năm là: $r = {r_num}\% = {latex(rate_rational)}$.
        \item Theo quy tắc sau mỗi năm lãi được nhập vào vốn, số tiền sau mỗi năm sẽ tăng gấp $(1 + r) = {latex(growth_factor)}$ lần so với năm trước đó.
        \item Tổng số tiền người đó nhận được sau {n_year} năm là:
        $P = P_0 \cdot (1 + r)^{{{n_year}}} = {p0_formatted} \cdot \left({latex(growth_factor)}\right)^{{{n_year}}}$ đồng.
        \item Giá trị tính toán: $P = {latex(simplify(pn_val))}$ đồng.
        \item Giá trị xấp xỉ: $P \approx {kq_so_thuc:,.2f}$ đồng.
    \end{{itemize}}
    Làm tròn đến hàng đơn vị, số tiền người đó nhận được là \textbf{{{kq_formatted} triệu đồng}}.
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
