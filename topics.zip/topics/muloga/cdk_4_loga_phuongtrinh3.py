import random
from sympy import symbols, log, Eq, expand, solve, latex, solveset, Interval, oo, Intersection, S, E, simplify
from decimal import Decimal, ROUND_HALF_UP

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THÔNG SỐ
    x = symbols('x')
    h_value = random.randint(1, 3) 
    a_param = h_value + 1
    
    # x1 = x - a*e
    # x2 = x - (a+1)*e
    x1 = x - a_param * E
    x2 = x - (a_param + 1) * E
    
    # 2. ĐIỀU KIỆN XÁC ĐỊNH
    dk1 = solveset(x1 > 0, x, domain=S.Reals)
    dk2 = solveset(x2 > 0, x, domain=S.Reals)
    dk = Intersection(dk1, dk2)
    
    # 3. THIẾT LẬP PHƯƠNG TRÌNH
    bt1 = log(x1)   # ln(x - a*e)
    bt2 = log(x2)   # ln(x - (a+1)*e)
    
    # Phương trình dạng (ln(x1) - a)*(ln(x2) - 1) = 0
    # Khai triển để tạo đề bài
    bt_factor = (bt1 - a_param) * (bt2 - 1)
    pt_hien_thi = Eq(expand(bt_factor), 0)
    
    # 4. GIẢI PHƯƠNG TRÌNH
    # Thừa số 1: ln(x1) = a => x1 = e^a
    pt2a = Eq(bt1, a_param)
    nghiem_a = solve(pt2a, x)
    
    # Thừa số 2: ln(x2) = 1 => x2 = e
    pt2b = Eq(bt2, 1)
    nghiem_b = solve(pt2b, x)
    
    # Tổng hợp nghiệm thô
    nghiem_tho = set(nghiem_a + nghiem_b)
    
    # Lọc nghiệm theo điều kiện
    tap_nghiem = Intersection(dk, nghiem_tho)
    danh_sach_nghiem = list(tap_nghiem)
    tong_nghiem = sum(danh_sach_nghiem)
    
    # 5. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Phương trình đã cho: ${latex(pt_hien_thi)}$",
        f"Điều kiện xác định: ${latex(dk)}$",
        f"Phương trình đưa về dạng tích: ${latex(Eq(bt_factor, 0))}$",
        f"$\\Leftrightarrow \\left[ \\begin{{array}}{{l}} {latex(pt2a)} \\\\ {latex(pt2b)} \\end{{array}} \\right.$",
        f"$\\Leftrightarrow \\left[ \\begin{{array}}{{l}} x = {latex(nghiem_a[0])} \\\\ x = {latex(nghiem_b[0])} \\end{{array}} \\right.$",
        f"Thử lại điều kiện, ta thấy cả hai nghiệm đều thỏa mãn.",
        f"Tập nghiệm $S = \\{{ {', '.join([latex(n) for n in danh_sach_nghiem])} \\}}$",
        f"Vậy tổng các nghiệm là ${latex(tong_nghiem)}$"
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 6. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
Cho phương trình ${latex(pt_hien_thi)}$. Tính tổng các nghiệm thực của phương trình đã cho.
\shortans{{ ${latex(tong_nghiem)}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
