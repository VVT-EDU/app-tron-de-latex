import random
from sympy import symbols, latex, Rational, simplify

def vn_format(number):
    """Định dạng số theo chuẩn Việt Nam, bọc trong $ $."""
    str_num = str(number)
    if '/' in str_num: 
        return f"${latex(number)}$"
    if '.' in str_num:
        parts = str_num.split('.')
        return f"${parts[0]},{parts[1]}$"
    return f"${str_num}$"

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    # m, n là các bậc căn (ví dụ căn bậc 3, căn bậc 4)
    m = random.choice([3, 4, 5])
    n = random.choice([2, 3])
    
    # Số mũ x: 1/2 (căn ngoài) + 1/(2*m) (căn giữa) + 1/(2*m*n) (căn trong)
    exp_x = Rational(1, 2) + Rational(1, 2*m) + Rational(1, 2*m*n)
    
    # k là số mũ ở cơ số: log_{x^k}
    k = random.choice([2, 3])
    
    # Kết quả a = exp_x / k
    a_val = exp_x / k
    
    # 2. LINH ĐỘNG HỆ SỐ T = k_coeff * a + h_coeff
    mau_so = a_val.q # Lấy mẫu số của phân số tối giản
    k_coeff = int(mau_so * random.randint(1, 2))
    h_coeff = random.randint(1, 5)
    
    T_val = int(k_coeff * a_val + h_coeff)
    name = random.choice(['P', 'A', 'M', 'L'])
    
    # 3. TRÌNH BÀY NỘI DUNG
    expr_tex = rf"\log_{{{x}^{{{k}}}}} \left( \sqrt{{{x} \sqrt[{{{m}}}]{{{x} \sqrt[{{{n}}}]{{{x}}}}}}} \right)"
    
    bai_tap = (
        rf"Cho biểu thức ${name} = {expr_tex}$ với $x > 0$ và $x \neq 1$. "
        rf"Biết giá trị của biểu thức ${name}$ bằng $a$. "
        rf"Tính giá trị của biểu thức $T = {k_coeff}a + {h_coeff}$."
    )

    return rf"""\begin{{ex}}
{bai_tap}
\shortans{{ {T_val} }}
\loigiai{{
    Biến đổi biểu thức ${name}$ về dạng lũy thừa của $x$:
    \begin{{itemize}}
        \item Ta có: $\sqrt{{{x} \sqrt[{{{m}}}]{{{x} \sqrt[{{{n}}}]{{{x}}}}}}} = x^{{\frac{{1}}{{2}}}} \cdot x^{{\frac{{1}}{{2 \cdot {m}}}}} \cdot x^{{\frac{{1}}{{2 \cdot {m} \cdot {n}}}}} = x^{{\frac{{1}}{{2}} + \frac{{1}}{{{2*m}}} + \frac{{1}}{{{2*m*n}}}}}$.
        \item Tính tổng số mũ: $\dfrac{{1}}{{2}} + \dfrac{{1}}{{{2*m}}} + \dfrac{{1}}{{{2*m*n}}} = {vn_format(exp_x)}$.
        \item Suy ra: ${name} = \log_{{{x}^{{{k}}}}} \left( x^{{{latex(exp_x)}}} \right) = \dfrac{{{latex(exp_x)}}}{{{k}}} \log_x x$.
        \item Do đó $a = {vn_format(a_val)}$.
        \item Vậy $T = {k_coeff} \cdot {latex(a_val)} + {h_coeff} = {int(k_coeff * a_val)} + {h_coeff} = {T_val}$.
    \end{{itemize}}
    Đáp số: $T = {T_val}$.
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
