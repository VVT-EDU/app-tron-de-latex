import random
import sympy as sp
from sympy import symbols, latex, Rational, sqrt

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    r"""
    Trộn 2 đúng, 2 sai. Trả về [nội dung choiceTF, danh sách các câu đã chọn]
    """
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
        
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    
    # Tạo danh sách hiển thị
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    # Trả về chuỗi choice và danh sách các câu đã chọn để làm lời giải
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Qt6 Scanner Compatible)
# =============================================================================

def generate():
    x = symbols('x')
    m = random.randint(1, 5)
    bac_can = random.choice([2, 4, 6])
    mu_vo_ty = random.choice([sqrt(2), sqrt(3), sqrt(5)])
    mu_vo_ty_latex = latex(mu_vo_ty)
    
    # Định nghĩa nội dung các khẳng định (đã bọc $)
    # Câu đúng
    d1 = f"$B = (x-{m})^{{{mu_vo_ty_latex}}}$ có điều kiện xác định là $x > {m}$"
    d2 = f"$A \\cdot B = (x-{m})^{{\\dfrac{{1}}{{{bac_can}}} + {mu_vo_ty_latex}}}$"
    d3 = f"$\\text{{Điều kiện xác định của }} A = \\sqrt[{bac_can}]{{x-{m}}} \\text{{ là }} x \\ge {m}$"
    d4 = f"$\\text{{Nếu }} A > B \\text{{ thì }} {m} < x < {m+1}$"
    
    # Câu sai
    s1 = f"$\\text{{Điều kiện xác định của }} A \\text{{ là }} x > {m}$"
    s2 = f"$\\text{{Điều kiện xác định của }} B \\text{{ là }} x \\ge {m}$"
    s3 = f"$A \\cdot B = (x-{m})^{{\\dfrac{{{mu_vo_ty_latex}}}{{{bac_can}}}}}$"
    s4 = f"$\\text{{Nếu }} A > B \\text{{ thì }} x > {m+1}$"
    
    dung = [d1, d2, d3, d4]
    sai = [s1, s2, s3, s4]
    
    # Trộn và lấy danh sách đã chọn
    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung, sai)
    
    # --- XÂY DỰNG LỜI GIẢI CHI TIẾT CHO TỪNG PHƯƠNG ÁN ---
    loigiai_items = []
    for item in selected_items:
        is_true = r'\True' in item
        content = item.replace(r'\True ', '')
        
        if content == d1:
            note = f"\\textbf{{Đúng}}. Vì số mũ $\\alpha = {mu_vo_ty_latex}$ không nguyên nên cơ số phải dương: $x-{m} > 0 \\Leftrightarrow x > {m}$."
        elif content == d2:
            note = f"\\textbf{{Đúng}}. Ta có $A \\cdot B = (x-{m})^{{\\frac{{1}}{{{bac_can}}}}} \\cdot (x-{m})^{{{mu_vo_ty_latex}}} = (x-{m})^{{\\frac{{1}}{{{bac_can}}} + {mu_vo_ty_latex}}}$."
        elif content == d3:
            note = f"\\textbf{{Đúng}}. Căn bậc chẵn xác định khi biểu thức dưới dấu căn không âm: $x-{m} \\ge 0 \\Leftrightarrow x \\ge {m}$."
        elif content == d4:
            note = f"\\textbf{{Đúng}}. $A > B \\Leftrightarrow (x-{m})^{{\\frac{{1}}{{{bac_can}}}}} > (x-{m})^{{{mu_vo_ty_latex}}}$. Vì $\\frac{{1}}{{{bac_can}}} < {mu_vo_ty_latex}$ nên $0 < x-{m} < 1 \\Leftrightarrow {m} < x < {m+1}$."
        elif content == s1:
            note = f"\\textbf{{Sai}}. Thiếu trường hợp dấu bằng ($x = {m}$) vì đây là căn bậc chẵn."
        elif content == s2:
            note = f"\\textbf{{Sai}}. Lũy thừa với số mũ vô tỷ không xác định tại cơ số bằng $0$."
        elif content == s3:
            note = f"\\textbf{{Sai}}. Quy tắc nhân hai lũy thừa cùng cơ số là cộng số mũ, không phải nhân số mũ."
        elif content == s4:
            note = f"\\textbf{{Sai}}. Với cơ số $x-{m} > 1$, lũy thừa có số mũ lớn hơn sẽ lớn hơn. Ở đây $\\frac{{1}}{{{bac_can}}} < {mu_vo_ty_latex}$ mà $A>B$ nên cơ số phải thuộc $(0;1)$."
        else:
            note = ""
        
        loigiai_items.append(f"\\itemch {note}")

    # --- RÁP MÃ LATEX ---
    de_bai = f"Cho các biểu thức $A=\\sqrt[{bac_can}]{{x-{m}}}$ và $B=(x-{m})^{{{mu_vo_ty_latex}}}$."
    
    thanhde = f"""\\begin{{ex}}
    {de_bai} \\textbf{{Xác định tính đúng sai của mỗi khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde.replace("\\frac", "\\dfrac")
