import random
from sympy import symbols, exp
from decimal import Decimal, ROUND_HALF_UP

def vn_format(number, decimals=2):
    """Chuyển số sang định dạng Việt Nam và bọc trong $ $."""
    if decimals == 0:
        return f"${int(number):,}$. ".replace(",", ".") # Dấu cách hàng nghìn kiểu Việt
    
    # Làm tròn chuẩn
    factor = Decimal('1') if decimals == 0 else Decimal('1.' + '0' * decimals)
    rounded = Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP)
    
    # Tách phần nguyên và thập phân để thay dấu chấm bằng dấu phẩy
    parts = str(rounded).split('.')
    if len(parts) == 1:
        return f"${parts[0]}$"
    return f"${parts[0]},{parts[1]}$"

def generate():
    # 1. THIẾT LẬP THAM SỐ
    h = symbols('h')
    p0_val = 760 
    k_val = random.choice([-0.12, -0.13, -0.14, -0.15])
    
    mountains = [
        ("Fansipan", 3.1),
        ("Everest", 8.8),
        ("Bà Đen", 1.0),
        ("Langbiang", 2.2)
    ]
    mountain_name, h_val = random.choice(mountains)
    
    # 2. TÍNH TOÁN
    p_func = p0_val * exp(k_val * h)
    p_at_h = p_func.subs(h, h_val)
    kq_so_thuc = float(p_at_h.evalf())
    
    # Định dạng các tham số sang dạng VN trong $ $
    p0_vn = vn_format(p0_val, 0)
    h_vn = vn_format(h_val, 1)
    k_vn = vn_format(k_val, 2)
    kq_final_vn = vn_format(kq_so_thuc, 2)
    
    # 3. TRÌNH BÀY NỘI DUNG
    bai_tap = (
        rf"Áp suất khí quyển $P$ (tính bằng mmHg) tại độ cao $h$ (tính bằng km) so với mực nước biển "
        rf"được tính bởi công thức $P = P_0 \cdot e^{{kh}}$, trong đó $P_0 = {p0_vn}$ mmHg là áp suất tại mực nước biển, "
        rf"$k$ là hệ số suy giảm. Biết rằng tại độ cao {h_vn} km (tương ứng với đỉnh núi {mountain_name}), "
        rf"hệ số $k$ được xác định là {k_vn}. Tính áp suất khí quyển tại đỉnh núi này. "
        f"(Kết quả làm tròn đến hàng phần trăm)."
    )

    return rf"""\begin{{ex}}
{bai_tap}
\shortans{{ {kq_final_vn} mmHg }}
\loigiai{{
    \begin{{itemize}}
        \item Công thức tính áp suất khí quyển là $P = P_0 \cdot e^{{kh}}$.
        \item Thay các giá trị đã biết vào công thức:
        \begin{{itemize}}
            \item $P_0 = {p0_vn}$ mmHg.
            \item $h = {h_vn}$ km.
            \item $k = {k_vn}$.
        \end{{itemize}}
        \item Ta có: $P = {p0_vn} \cdot e^{{{k_vn} \cdot {h_vn}}} \approx {vn_format(kq_so_thuc, 4)}$ mmHg.
    \end{{itemize}}
    Làm tròn đến hàng phần trăm, áp suất khí quyển tại đỉnh {mountain_name} là \textbf{{{kq_final_vn} mmHg}}.
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
