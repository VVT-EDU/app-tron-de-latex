import random

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai theo định dạng \choiceTF."""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Biến đổi biểu thức Logarit - Qt6 Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # Biến số ngẫu nhiên cho các số mũ
    k1 = random.randint(2, 4)
    k2 = random.randint(2, 5)

    # --- CÁC CÂU ĐÚNG ---
    d1 = r"$\mathrm{e}^{\ln a - \ln b} = \dfrac{a}{b}$"
    d2 = f"$\\ln \\sqrt[{{{k1}}}]{{b}} = \\dfrac{{1}}{{{k1}}} \\ln b$"
    d3 = f"$\\ln(a^{k1}b^{k1+k2}) = {k1}\\ln(ab) + {k2}\\ln b$"
    d4 = r"$a \ln \dfrac{1}{b} = \ln(b^{-a})$"
    d5 = r"$\ln \left( \dfrac{a}{b} \right) + \ln \left( \dfrac{b}{a} \right) = 0$"

    # --- CÁC CÂU SAI ---
    s1 = f"$\\ln \\dfrac{{a}}{{\\sqrt[{{{k1}}}]{{b}}}} = \\ln a - {k1}\\ln b$" # Sai vì phải là 1/k1
    s2 = r"$\ln(a+b) = \ln a + \ln b$" # Sai cơ bản: log tổng không bằng tổng log
    s3 = f"$\\mathrm{{e}}^{{{k1}\\ln a}} = {k1}a$" # Sai vì phải là a^k1
    s4 = r"$\ln a^2 = (\ln a)^2$" # Sai vì dấu ngoặc
    s5 = f"$\\ln(a^{k1}) - \\ln(b^{k1}) = {k1} \\ln(a-b)$" # Sai vì phải là ln(a/b)

    dung_list = [d1, d2, d3, d4, d5]
    sai_list = [s1, s2, s3, s4, s5]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 2. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = r"\textbf{Đúng}. $\mathrm{e}^{\ln a - \ln b} = \mathrm{e}^{\ln(a/b)} = \dfrac{a}{b}$."
        elif content == d4:
            note = r"\textbf{Đúng}. $a \ln \frac{1}{b} = a \ln(b^{-1}) = -a \ln b = \ln(b^{-a})$."
        elif content == s2:
            note = r"\textbf{Sai}. Công thức đúng là $\ln(a \cdot b) = \ln a + \ln b$."
        elif content == s4:
            note = r"\textbf{Sai}. $\ln a^2 = 2 \ln a$, không phải $(\ln a)^2$."
        elif "sqrt" in content:
            note = f"\\textbf{{Kiểm tra}}. $\\ln \\sqrt[{{{k1}}}]{{b}} = \\ln b^{{1/{k1}}} = \\frac{{1}}{{{k1}}} \\ln b$."
        else:
            note = r"\textbf{Kiểm tra}. Áp dụng các quy tắc biến đổi lôgarit: tích, thương và lũy thừa."
        loigiai_items.append(f"\\itemch {note}")

    # 3. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Cho $a, b$ là các số thực dương. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde
