import random
import math

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai theo định dạng \choiceTF."""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Bất phương trình Lôgarit ngẫu nhiên - Qt6 Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ NGẪU NHIÊN
    # log_base(mx - n) + log_(1/base)(p - x) <= 0
    # <=> mx - n <= p - x (vì cùng cơ số base > 1)
    # <=> (m+1)x <= p + n <=> x <= (p + n)/(m + 1)
    
    base = random.choice([2, 3, 5])
    m = random.choice([2, 3, 4])
    n = random.randint(2, 6)
    
    # Chọn p sao cho p + n chia hết cho m + 1 để nghiệm đẹp
    # Đồng thời đảm bảo khoảng (n/m; p) tồn tại nghiệm nguyên
    p_candidates = [k for k in range(5, 12) if (k + n) % (m + 1) == 0 and k > n/m + 2]
    if not p_candidates: p_candidates = [7] # Dự phòng
    p = random.choice(p_candidates)
    
    # Tính toán các biên
    low_bound = n/m
    up_bound = (p + n) / (m + 1)
    # up_bound luôn <= p vì mx - n <= p - x và x > n/m
    
    # Đếm số nghiệm nguyên
    nghiem_nguyen = [x for x in range(math.floor(low_bound) + 1, math.ceil(up_bound) + 1) if x <= up_bound]
    count_nghiem = len(nghiem_nguyen)
    
    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # --- CÁC CÂU ĐÚNG ---
    d1 = f"$\\text{{Bất phương trình xác định khi }} \\dfrac{{{n}}}{{{m}}} < x < {p}$"
    d2 = f"$\\text{{Tập nghiệm của bất phương trình có dạng }} S = (a; b] \\text{{ với }} b = {int(up_bound) if up_bound.is_integer() else up_bound}$"
    d3 = f"$\\text{{Bất phương trình đã cho có đúng }} {count_nghiem} \\text{{ nghiệm là số nguyên}}$"
    d4 = f"$\\text{{Giá trị }} x = {nghiem_nguyen[0]} \\text{{ là một nghiệm của bất phương trình}}$"
    d5 = f"$\\text{{Tập nghiệm của bất phương trình là tập con của }} (-\\infty; {int(up_bound) + 1}]$"

    # --- CÁC CÂU SAI ---
    s1 = f"$\\text{{Điều kiện xác định của bất phương trình là }} x > 1$"
    s2 = f"$\\text{{Bất phương trình có tập nghiệm là }} S = [{int(low_bound)}; {int(up_bound)}]$"
    s3 = f"$\\text{{Bất phương trình đã cho vô nghiệm trên tập số nguyên}}$"
    s4 = f"$\\text{{Bất phương trình tương đương với }} {m}x - {n} \\ge {p} - x$" # Sai dấu BPT
    s5 = f"$\\text{{Tập nghiệm của bất phương trình là }} S = (-\\infty; {p})$"

    dung_list = [d1, d2, d3, d4, d5]
    sai_list = [s1, s2, s3, s4, s5]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = f"\\textbf{{Đúng}}. Điều kiện: $mx-n>0$ và $p-x>0 \\Rightarrow \\frac{{{n}}}{{{m}}} < x < {p}$."
        elif content == d3:
            note = f"\\textbf{{Đúng}}. Tập nghiệm là $(\\frac{{{n}}}{{{m}}}; {up_bound}]$, các số nguyên thỏa mãn là: {', '.join(map(str, nghiem_nguyen))}."
        elif content == s4:
            note = f"\\textbf{{Sai}}. Vì cùng cơ số ${base}>1$, $\\log_{{{base}}}({m}x-{n}) \\le \\log_{{{base}}}({p}-x) \\Leftrightarrow {m}x-{n} \\le {p}-x$."
        elif "nghiệm của bất phương trình" in content and "\\True" in item:
            note = f"\\textbf{{Đúng}}. Thay giá trị vào bất phương trình ta thấy thỏa mãn."
        else:
            note = r"\textbf{Kiểm tra}. Giải bất phương trình lôgarit bằng cách đưa về cùng cơ số và kết hợp điều kiện xác định."
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Cho bất phương trình $\\log_{{{base}}} ({m}x - {n}) + \\log_{{\\frac{{1}}{{{base}}}}} ({p} - x) \\le 0$. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde.replace(".", ",")
