import random
from sympy import symbols, latex, Rational, sqrt, simplify
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    factor = Decimal('1') if decimals == 0 else Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP THAM SỐ
    t = symbols('t')
    p0_val = random.choice([1000, 2000, 3000, 4000, 5000])
    ngay = random.choice([4, 6, 8])
    
    # Sử dụng Rational cho tỉ lệ tăng trưởng để chính xác tuyệt đối
    # Ví dụ: 15% -> Rational(15, 100) = 3/20
    rate_num = random.choice([10, 15, 20, 25]) 
    rate_rational = Rational(rate_num, 100)
    
    p0 = Rational(p0_val)
    # P(2) = P0 * (1 + r)
    p2 = simplify(p0 * (1 + rate_rational))
    
    # a^2 = P2/P0 => a = sqrt(P2/P0)
    a_sq_val = p2 / p0
    a_val = sqrt(a_sq_val)
    
    # 2. TÍNH TOÁN KẾT QUẢ
    # P(t) = P0 * a^t
    pt_ngay = p0 * (a_val**ngay)
    kq_so_thuc = float(pt_ngay.evalf())
    kq_final = int(round_half_up(kq_so_thuc, 0))
    
    # 3. TRÌNH BÀY NỘI DUNG
    bai_tap = (
        f"Thực hiện một mẻ nuôi cấy vi khuẩn với ${p0_val}$ vi khuẩn ban đầu. "
        f"Nhà sinh học phát hiện ra số lượng vi khuẩn tăng thêm ${rate_num}\\%$ sau mỗi hai ngày. "
        rf"Công thức $P(t)=P_0 \cdot a^t$ cho phép tính số lượng vi khuẩn sau $t$ ngày kể từ thời điểm ban đầu. "
        f"Xác định các tham số $P_0, a$ và tính số lượng vi khuẩn sau ${ngay}$ ngày. "
        f"(Kết quả làm tròn đến hàng đơn vị)."
    )

    # 4. RÁP CHUỖI LATEX
    return rf"""\begin{{ex}}
{bai_tap}
\shortans{{ ${kq_final}$ }}
\loigiai{{
    \begin{{itemize}}
        \item Tại thời điểm ban đầu ($t=0$), ta có $P(0) = P_0 = {p0_val}$.
        \item Sau hai ngày ($t=2$), số lượng vi khuẩn là: 
        $P(2) = {p0_val} + {rate_num}\% \cdot {p0_val} = {latex(p2)}$.
        \item Theo công thức $P(t) = P_0 \cdot a^t$, ta có: 
        ${p0_val} \cdot a^2 = {latex(p2)} \Rightarrow a^2 = \frac{{{latex(p2)}}}{{{p0_val}}} = {latex(a_sq_val)}$.
        \item Suy ra $a = \sqrt{{{latex(a_sq_val)}}} \approx {float(a_val):.4f}$.
        \item Số lượng vi khuẩn sau ${ngay}$ ngày là: 
        $P({ngay}) = {p0_val} \cdot \left(\sqrt{{{latex(a_sq_val)}}}\right)^{{{ngay}}} = {p0_val} \cdot \left({latex(a_sq_val)}\right)^{{{ngay // 2}}} = {latex(simplify(pt_ngay))}$.
        \item Tính toán giá trị xấp xỉ: $P({ngay}) \approx {kq_so_thuc:.2f}$.
    \end{{itemize}}
    Làm tròn đến hàng đơn vị, ta được kết quả là ${kq_final}$ vi khuẩn.
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
