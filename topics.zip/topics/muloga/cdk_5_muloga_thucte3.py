import random
import math
from sympy import symbols, Eq, solve, latex, Rational, sqrt, simplify, log
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    from decimal import Decimal, ROUND_HALF_UP
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP THAM SỐ
    t = symbols('t')
    soluongbandau = random.choice([1000, 2000, 3000, 4000, 5000])
    tang_rate = random.choice([0.15, 0.20, 0.25]) # Tỉ lệ tăng sau 2 ngày
    
    phantramtang = int(tang_rate * 100)
    p0 = Rational(soluongbandau)
    p2 = simplify(p0 * (1 + tang_rate))
    
    # 2. XÁC ĐỊNH THAM SỐ a
    # P(2) = P0 * a^2 => a = sqrt(p2/p0)
    a_val = sqrt(p2 / p0)
    a_numeric = float(a_val.evalf())
    
    # 3. GIẢI PHƯƠNG TRÌNH GẤP ĐÔI: P(t) = 2*P0
    # p0 * a^t = 2 * p0  => a^t = 2 => t = log(2) / log(a)
    t_solution = math.log(2) / math.log(a_numeric)
    t_min = math.ceil(t_solution) # Lấy số nguyên đầu tiên lớn hơn hoặc bằng
    
    # 4. TRÌNH BÀY LỜI GIẢI
    bai_tap = (
        f"Thực hiện một mẻ nuôi cấy vi khuẩn với ${soluongbandau}$ vi khuẩn ban đầu, "
        f"nhà sinh học phát hiện ra số lượng vi khuẩn tăng thêm ${phantramtang}\\%$ sau mỗi hai ngày. "
        f"Biết công thức tăng trưởng là $P(t)=P_0\\cdot a^t$ ($t$ tính bằng ngày). "
        f"Sau ít nhất bao nhiêu ngày thì số lượng vi khuẩn sẽ vượt gấp đôi số lượng ban đầu?"
    )

    y_list = [
        f"**Bước 1: Xác định các tham số $P_0$ và $a$.**",
        f"Tại $t=0$, ta có $P(0) = P_0 = {soluongbandau}$.",
        f"Tại $t=2$, số lượng vi khuẩn là $P(2) = {soluongbandau} \\cdot (1 + {tang_rate}) = {p2}$.",
        f"Thay vào công thức: ${soluongbandau} \\cdot a^2 = {p2} \\Rightarrow a^2 = {float(p2/p0)} \\Rightarrow a = {latex(a_val)}$.",
        f"**Bước 2: Giải bất phương trình gấp đôi số lượng.**",
        f"Ta cần tìm $t$ sao cho $P(t) \\geq 2P_0 \\Leftrightarrow {soluongbandau} \\cdot ({latex(a_val)})^t \\geq 2 \\cdot {soluongbandau}$.",
        f"$\\Leftrightarrow ({latex(a_val)})^t \\geq 2 \\Leftrightarrow t \\geq \\log_{{{latex(a_val)}}} 2$.",
        f"Tính toán: $t \\geq \\frac{{\\ln 2}}{{\\ln {latex(a_val)}}} \\approx {t_solution:.2f}$.",
        f"**Kết luận:** Vì $t$ là số nguyên nên $t \\geq {t_min}$.",
        f"Vậy sau ít nhất ${t_min}$ ngày thì số lượng vi khuẩn tăng gấp đôi ban đầu."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
{bai_tap}
\shortans{{ ${t_min}$ ngày }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
