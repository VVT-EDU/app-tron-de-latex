import random
from fractions import Fraction
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    """Làm tròn số chuẩn toán học (0.5 lên 1)."""
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def to_latex(frac):
    """Định dạng LaTeX sạch cho phân số và số nguyên."""
    if frac.denominator == 1: return str(frac.numerator)
    num = abs(frac.numerator)
    den = frac.denominator
    sign = "-" if frac.numerator < 0 else ""
    return rf"{sign}\dfrac{{{num}}}{{{den}}}"

def generate():
    # --- PHẦN 1: THIẾT KẾ BIỂU THỨC ---
    # Cụm A (Hằng đẳng thức) -> x^{2k}
    k_frac = random.choice([Fraction(1, 2), Fraction(1, 4), Fraction(3, 4), Fraction(2, 3)])
    two_k = k_frac * 2
    four_k = k_frac * 4
    
    # Cụm B (Căn thức) -> x^{exp_x_B} * y^{exp_y_B}
    m, p = random.randint(2, 3), random.randint(2, 3)
    n, q = random.randint(2, 4), random.randint(2, 4)
    
    exp_x_B = Fraction(n, m) - Fraction(1, p)
    exp_y_B = Fraction(1, m) - Fraction(q, p)
    
    # Số mũ cuối cùng của M = A * B = x^a * y^b
    val_a = two_k + exp_x_B
    val_b = exp_y_B
    
    # --- PHẦN 2: THIẾT LẬP HỆ SỐ h, k VÀ TÍNH TỔNG S ---
    h_coeff = random.randint(2, 5)
    k_coeff = random.randint(2, 5)
    
    # Tính S = h*a + k*b
    val_S_raw = h_coeff * val_a + k_coeff * val_b
    res_final = int(round_half_up(float(val_S_raw), 0))

    # --- PHẦN 3: RÁP LATEX ---
    part_A = rf"\left[ \left( x^{{{to_latex(k_frac)}}} - y^{{{to_latex(k_frac)}}} \right) \left( x^{{{to_latex(k_frac)}}} + y^{{{to_latex(k_frac)}}} \right) + \sqrt{{y^{{{to_latex(four_k)}}}}} \right]"
    part_B = rf"\dfrac{{\sqrt[{{{m}}}]{{x^{{{n}}}y}}}}{{\sqrt[{{{p}}}]{{xy^{{{q}}}}}}}"
    P_tex = rf"{part_A} \cdot {part_B}"

    return rf"""\begin{{ex}}
    Biểu thức $M = {P_tex}$ với $x, y > 0$, được biến đổi thành  $M = x^{{a}}y^{{b}}$. 
    Tính  ${h_coeff}a + {k_coeff}b$ (làm tròn kết quả đến hàng đơn vị).
    \shortans{{ ${res_final}$ }}
    \loigiai{{
        Ta thực hiện rút gọn từng phần của biểu thức $M$:
        \begin{{itemize}}
            \item \textbf{{Rút gọn cụm ngoặc vuông:}}
            \[ A = \left( x^{{{to_latex(k_frac)}}} \right)^2 - \left( y^{{{to_latex(k_frac)}}} \right)^2 + y^{{{to_latex(two_k)}}} = x^{{{to_latex(two_k)}}} - y^{{{to_latex(two_k)}}} + y^{{{to_latex(two_k)}}} = x^{{{to_latex(two_k)}}}. \]
            \item \textbf{{Rút gọn cụm phân thức căn bậc $n$:}}
            \[ B = \dfrac{{x^{{{to_latex(Fraction(n,m))}}} \cdot y^{{{to_latex(Fraction(1,m))}}}}}{{x^{{{to_latex(Fraction(1,p))}}} \cdot y^{{{to_latex(Fraction(q,p))}}}}} = x^{{{to_latex(exp_x_B)}}} \cdot y^{{{to_latex(exp_y_B)}}}. \]
            \item \textbf{{Kết hợp lại:}}
            \[ M = A \cdot B = x^{{{to_latex(two_k)}}} \cdot x^{{{to_latex(exp_x_B)}}} \cdot y^{{{to_latex(exp_y_B)}}} = x^{{{to_latex(val_a)}}} \cdot y^{{{to_latex(val_b)}}}. \]
        \end{{itemize}}
        Từ đó, ta xác định được $a = {to_latex(val_a)}$ và $b = {to_latex(val_b)}$.
        Giá trị biểu thức $S = {h_coeff} \cdot {to_latex(val_a)} + {k_coeff} \cdot \left( {to_latex(val_b)} \right) = {to_latex(val_S_raw)}$.
        Xấp xỉ xấp xỉ ${float(val_S_raw):.3f}$, làm tròn đến hàng đơn vị ta được $S = {res_final}$.
        Đáp án đúng là \textbf{{${res_final}$}}.
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
