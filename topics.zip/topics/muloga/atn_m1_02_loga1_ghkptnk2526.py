import random
from fractions import Fraction

def to_latex(frac):
    """Hiển thị phân số LaTeX tối giản."""
    if frac.denominator == 1:
        return str(frac.numerator)
    num = abs(frac.numerator)
    sign = "-" if frac.numerator < 0 else ""
    return rf"{sign}\dfrac{{{num}}}{{{frac.denominator}}}"

def generate():
    # 1. Tham số toán học
    # Cho log_a(b) = m. Tính log_{a}( (a^n * sqrt[p]{b}) / b^q )
    a_base = random.choice(['a', 'x', 'c'])
    b_val = random.choice(['b', 'y', 'd'])
    
    n = random.randint(2, 3) 
    p = random.randint(4, 6) # Căn bậc p
    q = random.randint(3, 7)
    
    # Kết quả rút gọn: n + (1/p - q) * m
    coeff_m = Fraction(1, p) - Fraction(q)
    
    ten_bt = random.choice(['P', 'Q', 'A', 'M'])
    
    # 2. Chuẩn bị chuỗi LaTeX cho phương án
    # Đáp án đúng: n + (coeff_m)m
    sign_m = "+" if coeff_m >= 0 else ""
    correct_ans = rf"{n} {sign_m} {to_latex(coeff_m)}m"
    
    distractors = set()
    # Nhiễu 1: Nhầm căn bậc p thành lũy thừa p (n + (p-q)m)
    distractors.add(rf"{n} + {to_latex(Fraction(p - q))}m")
    # Nhiễu 2: Quên số hạng n (chỉ còn phần m)
    distractors.add(rf"{to_latex(coeff_m)}m")
    # Nhiễu 3: Sai quy tắc chia (thành nhân: n + (1/p + q)m)
    distractors.add(rf"{n} + {to_latex(Fraction(1, p) + Fraction(q))}m")

    options = [rf"\True ${correct_ans}$"]
    for d in list(distractors)[:3]:
        options.append(rf"${d}$")
    random.shuffle(options)

    # 3. Ráp LaTeX biểu thức "Pro"
    # P = \log_a \left( \frac{a^n \cdot \sqrt[p]{b}}{b^q} \right)
    log_expr = rf"\log_{{{a_base}}} \left( \dfrac{{{a_base}^{{{n}}} \cdot \sqrt[{{{p}}}]{{{b_val}}}}}{{{b_val}^{{{q}}}}} \right)"

    return rf"""\begin{{ex}}
    Cho các số thực dương ${a_base}, {b_val}$ khác $1$, thỏa mãn $\log_{{{a_base}}} {b_val} = m$.
    Tính theo $m$, biểu thức ${log_expr}$ bằng
    \choice
    {{{options[0]}}}
    {{{options[1]}}}
    {{{options[2]}}}
    {{{options[3]}}}
    \loigiai{{
        Biến đổi biểu thức ${ten_bt}$ bằng các tính chất của logarit:
        \begin{{itemize}}
            \item ${ten_bt} = \log_{{{a_base}}} \left( {a_base}^{{{n}}} \cdot {b_val}^{{1/{p}}} \cdot {b_val}^{{-{q}}} \right)$.
            \item ${ten_bt} = \log_{{{a_base}}} \left( {a_base}^{{{n}}} \right) + \log_{{{a_base}}} \left( {b_val}^{{1/{p} - {q}}} \right)$.
            \item ${ten_bt} = {n} + \left( \dfrac{{1}}{{{p}}} - {q} \right) \log_{{{a_base}}} {b_val}$.
            \item Thay $\log_{{{a_base}}} {b_val} = m$, ta được ${ten_bt} = {correct_ans}$.
        \end{{itemize}}
        Vậy đáp án đúng là \textbf{{${correct_ans}$}}.
    }}
\end{{ex}}"""

#print(generate())
