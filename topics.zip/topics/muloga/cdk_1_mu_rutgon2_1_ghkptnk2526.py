import random
from sympy import symbols, sqrt, simplify, factor, latex, Rational
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    if decimals == 0:
        factor_dec = Decimal('1')
    else:
        factor_dec = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor_dec, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP CÁC BIẾN (Dùng positive=True để simplify tốt hơn)
    x = symbols('x', positive=True)
    h_sym, k_sym, t_sym = symbols('h k t')
    
    a = random.choice([2, 4, 6, 8])
    b = random.choice([3, 5, 7, 9])
    c = random.choice([3, 5, 7, 9])
    
    can1 = Rational(1, 2) + a
    can2 = can1 + b
    
    # 2. XÂY DỰNG BIỂU THỨC
    bt1t = x**(can1 + a) + c * x**can1
    bt1m = x**a + c
    bt1 = bt1t / bt1m

    bt2t = x**(can2 + 1) + x**(can2 + 2)
    bt2m = 1 + x
    bt2 = bt2t / bt2m

    bt_sum = bt1 + bt2
    
    # 3. PHÂN TÍCH VÀ TRÍCH XUẤT (Sửa lỗi PolificationFailed)
    bt_final = simplify(bt_sum) # Kết quả sẽ có dạng x^h + x^(h+k)
    bt_factored = factor(bt_final) # Kết quả sẽ có dạng x^h * (1 + x^k)
    
    # Tách h, k, t từ bt_factored
    # bt_factored thường là một đối tượng Mul (Phép nhân)
    if bt_factored.is_Mul:
        # Giả sử bt_factored = x**h * (x**k + 1)
        # args[0] thường là x**h, args[1] là (x**k + 1)
        part_x = bt_factored.args[0]
        part_poly = bt_factored.args[1]
        
        somucuax = part_x.as_powers_dict()[x] # Lấy h
        somucuadathuccuoi = 1 # t mặc định là 1 trong bài này
        
        # Lấy k từ đa thức (x**k + 1)
        # đa thức này là một đối tượng Add, ví dụ: x**4 + 1
        # Lấy tất cả số mũ của x trong các hạng tử và tìm cái lớn nhất
        k_val = max(term.as_powers_dict().get(x, 0) for term in part_poly.args)
    else:
        # Trường hợp hy hữu nếu không phân tích thành nhân tử được
        somucuax = bt_factored.as_powers_dict().get(x, 0)
        k_val = 0
        somucuadathuccuoi = 1

    # 4. TÍNH TỔNG
    tong = somucuax + k_val + somucuadathuccuoi
    res_float = float(tong.evalf())
    res_final = int(round_half_up(res_float, 0))
    
    # 5. TRÌNH BÀY CÂU HỎI
    M_target = x**h_sym * (x**k_sym + 1)**t_sym
    bai = f"Biểu thức $M={latex(bt_sum)}$ với $x$ là số thực dương,  được biến đổi thành $M={latex(M_target)}$."
    cau_hoi = f"{bai} Tính $h + k + t$ (làm tròn kết quả đến hàng đơn vị)."
    
    # 6. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Rút gọn từng phần tử của tổng: $M = {latex(simplify(bt1))} + {latex(simplify(bt2))}$.",
        f"Đặt nhân tử chung: $M = {latex(bt_factored)}$.",
        f"Đối chiếu với dạng $x^h(x^k+1)^t$, ta có: $h={latex(somucuax)}$, $k={latex(k_val)}$, $t={latex(somucuadathuccuoi)}$.",
        f"Suy ra $S = h + k + t = {latex(tong)}$.",
        f"Giá trị làm tròn đến hàng đơn vị là ${res_final}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    content = rf"""\begin{{ex}}
{cau_hoi}
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
