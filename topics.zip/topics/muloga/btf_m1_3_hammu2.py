import random

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai theo định dạng \choiceTF."""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (So sánh cơ số mũ qua đồ thị - Qt6 Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # Dựa trên đặc điểm đồ thị: a > b > 1 > c
    
    d1 = r"$\text{Hàm số } y=a^x \text{ đồng biến trên } \mathbb{R}$"
    d2 = r"$\text{Hàm số } y=c^x \text{ nghịch biến trên } \mathbb{R}$"
    d3 = r"$\text{Tại mốc } x=1, \text{ giá trị } a^1 > b^1 \text{ nên } a > b$"
    d4 = r"$\text{Thứ tự đúng của các cơ số là } a > b > 1 > c > 0$"

    s1 = r"$\text{Hàm số } y=b^x \text{ nghịch biến trên } \mathbb{R}$"
    s2 = r"$\text{Cơ số } c \text{ thỏa mãn điều kiện } c > 1$"
    s3 = r"$\text{Mối quan hệ giữa các cơ số là } b < c$"
    s4 = r"$\text{Đồ thị hàm số } y=c^x \text{ nằm phía trên trục hoành chỉ khi } x > 0$" # Sai vì mũ luôn > 0

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 2. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = r"\textbf{Đúng}. Đồ thị hàm số $y=a^x$ có hướng đi lên từ trái sang phải nên hàm số đồng biến."
        elif content == d2:
            note = r"\textbf{Đúng}. Đồ thị hàm số $y=c^x$ có hướng đi xuống từ trái sang phải nên hàm số nghịch biến."
        elif content == d4:
            note = r"\textbf{Đúng}. Ta có $y=a^x, y=b^x$ đồng biến $\Rightarrow a, b > 1$. Với $x>0$, đồ thị $a^x$ nằm trên $b^x$ nên $a > b$. Hàm $y=c^x$ nghịch biến nên $c < 1$."
        elif content == s1:
            note = r"\textbf{Sai}. Đồ thị $y=b^x$ đi lên nên hàm số phải đồng biến."
        elif content == s3:
            note = r"\textbf{Sai}. Vì $b > 1$ (đồng biến) và $c < 1$ (nghịch biến) nên $b > c$."
        else:
            note = r"\textbf{Kiểm tra}. Dựa vào tính đơn điệu và vị trí tương đối của đồ thị để xác định."
        loigiai_items.append(f"\\itemch {note}")

    # 3. RÁP MÃ LATEX
    # Lưu ý: Phần đồ thị TikZ được giữ nguyên cấu trúc mẫu
    thanh_de = f"""\\begin{{ex}}
    Hình vẽ dưới đây là đồ thị của các hàm số mũ $y=a^x$, $y=b^x$, $y=c^x$. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    \\begin{{center}}
        \\begin{{tikzpicture}}[scale=0.8, font=\\footnotesize, line join=round, line cap=round,>=stealth]
            \\def\\xmin{{-3}};\\def\\ymin{{-0.5}};\\def\\xmax{{3}};\\def\\ymax{{4}};
            \\draw[->] (\\xmin,0)--(\\xmax,0) node[below]{{$x$}};
            \\draw[->] (0,\\ymin)--(0,\\ymax) node[left]{{$y$}};
            \\node at (-0.2,-0.2) {{$O$}};
            \\draw[line width=1pt,color=blue] plot[domain=-3:2.2] (\\x,{{1.5^(\\x)}}) node[right] {{$y=b^x$}};
            \\draw[line width=1pt,color=red] plot[domain=-3:1.4] (\\x,{{2.5^(\\x)}}) node[right] {{$y=a^x$}};
            \\draw[line width=1pt,color=violet] plot[domain=-1.5:3] (\\x,{{0.5^(\\x)}}) node[right] {{$y=c^x$}};
            \\node[left] at (0,1) {{$1$}};
            \\fill (0,1) circle (1.5pt);
        \\end{{tikzpicture}}
    \\end{{center}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanh_de
