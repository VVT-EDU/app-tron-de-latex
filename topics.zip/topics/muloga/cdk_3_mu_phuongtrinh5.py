import random
from sympy import symbols, Eq, expand, simplify, solve, latex, Rational
from decimal import Decimal, ROUND_HALF_UP

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THÔNG SỐ
    x, t = symbols('x t')
    h_value = random.randint(1, 4) # Chọn ngẫu nhiên h_value
    
    a = Rational(h_value + 1)
    # mu1 = 1/2 + a/2, mu2 = 1/2
    mu1 = Rational(1, 2) + a/2
    mu2 = Rational(1, 2)
    
    # Ẩn phụ t = 2^x
    bphu = 2**x
    
    # 2. XÂY DỰNG PHƯƠNG TRÌNH THEO t
    # t1 = t - 2^mu1, t2 = t - 2^mu2
    val_t1 = 2**mu1
    val_t2 = 2**mu2
    
    t1 = t - val_t1
    t2 = t - val_t2
    
    btt = expand(t1 * t2) # Phương trình bậc hai t^2 - (2^mu1 + 2^mu2)t + ...
    ptt = Eq(btt, 0)      # Phương trình t ở dạng khai triển
    ptt1 = Eq(t1 * t2, 0) # Phương trình t ở dạng tích
    
    # Giải tìm t
    ngt = solve(ptt1, t)
    
    # 3. CHUYỂN VỀ PHƯƠNG TRÌNH x
    # Thay t bằng 2^x vào phương trình đã khai triển
    pt1 = ptt.subs(t, bphu)
    
    # Giải tìm x: 2^x = ngt[0] và 2^x = ngt[1]
    nghiem_x = solve(Eq(bphu**2 - (val_t1 + val_t2)*bphu + val_t1*val_t2, 0), x)
    
    # Lọc nghiệm thực và tối giản
    nghiem_x = [simplify(sol) for sol in nghiem_x if sol.is_real]
    tap_nghiem = set(nghiem_x)
    tong_nghiem = sum(tap_nghiem)
    
    # Tính toán giá trị làm tròn
    val_tong = float(tong_nghiem.evalf())
    res_final = int(round_half_up(val_tong, 0))
    
    # 4. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Phương trình đã cho: ${latex(pt1)} = 0$",
        f"Đặt $t = {latex(bphu)}$ ($t > 0$), phương trình trở thành: ${latex(ptt)}$",
        f"$\\Leftrightarrow {latex(ptt1)}$",
        f"$\\Leftrightarrow t = {latex(ngt[0])} \\text{{ hoặc }} t = {latex(ngt[1])}$",
        f"Với $t = {latex(ngt[0])} \\Rightarrow {latex(bphu)} = {latex(ngt[0])} \\Rightarrow x = {latex(solve(Eq(bphu, ngt[0]), x)[0])}$",
        f"Với $t = {latex(ngt[1])} \\Rightarrow {latex(bphu)} = {latex(ngt[1])} \\Rightarrow x = {latex(solve(Eq(bphu, ngt[1]), x)[0])}$",
        f"Tập nghiệm của phương trình là $S = \\{{ {', '.join([latex(n) for n in tap_nghiem])} \\}}$",
        f"Vậy tổng các nghiệm là ${latex(tong_nghiem)}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
Cho phương trình ${latex(pt1)}$. Tính tổng các nghiệm của phương trình đã cho.
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

# Thực thi
if __name__ == "__main__":
    print(generate())
