import random
from fractions import Fraction

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn khẳng định theo chuẩn #deppy."""
    all_indices = random.sample(range(6), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    choices = [r'\True ' + dung[i] for i in idx_dung] + [sai[i] for i in idx_sai]
    random.shuffle(choices)
    return f"\\choiceTF \n {{ {choices[0]} }}\n {{ {choices[1]} }}\n {{ {choices[2]} }}\n {{ {choices[3]} }}"

def to_latex(frac):
    """Xử lý phân số tối giản và số nguyên."""
    if frac.denominator == 1: return str(frac.numerator)
    return rf"\dfrac{{{frac.numerator}}}{{{frac.denominator}}}"

def generate():
    # --- 1. RANDOM THAM SỐ ---
    m, p = 2, 3
    n, q = random.choice([(2, 1), (1, 2), (3, 1)])
    f_A = Fraction(n * p + q, m * p) # Mũ của A
    
    k = random.randint(2, 4) # B = x^k + 1
    
    # Tính toán các giá trị so sánh
    f_inv_A = Fraction(1, f_A) # Nghịch đảo mũ A
    f_ratio = Fraction(k, f_A) # Tỉ số mũ B-1 và A

    # --- 2. DANH SÁCH 6 CẶP ĐỐI ỨNG (THÔNG MINH HƠN) ---
    dung_list = [
        rf"$A^{{{to_latex(f_inv_A)}}} = x$",                                     # Cặp 0: Định nghĩa ngược
        rf"$B - 1 = A^{{{to_latex(f_ratio)}}}$",                                # Cặp 1: Liên hệ A và B
        rf"$\dfrac{{B-1}}{{x^{{{k-1}}}}} = x$",                                 # Cặp 2: Chia lũy thừa
        rf"$(B-1)^2 = x^{{{2*k}}}$",                                            # Cặp 3: Bình phương hóa
        rf"$\dfrac{{1}}{{B-1}} = x^{{{-k}}}$",                                  # Cặp 4: Số mũ âm
        rf"$\text{{Với }} x = 2^{{{m*p}}}, \text{{ biểu thức }} A \text{{ nhận giá trị }} 2^{{{n*p+q}}}$" # Cặp 5: Thay số
    ]
    
    sai_list = [
        rf"$A = x^{{{to_latex(Fraction(n+q, m+p))}}}$",                         # Cặp 0: Sai quy tắc căn lồng
        rf"$B = x^{{{k}}} - 1$",                                                # Cặp 1: Sai dấu hằng đẳng thức
        rf"$B - 1 = x^{{{k+1}}}$",                                              # Cặp 2: Sai bậc
        rf"$(B-1)^2 = x^{{{k**2}}}$",                                           # Cặp 3: Nhầm (x^k)^2 với x^(k^2)
        rf"$\dfrac{{1}}{{B-1}} = -x^{{{k}}}$",                                 # Cặp 4: Sai định nghĩa mũ âm
        rf"$\text{{Với }} x = 1, \text{{ ta có }} A = 0$"                       # Cặp 5: Sai giá trị cơ bản
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 3. ĐỊNH NGHĨA BIỂU THỨC ---
    A_tex = rf"\sqrt[{{{m}}}]{{x^{{{n}}} \cdot \sqrt[{{{p}}}]{{x^{{{q}}}}}}}"
    B_tex = rf"\dfrac{{x^{{{3*k}}} + 1}}{{x^{{{2*k}}} - x^{{{k}}} + 1}}"

    return rf"""\begin{{ex}}
    Cho các biểu thức $A = {A_tex}$ và $B = {B_tex}$ với $x > 0$.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        Rút gọn ta được: $A = x^{{{to_latex(f_A)}}}$ và $B = x^{{{k}}} + 1$.
        Từ đó, $B - 1 = x^{{{k}}}$. 
        Mối liên hệ: $x = A^{{1/({to_latex(f_A)})}} = A^{{{to_latex(f_inv_A)}}}$.
        Suy ra $B - 1 = (A^{{{to_latex(f_inv_A)}}})^{{{k}}} = A^{{{to_latex(f_ratio)}}}$.
    }}
\end{{ex}}"""

#print(generate())
