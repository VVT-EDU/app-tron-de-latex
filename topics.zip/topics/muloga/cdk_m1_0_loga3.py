import random
from sympy import symbols, latex, Rational, simplify, log

def vn_format(number):
    """Định dạng số theo chuẩn Việt Nam, bọc trong $ $."""
    str_num = str(number)
    if '/' in str_num: 
        return f"${latex(number)}$"
    if '.' in str_num:
        parts = str_num.split('.')
        return f"${parts[0]},{parts[1]}$"
    return f"${str_num}$"

def generate():
    # 1. THIẾT LẬP THAM SỐ
    a, b = symbols('a b')
    
    # Thiết kế đẳng thức: a^2 + 4b^2 = 12ab => (a + 2b)^2 = 16ab
    # Hoặc: a^2 + b^2 = 7ab => (a + b)^2 = 9ab
    mode = random.choice(['sum', 'diff'])
    
    if mode == 'sum':
        # Dạng (a+b)^2 = k^2 * ab
        k_val = random.choice([3, 4, 5])
        ab_coeff = k_val**2 - 2
        formula_tex = rf"a^2 + b^2 = {ab_coeff}ab"
        # Logarit cơ số k của (a+b)/k = 1/2 * (log a + log b)
        base = k_val
        expr_inside = rf"\dfrac{{a + b}}{{{base}}}"
        a_coeff, b_coeff = Rational(1, 2), Rational(1, 2)
    else:
        # Dạng (a+2b)^2 = k^2 * ab
        k_val = 4
        ab_coeff = k_val**2 - 4 # = 12
        formula_tex = rf"a^2 + 4b^2 = {ab_coeff}ab"
        base = k_val
        expr_inside = rf"\dfrac{{a + 2b}}{{{base}}}"
        a_coeff, b_coeff = Rational(1, 2), Rational(1, 2)

    # 2. THIẾT KẾ CÂU HỎI T = m*a_coeff + n*b_coeff
    m_val, n_val = random.randint(2, 4), random.randint(2, 4)
    # Vì a_coeff, b_coeff thường là 1/2, ta chọn m, n chẵn để T nguyên
    m = m_val * 2
    n = n_val * 2
    T_result = int(m * a_coeff + n * b_coeff)
    
    name = random.choice(['P', 'S', 'Q', 'K'])

    # 3. TRÌNH BÀY NỘI DUNG (Dùng ngoặc đơn bao quanh toàn bộ rf để tránh lỗi Syntax)
    bai_tap = (
        rf"Cho hai số thực dương $a, b$ thỏa mãn đẳng thức ${formula_tex}$. "
        rf"Biết rằng $\log_{{{base}}} \left( {expr_inside} \right) = x \log_{{{base}}} a + y \log_{{{base}}} b$. "
        rf"Tính giá trị của biểu thức $T = {m}x + {n}y$."
    )

    return rf"""\begin{{ex}}
{bai_tap}
\shortans{{ {T_result} }}
\loigiai{{
    Từ giả thiết ${formula_tex}$, ta biến đổi để tạo ra bình phương một tổng:
    \begin{{itemize}}
        \item Cộng thêm hạng tử phù hợp vào hai vế:
        \item {"$a^2 + 2ab + b^2 = " + str(ab_coeff + 2) + "ab \Rightarrow (a+b)^2 = " + str(base**2) + "ab$" if mode == 'sum' else "$a^2 + 4ab + 4b^2 = 16ab \Rightarrow (a+2b)^2 = 16ab$"}
        \item Suy ra: $\left( {expr_inside} \right)^2 = ab \Rightarrow {expr_inside} = (ab)^{{1/2}}$.
        \item Lấy logarit cơ số ${base}$ hai vế, ta được:
        \item $\log_{{{base}}} \left( {expr_inside} \right) = \log_{{{base}}} (ab)^{{1/2}} = \dfrac{{1}}{{2}} \log_{{{base}}} a + \dfrac{{1}}{{2}} \log_{{{base}}} b$.
        \item Đối chiếu vế phải, ta có $x = \dfrac{{1}}{{2}}$ và $y = \dfrac{{1}}{{2}}$.
        \item Vậy $T = {m} \cdot \dfrac{{1}}{{2}} + {n} \cdot \dfrac{{1}}{{2}} = {T_result}$.
    \end{{itemize}}
    Đáp số: $T = {T_result}$.
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
