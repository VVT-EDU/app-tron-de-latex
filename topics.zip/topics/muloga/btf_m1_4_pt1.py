import random
import math

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai theo định dạng \choiceTF."""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Phương trình Lôgarit ngẫu nhiên - Qt6 Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ NGẪU NHIÊN
    # Phương trình: log_a(x + m) = log_a(x - n) + 1
    # <=> x + m = a(x - n) <=> x + m = ax - an <=> x(a - 1) = m + an
    # => x = (m + an) / (a - 1)
    
    a = random.choice([2, 3]) # Cơ số
    n = random.randint(2, 5) # Điều kiện x > n
    # Chọn m sao cho (m + an) chia hết cho (a-1) để nghiệm nguyên đẹp
    if a == 2:
        m = random.randint(1, 10)
    else: # a = 3, cần m + 3n chẵn
        m = random.choice([k for k in range(1, 11) if (k + 3*n) % 2 == 0])
        
    nghiem = (m + a * n) // (a - 1)
    
    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # --- CÁC CÂU ĐÚNG ---
    d1 = f"$\\text{{Điều kiện xác định của phương trình là }} x > {n}$"
    d2 = f"$\\text{{Phương trình đã cho có duy nhất một nghiệm thực }}$"
    d3 = f"$\\text{{Nghiệm của phương trình là }} x = {nghiem}$"
    d4 = f"$\\text{{Nghiệm }} x_0 \\text{{ của phương trình thỏa mãn }} {nghiem-1} < x_0 < {nghiem+1}$"
    d5 = f"$\\text{{Giá trị }} \\log_{{{nghiem}}} x \\text{{ với }} x \\text{{ là nghiệm của phương trình bằng }} 1$"

    # --- CÁC CÂU SAI ---
    s1 = f"$\\text{{Điều kiện xác định của phương trình là }} x > -{m}$"
    s2 = f"$\\text{{Phương trình đã cho vô nghiệm }}$"
    s3 = f"$\\text{{Nghiệm của phương trình là }} x = {nghiem + random.randint(1,3)}$"
    s4 = f"$\\text{{Tổng các nghiệm của phương trình bằng }} 0$"
    s5 = f"$\\text{{Nghiệm của phương trình là một số âm }}$"

    dung_list = [d1, d2, d3, d4, d5]
    sai_list = [s1, s2, s3, s4, s5]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = f"\\textbf{{Đúng}}. Điều kiện: $x+{m}>0$ và $x-{n}>0 \\Rightarrow x>{n}$."
        elif content == d2:
            note = f"\\textbf{{Đúng}}. Phương trình đưa về bậc nhất $x+{m} = {a}(x-{n})$ nên có nghiệm duy nhất."
        elif content == d3:
            note = f"\\textbf{{Đúng}}. Ta có $x+{m} = {a}x - {a*n} \\Leftrightarrow {a-1}x = {m+a*n} \\Leftrightarrow x={nghiem}$."
        elif content == s1:
            note = f"\\textbf{{Sai}}. Điều kiện xác định là giao của hai tập, phải lấy giá trị lớn hơn ($x > {n}$)."
        elif content == s2:
            note = f"\\textbf{{Sai}}. Phương trình có nghiệm $x={nghiem}$ thỏa mãn điều kiện $x > {n}$."
        else:
            note = r"\textbf{Kiểm tra}. Giải phương trình bằng cách đưa về cùng cơ số và so sánh với điều kiện xác định."
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Cho phương trình $\\log_{{{a}}}(x+{m})=\\log_{{{a}}}(x-{n})+1$. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde.replace(".", ",")
