import random
from sympy import symbols, log, Eq, expand, solve, latex, solveset, Interval, oo, Intersection, S, logcombine, simplify
from decimal import Decimal, ROUND_HALF_UP

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THÔNG SỐ
    x = symbols('x')
    h_value = random.randint(1, 5) 
    a = h_value
    
    # Biểu thức trong logarit
    # x1 = x + a + 1
    # x2 = 4 - x
    # x3 = 2*(x+a)*(3-x) + 4 + a
    x1 = expand((x + a) + 1)
    x2 = expand((3 - x) + 1)
    x3 = expand(2 * (x + a) * (3 - x) + 1 + 3 + a)
    
    # 2. ĐIỀU KIỆN XÁC ĐỊNH
    dk1 = solveset(x1 > 0, x, domain=S.Reals)
    dk2 = solveset(x2 > 0, x, domain=S.Reals)
    dk3 = solveset(x3 > 0, x, domain=S.Reals)
    dk = Intersection(dk1, dk2, dk3)
    
    # 3. THIẾT LẬP PHƯƠNG TRÌNH
    bt1 = log(x1)
    bt2 = log(x2)
    bt3 = log(x3)
    pt = Eq(bt1 + bt2, bt3)
    
    # Biến đổi: log(x1) + log(x2) = log(x1*x2)
    bt_combined = logcombine(bt1 + bt2, force=True)
    pt_combined = Eq(bt_combined, bt3)
    
    # Phương trình hệ quả: x1 * x2 = x3
    arg_left = bt_combined.args[0]
    pt_he_qua = Eq(arg_left, x3)
    
    # Rút gọn phương trình: x1*x2 - x3 = 0
    don = simplify(arg_left - x3)
    pt_rut_gon = Eq(don, 0)
    
    # 4. GIẢI VÀ KIỂM TRA ĐIỀU KIỆN
    nghiem_tho = solve(pt_rut_gon, x)
    nghiem_set = set(nghiem_tho)
    
    # Lọc nghiệm thuộc tập xác định
    tap_nghiem_thuc = Intersection(dk, nghiem_set)
    danh_sach_nghiem = list(tap_nghiem_thuc)
    tong_nghiem = sum(danh_sach_nghiem)
    
    # Kết quả số học
    val_tong = float(tong_nghiem.evalf())
    res_final = int(round_half_up(val_tong, 0))
    
    # 5. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Phương trình đã cho: ${latex(pt)}$",
        f"Điều kiện xác định: $x \\in {latex(dk)}$",
        f"Sử dụng công thức cộng logarit: ${latex(pt_combined)}$",
        f"$\\Leftrightarrow {latex(pt_he_qua)}$",
        f"$\\Leftrightarrow {latex(pt_rut_gon)}$",
        f"$\\Leftrightarrow x \\in {latex(nghiem_set)}$",
        f"Đối chiếu điều kiện, ta có tập nghiệm $S = {latex(tap_nghiem_thuc)}$",
        f"Vậy tổng các nghiệm bằng ${latex(tong_nghiem)}$"
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 6. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
Cho phương trình ${latex(pt)}$. Tính tổng các nghiệm của phương trình đã cho.
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
