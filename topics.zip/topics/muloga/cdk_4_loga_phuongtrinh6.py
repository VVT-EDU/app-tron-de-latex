import random
from sympy import symbols, log, Eq, expand, solve, latex, solveset, Interval, oo, Intersection, S, sqrt, simplify, FiniteSet

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    from decimal import Decimal, ROUND_HALF_UP
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THAM SỐ
    x = symbols('x')
    h_value = random.randint(1, 3)
    a = 2 * h_value + 1  # a là số lẻ > 1
    
    # Biểu thức trong phương trình
    bt1 = a * x
    bt2 = 2 * bt1 + 1
    bt22 = sqrt(bt2)
    
    # 2. TÌM ĐIỀU KIỆN XÁC ĐỊNH (DK)
    dk1 = solveset(bt1 > 0, x, domain=S.Reals)
    dk2 = solveset(bt2 > 0, x, domain=S.Reals)
    dk = Intersection(dk1, dk2)
    
    # 3. THIẾT LẬP PHƯƠNG TRÌNH VÀ CÁC BƯỚC GIẢI
    # log_a(bt1) - log_a(bt1) * log_{a+1}(bt22) = 0
    bai_latex = f"\\log_{{{a}}}{{({latex(bt1)})}} - \\log_{{{a}}}{{({latex(bt1)})}} \\cdot \\log_{{{a+1}}}{{({latex(bt22)})}} = 0"
    
    # Bước 1: Đặt nhân tử chung
    y1 = f"$\\Leftrightarrow \\log_{{{a}}}{{({latex(bt1)})}} \\cdot \\left[ 1 - \\log_{{{a+1}}}{{({latex(bt22)})}} \\right] = 0$"
    
    # Bước 2: Tách thành phương trình tích
    y2 = f"$\\Leftrightarrow \\left[ \\begin{{array}}{{l}} \\log_{{{a}}}{{({latex(bt1)})}} = 0 \\\\ \\log_{{{a+1}}}{{({latex(bt22)})}} = 1 \\end{{array}} \\right.$"
    
    # Bước 3: Giải phương trình cơ bản
    y3 = f"$\\Leftrightarrow \\left[ \\begin{{array}}{{l}} {latex(bt1)} = 1 \\\\ {latex(bt22)} = {a+1} \\end{{array}} \\right.$"
    
    # Bước 4: Tìm x
    pt1 = Eq(bt1, 1)
    pt2 = Eq(bt2, (a+1)**2) # Bình phương hai vế
    nghiem1 = solve(pt1, x)
    nghiem2 = solve(pt2, x)
    
    y4 = f"$\\Leftrightarrow \\left[ \\begin{{array}}{{l}} x = {latex(nghiem1[0])} \\\\ x = {latex(nghiem2[0])} \\end{{array}} \\right.$"
    
    # 4. KIỂM TRA ĐIỀU KIỆN VÀ TÍNH TỔNG
    nghiem_all = FiniteSet(nghiem1[0], nghiem2[0])
    tap_nghiem = Intersection(dk, nghiem_all)
    danh_sach_nghiem = list(tap_nghiem)
    tong_nghiem = sum(danh_sach_nghiem)
    
    # 5. TỔNG HỢP LỜI GIẢI
    y_list = [
        f"Phương trình: ${bai_latex}$",
        f"Điều kiện xác định: $x \\in {latex(dk)}$",
        y1,
        y2,
        y3,
        y4,
        f"Đối chiếu điều kiện, ta thấy cả hai nghiệm đều thỏa mãn.",
        f"Tập nghiệm $S = \\{{ {', '.join([latex(n) for n in danh_sach_nghiem])} \\}}$",
        f"Vậy tổng các nghiệm là ${latex(tong_nghiem)}$"
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 6. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
Cho phương trình ${bai_latex}$. Tính tổng các nghiệm của phương trình đã cho.
\shortans{{ ${latex(tong_nghiem)}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
