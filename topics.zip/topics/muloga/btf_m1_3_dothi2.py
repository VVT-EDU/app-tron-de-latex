import random

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai theo định dạng \choiceTF."""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (So sánh tính chất Mũ và Lôgarit - Qt6 Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # --- CÁC CÂU ĐÚNG ---
    d1 = r"$\text{Đồ thị hàm số } y=\log_ax \text{ luôn nằm bên phải trục tung (nhận } Oy \text{ làm tiệm cận đứng)}$"
    d2 = r"$\text{Hàm số } y=a^x \text{ và } y=\log_ax \text{ luôn có cùng tính đơn điệu trên tập xác định của chúng}$"
    d3 = r"$\text{Đồ thị của hai hàm số } y=a^x \text{ và } y=\log_ax \text{ đối xứng với nhau qua đường thẳng } y=x$"
    d4 = r"$\text{Tập giá trị của hàm số } y=a^x \text{ là tập xác định của hàm số } y=\log_ax$"
    d5 = r"$\text{Với } 0 < a < 1, \text{ hàm số } y=a^x \text{ nghịch biến trên khoảng } (-\infty; +\infty)$"

    # --- CÁC CÂU SAI ---
    s1 = r"$\text{Hàm số } y=\log_ax \text{ và hàm số } y=a^x \text{ có cùng tập giá trị}$"
    s2 = r"$\text{Đồ thị hàm số } y=a^x \text{ luôn đi qua điểm } A(a; 1)$" # Phải là (0;1) hoặc (1;a)
    s3 = r"$\text{Đồ thị hàm số } y=\log_ax \text{ luôn cắt trục tung tại điểm } (0; 1)$" # Phải là trục hoành tại (1;0)
    s4 = r"$\text{Hàm số } y=\log_ax \text{ xác định với mọi số thực } x$"
    s5 = r"$\text{Với } a > 1, \text{ đồ thị hàm số } y=\log_ax \text{ nằm phía dưới trục hoành khi } x > 1$"

    dung_list = [d1, d2, d3, d4, d5]
    sai_list = [s1, s2, s3, s4, s5]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 2. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = r"\textbf{Đúng}. Vì điều kiện xác định là $x > 0$."
        elif content == d2:
            note = r"\textbf{Đúng}. Cả hai hàm đều đồng biến nếu $a > 1$ và nghịch biến nếu $0 < a < 1$."
        elif content == d3:
            note = r"\textbf{Đúng}. Đây là tính chất của hai hàm số ngược nhau."
        elif content == d4:
            note = r"\textbf{Đúng}. Tập giá trị của hàm mũ là $(0;+\infty)$, cũng là tập xác định của hàm lôgarit."
        elif content == s1:
            note = r"\textbf{Sai}. Tập giá trị của $y=a^x$ là $(0;+\infty)$, còn của $y=\log_ax$ là $\mathbb{R}$."
        elif content == s2:
            note = r"\textbf{Sai}. Đồ thị hàm số $y=a^x$ luôn đi qua điểm $(0;1)$."
        elif content == s3:
            note = r"\textbf{Sai}. Hàm lôgarit không cắt trục tung, nó cắt trục hoành tại $(1;0)$."
        else:
            note = r"\textbf{Kiểm tra}. Dựa vào các định nghĩa về tập xác định, tập giá trị và đồ thị của hàm mũ và lôgarit."
        loigiai_items.append(f"\\itemch {note}")

    # 3. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Cho các hàm số $y=\\log_{{a}}x$ và $y=a^x$ với $a$ là số thực dương khác $1$. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde
