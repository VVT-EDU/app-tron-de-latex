import random
from sympy import symbols, latex, Rational

def generate():
    # 1. THIẾT LẬP THAM SỐ
    # Chọn cơ số c (thường là 2, 3 hoặc 5)
    c = random.choice([2, 3])
    
    # Chọn nghiệm x1, x2 (đây chính là a và b) để x1 < x2
    # Thường chọn các số nguyên nhỏ để 5a + 3b không quá lớn
    x1 = random.choice([0, 1])
    x2 = x1 + random.choice([1, 2])
    
    a_val = x1
    b_val = x2
    
    # Tính các nghiệm của biến phụ t = c^x
    t1 = c**x1
    t2 = c**x2
    
    # Tổng S và Tích P của phương trình bậc hai t^2 - St + P = 0
    S = t1 + t2
    P = t1 * t2
    
    # Hệ số cho biểu thức ma + nb
    m = random.choice([2, 3, 4, 5])
    n = random.choice([2, 3, 4, 5])
    ket_qua = m * a_val + n * b_val
    
    # 2. TRÌNH BÀY ĐỀ BÀI
    # BPT dạng: c^x < S - P/(c^x)
    bai_tap = (
        f"Biết tập nghiệm của bất phương trình ${c}^x < {S} - \\dfrac{{{P}}}{{{c}^x}}$ là $(a; b)$. "
        f"Giá trị ${m}a + {n}b$ bằng bao nhiêu?"
    )

    # 3. TRÌNH BÀY LỜI GIẢI
    y_list = [
        rf"Bất phương trình tương đương với: $({c}^x)^2 - {S} \cdot ({c}^x) + {P} < 0$.",
        rf"Đặt $t = {c}^x$ ($t > 0$), ta có bất phương trình: $t^2 - {S}t + {P} < 0$.",
        rf"Xét phương trình $t^2 - {S}t + {P} = 0$ có hai nghiệm $t = {t1}$ và $t = {t2}$.",
        rf"Do đó $t^2 - {S}t + {P} < 0 \Leftrightarrow {t1} < t < {t2}$.",
        rf"Suy ra ${t1} < {c}^x < {t2} \Leftrightarrow {x1} < x < {x2}$.",
        rf"Tập nghiệm của bất phương trình là $S = ({a_val}; {b_val})$.",
        rf"Vậy $a = {a_val}$, $b = {b_val}$ nên ${m}a + {n}b = {m} \cdot {a_val} + {n} \cdot {b_val} = {ket_qua}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 4. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
    {bai_tap}
   \shortans{{{ket_qua}}}
    \loigiai{{
        \allowdisplaybreaks
        {loigiai_latex}
    }}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
