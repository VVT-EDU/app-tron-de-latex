import random
from fractions import Fraction

def to_latex(frac, is_exponent=False):
    """Hiển thị phân số LaTeX tối giản. is_exponent=True dùng cho số mũ."""
    if frac.denominator == 1:
        return str(frac.numerator)
    return rf"\frac{{{frac.numerator}}}{{{frac.denominator}}}"

def generate():
    name = random.choice(['K', 'M', 'N', 'P', 'Q', 'H'])
    m = random.choice([2, 3,4,5,6])
    
    # Chuẩn bị tên biến để tránh lỗi SyntaxWarning \i
    item_symbol = r"\item"
    
    if m == 2:
        # K = (x - y)/(sqrt(x) + sqrt(y)) + sqrt(y) = sqrt(x)
        P_tex = rf"\dfrac{{x - y}}{{\sqrt{{x}} + \sqrt{{y}}}} + \sqrt{{y}}"
        res_a, res_b = Fraction(1, 2), Fraction(0)
        simplify_step = rf"{item_symbol} Với $m=2$: $x-y = (\sqrt{{x}}-\sqrt{{y}})(\sqrt{{x}}+\sqrt{{y}})$"
        res_final_text = r"\sqrt{x}"
    else:
        # K = (x - y)/(x^{1/3} - y^{1/3}) - \sqrt[3]{xy} = x^{2/3} + y^{2/3}
        f1_3 = to_latex(Fraction(1, 3))
        P_tex = rf"\dfrac{{x - y}}{{x^{{{f1_3}}} - y^{{{f1_3}}}}} - \sqrt[3]{{xy}}"
        res_a, res_b = Fraction(2, 3), Fraction(2, 3)
        simplify_step = rf"{item_symbol} Với $m=3$: $x-y = (x^{{1/3}}-y^{{1/3}})(x^{{2/3}} + x^{{1/3}}y^{{1/3}} + y^{{2/3}})$"
        res_final_text = rf"x^{{{to_latex(res_a)}}} + y^{{{to_latex(res_b)}}}"

    # Tính T = ma*a + nb*b
    ma, nb = random.randint(2, 3), random.randint(2, 3)
    val_S = ma * res_a + nb * res_b
    lt_S = to_latex(val_S)
    
    # Tạo danh sách lựa chọn (Gán \True chuẩn xác)
    distractors = [to_latex(val_S + 1), to_latex(val_S - 1), to_latex(Fraction(1, 3))]
    choices = [rf"\True ${lt_S}$"] + [rf"$ {d}$" for d in distractors]
    random.shuffle(choices)

    return rf"""\begin{{ex}}
    Biểu thức $ {P_tex}$ với $x, y > 0, x \neq y$, 
      được biến đổi về dạng $x^{{a}} + y^{{b}}$. 
    Giá trị của biểu thức $ {ma}a + {nb}b$ bằng
    \choice
    {{{choices[0]}}}
    {{{choices[1]}}}
    {{{choices[2]}}}
    {{{choices[3]}}}
    \loigiai{{
        Sử dụng hằng đẳng thức cho lũy thừa hữu tỉ:
        \begin{{itemize}}
            {item_symbol} Ta có $x - y = (x^{{1/{m}}})^{{{m}}} - (y^{{1/{m}}})^{{{m}}}$.
            {simplify_step}
            {item_symbol} Rút gọn phân thức ta được: ${name} = {res_final_text}$.
            {item_symbol} Suy ra $a = {to_latex(res_a)}$ và $b = {to_latex(res_b)}$.
            {item_symbol} Vậy $T = {ma} \cdot {to_latex(res_a)} + {nb} \cdot {to_latex(res_b)} = {lt_S}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

print(generate())
