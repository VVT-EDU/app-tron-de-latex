import random
from sympy import symbols, sqrt, simplify, factor, latex, Rational, Add, Mul
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    if decimals == 0:
        factor_dec = Decimal('1')
    else:
        factor_dec = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor_dec, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN
    x = symbols('x', positive=True)
    h_sym, k_sym, t_sym = symbols('h k t')
    
    # Tham số ngẫu nhiên
    m = random.choice([2, 3, 4]) # Bậc căn
    
    # 2. XÂY DỰNG 3 CỤM BIỂU THỨC
    # Cụm 1: Phân thức rút gọn -> x^a_frac
    a_frac = Rational(random.randint(1, 5), m)
    c1 = random.randint(2, 6)
    bt1_t = x**(a_frac + 1) + c1 * x**a_frac
    bt1_m = x + c1
    bt1 = bt1_t / bt1_m 

    # Cụm 2: Căn thức lồng -> x^(a_frac + k_val)
    k_val = random.randint(1, 2)
    # Tạo biểu thức căn thức bậc m
    # bt2_expr = sqrt[m](x^(m*(k+a)))
    bt2_inner = x**(m * (k_val + a_frac))
    
    # Cụm 3: Đơn thức đồng dạng để nhóm
    coeff_bt3 = random.randint(2, 5)
    bt3 = (coeff_bt3 - 1) * x**a_frac
    
    # Tổng thực tế M = bt1 + bt2 + bt3
    bt_sum = bt1 + x**(k_val + a_frac) + bt3
    
    # 3. PHÂN TÍCH KẾT QUẢ
    bt_final = simplify(bt_sum) 
    bt_factored = factor(bt_final) 
    
    h_val = 0
    k_val_final = 0
    t_val = 1
    
    # Trích xuất h, k từ kết quả factor: dạng const * x^h * (x^k + const)
    if bt_factored.is_Mul:
        for arg in bt_factored.args:
            if arg.is_Pow and arg.base == x:
                h_val = arg.exp
            elif arg == x:
                h_val = 1
            elif isinstance(arg, Add):
                # Lấy số mũ lớn nhất của x trong ngoặc
                k_val_final = max(term.as_powers_dict().get(x, 0) for term in arg.args)
    
    # 4. TÍNH TỔNG S
    tong_S = h_val + k_val_final + t_val
    res_final = int(round_half_up(float(tong_S.evalf()), 0))

    # 5. TRÌNH BÀY CÂU HỎI
    # Biểu thức hiển thị (dùng Latex thủ công cho phần căn thức để đẹp hơn)
    P_tex = (rf"\dfrac{{x^{{{latex(a_frac + 1)}}} + {c1}x^{{{latex(a_frac)}}}}}{{x + {c1}}} " 
             rf"+ \sqrt[{(m)}]{{{latex(bt2_inner)}}} " 
             rf"+ {coeff_bt3 - 1}x^{{{latex(a_frac)}}}")

    # SỬA LỖI TẠI ĐÂY: Loại bỏ dấu {} quanh coeff_bt3
    M_target = x**h_sym * (x**k_sym + coeff_bt3)**t_sym
    
    cau_hoi = (rf"Cho biểu thức $M = {P_tex}$ với $x > 0$. "
               rf"Biến đổi ta được $M = {latex(M_target)}$. "
               rf"Tính $ h + k + t$ (làm tròn kết quả đến hàng đơn vị).")

    # 6. LỜI GIẢI
    y_list = [
        rf"Bước 1: Rút gọn cụm phân thức: $M_1 = \dfrac{{x^{{{latex(a_frac)}}}(x + {c1})}}{{x + {c1}}} = x^{{{latex(a_frac)}}}$.",
        rf"Bước 2: Rút gọn cụm căn thức: $M_2 = \sqrt[{(m)}]{{x^{{{m}({latex(k_val + a_frac)})}}}} = x^{{{latex(k_val + a_frac)}}}$.",
        rf"Bước 3: Thay vào biểu thức tổng: $M = x^{{{latex(a_frac)}}} + x^{{{latex(k_val + a_frac)}}} + {coeff_bt3 - 1}x^{{{latex(a_frac)}}}$.",
        rf"Bước 4: Nhóm các đơn thức đồng dạng: $M = {coeff_bt3}x^{{{latex(a_frac)}}} + x^{{{latex(k_val + a_frac)}}}$.",
        rf"Bước 5: Đặt nhân tử chung: $M = x^{{{latex(a_frac)}}}(x^{{{k_val}}} + {coeff_bt3})$.",
        rf"Đối chiếu dạng $x^h(x^k+c)^t$: $h = {latex(h_val)}$, $k = {k_val}$, $t = {t_val}$.",
        rf"Suy ra $S = {latex(h_val)} + {k_val} + {t_val} = {latex(tong_S)}$.",
        rf"Làm tròn đến hàng đơn vị, kết quả là: \textbf{{${res_final}$}}."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    return rf"""\begin{{ex}}
{cau_hoi}
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
