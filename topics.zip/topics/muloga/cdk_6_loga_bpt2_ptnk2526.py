import random
import math
from sympy import symbols, latex
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    
    # Chọn cơ số a > 1 (thường chọn 2 hoặc 3)
    a = random.choice([2, 3])
    
    # Thiết lập bất phương trình dạng: log_a(x^2 - mx) <= k
    k = random.randint(2, 3)
    val_ak = a**k 
    
    # Tìm m sao cho phương trình x^2 - mx - val_ak = 0 có nghiệm nguyên
    # delta = m^2 + 4*val_ak phải là số chính phương
    valid_m = []
    for m_test in range(1, 10):
        delta_test = m_test**2 + 4 * val_ak
        root = math.isqrt(delta_test)
        if root * root == delta_test: # Kiểm tra số chính phương đúng cách
            valid_m.append(m_test)
    
    # Nếu không tìm thấy m đẹp, mặc định lấy bộ số chuẩn
    if not valid_m:
        m = 2
        a = 2
        k = 3
        val_ak = 8
    else:
        m = random.choice(valid_m)

    # 2. GIẢI TOÁN
    delta = m**2 + 4 * val_ak
    root_delta = math.isqrt(delta)
    
    # Nghiệm của x^2 - mx - val_ak = 0
    x1 = int((m - root_delta) / 2)
    x2 = int((m + root_delta) / 2)
    
    # Kết hợp điều kiện x < 0 hoặc x > m
    nghiem_nguyen = []
    for i in range(x1, 0):
        nghiem_nguyen.append(i)
    for i in range(m + 1, x2 + 1):
        nghiem_nguyen.append(i)
        
    so_nghiem = len(nghiem_nguyen)

    # 3. TRÌNH BÀY ĐỀ BÀI
    bai_tap = f"Có bao nhiêu số nguyên là nghiệm của bất phương trình $\\log_{{{a}}}(x^2 - {m}x) \\le {k}$?"

    # 4. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Điều kiện xác định: $x^2 - {m}x > 0 \\Leftrightarrow x(x - {m}) > 0 \\Leftrightarrow \\left[ \\begin{{array}}{{l}} x < 0 \\\\ x > {m} \\end{{array}} \\right.$ (*)",
        f"Bất phương trình tương đương với: $x^2 - {m}x \\le {a}^{{{k}}}$",
        f"$\\Leftrightarrow x^2 - {m}x - {val_ak} \\le 0$",
        f"Xét phương trình $x^2 - {m}x - {val_ak} = 0$, ta có các nghiệm là $x = {x1}$ và $x = {x2}$.",
        f"Suy ra tập nghiệm của bất phương trình bậc hai là $S_1 = [{x1}; {x2}]$.",
        f"Kết hợp với điều kiện (*), ta được tập nghiệm của bất phương trình đã cho là: $S = [{x1}; 0) \\cup ({m}; {x2}]$.",
        f"Các nghiệm nguyên của bất phương trình là: $x \\in \\{{ {', '.join(map(str, nghiem_nguyen))} \\}}$.",
        f"Vậy có tất cả ${so_nghiem}$ nghiệm nguyên thỏa mãn."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
{bai_tap}
\shortans{{ ${so_nghiem}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
