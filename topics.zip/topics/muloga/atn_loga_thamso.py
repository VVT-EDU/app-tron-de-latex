import random
from sympy import symbols, solve, Rational, latex, log

def nhanvao_dsdungsai_rachoice_motdung(dung, sai):
    """Trộn 1 đúng, 3 sai theo định dạng \\choice."""
    selected_dung = dung[0]
    clean_sai = list(set([s for s in sai if s != selected_dung]))
    while len(clean_sai) < 3:
        clean_sai.append(f"$m = {random.randint(-10, 20)}$")
    
    selected_sai = random.sample(clean_sai, 3)
    choices = [r'\True ' + selected_dung] + selected_sai
    random.shuffle(choices)
    
    return (f"\\choice \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def generate():
    x, m = symbols('x m')
    
    while True:
        # 1. Thiết lập phương trình log_a(f(x,m)) = b
        a = random.choice([2, 3, 5])
        b_val = random.randint(1, 2)
        x0 = random.randint(1, 5) # Nghiệm x0 cho trước
        
        # Biểu thức f(x,m) dạng: x^2 + m*x + c hoặc x + m + c
        # Ở đây chọn dạng bậc nhất theo m để giải m dễ dàng: f(x,m) = x + m + c
        c = random.randint(-10, 10)
        # f(x, m) = x + m + c
        f_xm = x + m + c
        
        # 2. Thay x = x0 vào phương trình: log_a(x0 + m + c) = b_val
        # Tương đương: x0 + m + c = a**b_val
        ve_phai = Rational(a)**b_val
        pt_theo_m = x0 + m + c - ve_phai
        
        m_sol_list = solve(pt_theo_m, m)
        
        if m_sol_list:
            m_res = m_sol_list[0]
            # Kiểm tra điều kiện xác định của log: f(x0, m_res) phải > 0
            if (x0 + m_res + c) > 0:
                break

    correct_val = f"$m = {latex(m_res)}$"

    # --- 3. TẠO NHIỄU ---
    dssai = []
    # Nhiễu 1: Quên log, giải x0 + m + c = b_val
    sai1 = solve(x0 + m + c - b_val, m)
    if sai1: dssai.append(f"$m = {latex(sai1[0])}$")
    
    # Nhiễu 2: Giải x0 + m + c = a*b_val (nhầm lũy thừa thành nhân)
    sai2 = solve(x0 + m + c - a*b_val, m)
    if sai2: dssai.append(f"$m = {latex(sai2[0])}$")
    
    # Nhiễu 3: Sai dấu
    dssai.append(f"$m = {latex(-m_res)}$")

    # --- 4. RÁP LATEX ---
    toan = nhanvao_dsdungsai_rachoice_motdung([correct_val], dssai)
    # Hiển thị phương trình gốc
    expr_tex = latex(f_xm).replace('m', 'm')
    P_tex = rf"\log_{{{a}}} \left( {expr_tex} \right) = {b_val}"

    return rf"""\begin{{ex}}
Biết rằng phương trình ${P_tex}$ nhận $x = {x0}$ làm nghiệm. Giá trị của tham số $m$ bằng
{toan}
\loigiai{{
Vì $x = {x0}$ là nghiệm của phương trình nên thay $x = {x0}$ vào phương trình ta được:
$\log_{{{a}}} \left( {x0} + m + {c if c >=0 else f'({c})'} \right) = {b_val}$
$\Leftrightarrow {x0} + m + {c if c >=0 else f'({c})'} = {a}^{{{b_val}}}$
$\Leftrightarrow m + {x0 + c} = {ve_phai}$
$\Leftrightarrow m = {latex(m_res)}$.
}}
\end{{ex}}"""

print(generate())
