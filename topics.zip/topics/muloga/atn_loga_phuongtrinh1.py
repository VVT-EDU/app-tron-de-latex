import random
from sympy import symbols, solveset, Rational, latex, S, Interval, And

def nhanvao_dsdungsai_rachoice_motdung(dung, sai):
    """Trộn 1 đúng, 3 sai theo định dạng \\choice."""
    selected_dung = dung[0]
    clean_sai = list(set([s for s in sai if s != selected_dung]))
    while len(clean_sai) < 3:
        clean_sai.append(rf"$(-\infty; {random.randint(-5, 5)})$")
    
    selected_sai = random.sample(clean_sai, 3)
    choices = [r'\True ' + selected_dung] + selected_sai
    random.shuffle(choices)
    
    return (f"\\choice \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def generate():
    x = symbols('x')
    
    while True:
        # 1. Thiết lập thông số
        a_sym = random.choice([Rational(1, 2), Rational(2), Rational(3), Rational(1, 3)])
        a_num = float(a_sym)
        b_val = random.randint(-1, 1)
        m = random.choice([-2, -1, 1, 2])
        n = random.randint(-5, 5)
        f_x = m*x + n
        op = random.choice(['>', '<'])
        
        # 2. Giải ĐIỀU KIỆN XÁC ĐỊNH bằng solveset
        dk_xd = solveset(f_x > 0, x, domain=S.Reals)
        
        # 3. Giải BẤT PHƯƠNG TRÌNH
        # Đảo chiều nếu cơ số a < 1
        if a_num < 1:
            op_final = '<' if op == '>' else '>'
        else:
            op_final = op
            
        target = a_sym**b_val
        if op_final == '>':
            sol_bpt = solveset(f_x > target, x, domain=S.Reals)
        else:
            sol_bpt = solveset(f_x < target, x, domain=S.Reals)
            
        # 4. GIAO TẬP NGHIỆM (solveset trả về Set nên intersect sẽ hoạt động)
        final_sol = sol_bpt.intersect(dk_xd)
        
        # Đảm bảo tập nghiệm không rỗng và không phải toàn bộ R
        if final_sol != S.EmptySet and final_sol != S.Reals:
            break

    # Chuyển đổi tập nghiệm sang LaTeX chuẩn
    correct_val = f"${latex(final_sol)}$"

    # --- TẠO NHIỄU ---
    dssai = []
    # Nhiễu 1: Quên điều kiện xác định
    dssai.append(f"${latex(sol_bpt)}$")
    # Nhiễu 2: Quên đổi chiều (giả lập bằng cách lấy sol_bpt ngược lại)
    dssai.append(rf"$(-\infty; {random.randint(-2, 2)})$")
    # Nhiễu 3: Thay đổi kiểu ngoặc
    dssai.append(correct_val.replace('(', '[').replace(')', ']'))

    # --- RÁP LATEX ---
    toan = nhanvao_dsdungsai_rachoice_motdung([correct_val], dssai)
    a_tex = latex(a_sym)
    P_tex = rf"\log_{{{a_tex}}} ({latex(f_x)}) {op} {b_val}"

    return rf"""\begin{{ex}}
Tìm tập nghiệm $S$ của bất phương trình ${P_tex}$.
{toan}
\loigiai{{
Điều kiện xác định: ${latex(f_x)} > 0 \Leftrightarrow x \in {latex(dk_xd)}$.
Vì cơ số $a = {a_tex} {'< 1' if a_num < 1 else '> 1'}$ nên bất phương trình tương đương với:
${latex(f_x)} {'<' if op_final == '<' else '>'} {a_tex}^{{{b_val}}} \Leftrightarrow {latex(f_x)} {'<' if op_final == '<' else '>'} {latex(target)}$.
Giải ra ta được $x \in {latex(sol_bpt)}$.
Kết hợp với điều kiện xác định, ta được tập nghiệm $S = {latex(final_sol)}$.
}}
\end{{ex}}"""

print(generate())
