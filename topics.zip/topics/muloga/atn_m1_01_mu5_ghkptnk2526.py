import random
from fractions import Fraction

def to_latex(frac):
    """Định dạng LaTeX phân số tối giản."""
    if frac.denominator == 1:
        return str(frac.numerator)
    return rf"\dfrac{{{frac.numerator}}}{{{frac.denominator}}}"

def generate():
    # 1. Chọn giá trị cho a^x (thường là số nguyên hoặc phân số đẹp)
    val_ax = random.choice([2, 3, 4, 5])
    
    # 2. Thiết kế biểu thức: A = (a^{3x} + a^{-3x}) / (a^x + a^{-x})
    # Đây là dạng hằng đẳng thức: (u^3 + v^3)/(u + v) = u^2 - uv + v^2
    # Với u = a^x, v = a^{-x} thì uv = 1.
    
    # Chọn ngẫu nhiên kịch bản
    scenario = random.choice(['hdt_3', 'nhan_them'])
    
    name = random.choice(['P', 'Q', 'M', 'N', 'A', 'B'])
    
    if scenario == 'hdt_3':
        # P = (a^{3x} + a^{-3x}) / (a^x + a^{-x}) = (a^x)^2 - 1 + (a^{-x})^2
        res_val = Fraction(val_ax**2 - 1 + Fraction(1, val_ax**2))
        P_tex = rf"\dfrac{{a^{{3x}} + a^{{-3x}}}}{{a^{{x}} + a^{{-x}}}}"
        step_solve = rf"Ta có ${name} = \dfrac{{(a^{{x}} + a^{{-x}})(a^{{2x}} - 1 + a^{{-2x}})}}{{a^{{x}} + a^{{-x}}}} = a^{{2x}} - 1 + a^{{-2x}}$."
    else:
        # P = (a^x - a^{-x}) / (a^x + a^{-x}). Nhân cả tử và mẫu với a^x -> (a^{2x} - 1) / (a^{2x} + 1)
        res_val = Fraction(val_ax**2 - 1, val_ax**2 + 1)
        P_tex = rf"\dfrac{{a^{{x}} - a^{{-x}}}}{{a^{{x}} + a^{{-x}}}}"
        step_solve = rf"Nhân cả tử và mẫu của ${name}$ với $a^{{x}}$, ta được: ${name} = \dfrac{{a^{{2x}} - 1}}{{a^{{2x}} + 1}}$."

    # 3. Tạo phương án trắc nghiệm
    correct_lt = to_latex(res_val)
    distractors = {to_latex(res_val + 1), to_latex(1/res_val if res_val !=0 else 1), to_latex(Fraction(val_ax - 1, val_ax + 1))}
    
    options = [rf"\True $ {correct_lt}$"]
    for d in list(distractors)[:3]:
        options.append(rf"$ {d}$")
    random.shuffle(options)

    # 4. Xuất mã EX
    return rf"""\begin{{ex}}
    Cho số thực $a > 0$ thỏa mãn $a^{{x}} = {val_ax}$. Biểu thức $ {P_tex}$ bằng 
    \choice
    {{{options[0]}}}
    {{{options[1]}}}
    {{{options[2]}}}
    {{{options[3]}}}
    \loigiai{{
        Dựa vào giả thiết $a^{{x}} = {val_ax} \Rightarrow a^{{2x}} = (a^{{x}})^2 = {val_ax**2}$.
        \begin{{itemize}}
            \item {step_solve}
            \item Thay $a^{{2x}} = {val_ax**2}$ vào biểu thức, ta được:
            \item ${name} = {to_latex(res_val)}$.
        \end{{itemize}}
        Vậy đáp án đúng là ${correct_lt}$.
    }}
\end{{ex}}"""

print(generate())
