import random
from sympy import symbols, log, simplify, latex, Rational, root

def generate():
    # 1. THIẾT LẬP BIẾN
    m = symbols('m', positive=True)
    n = random.randint(2, 4) # Tham số n để tăng độ khó
    a = 2 # Cơ số chuẩn
    
    # 2. XÂY DỰNG BIỂU THỨC PHỨC TẠP
    # Ý tưởng: M = log_{a}(m^n) + log_{a^2}(m) * log_{m}(a^n) - log_{sqrt(a)}(m)
    # Bước này ép học sinh phải dùng:
    # - Công thức log_{a^2}(m) = 1/2 log_a(m)
    # - Công thức log_m(a^n) = n * log_m(a) = n / log_a(m)
    # - Công thức log_{sqrt(a)}(m) = 2 log_a(m)
    
    term1 = log(m**n, a) # n*log_a(m)
    term2_a = log(m, a**2) # (1/2)*log_a(m)
    term2_b = log(a**n, m) # n*log_m(a) = n/log_a(m)
    term3 = log(m, root(a, 2)) # 2*log_a(m)
    
    # Biểu thức M = term1 + term2_a * term2_b - term3
    # M = n*log_a(m) + (1/2 * log_a(m) * n / log_a(m)) - 2*log_a(m)
    # M = (n-2)*log_a(m) + n/2
    
    # 3. RÚT GỌN LOGIC
    # Kết quả rút gọn sẽ có dạng: (n-2)log_a(m) + n/2
    # Để đưa về dạng log_a(m^k), ta cần xử lý con số n/2 thành log_a(a^{n/2})
    # M = log_a(m^{n-2} * a^{n/2}) -> k không còn là hằng số đơn thuần mà chứa tham số.
    
    # Ở đây để bài toán hay, ta yêu cầu tìm k trong biểu thức M = log_a(m^k) + C
    k_val = n - 2
    constant_term = Rational(n, 2)
    
    # 4. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Bước 1: Biến đổi từng số hạng về cơ số ${a}$:",
        f"$+ \\log_{{{a}}} (m^{{{n}}}) = {n} \\log_{{{a}}} m$",
        f"$+ \\log_{{{a**2}}} m = \\frac{{1}}{{2}} \\log_{{{a}}} m$",
        f"$+ \\log_{{m}} ({a}^{{{n}}}) = {n} \\log_{{m}} {a} = \\frac{{{n}}}{{\\log_{{{a}}} m}}$",
        f"$+ \\log_{{\\sqrt{{{a}}}}} m = 2 \\log_{{{a}}} m$",
        f"Bước 2: Thay vào biểu thức $M$:",
        f"$M = {n} \\log_{{{a}}} m + \\left( \\frac{{1}}{{2}} \\log_{{{a}}} m \\cdot \\frac{{{n}}}{{\\log_{{{a}}} m}} \\right) - 2 \\log_{{{a}}} m$",
        f"Bước 3: Rút gọn các đại lượng:",
        f"$M = ({n} - 2) \\log_{{{a}}} m + \\frac{{{n}}}{{2}}$",
        f"Đối chiếu với dạng $M = \\log_{{{a}}} (m^k) + C$, ta có $k = {k_val}$ và $C = {latex(constant_term)}$."
    ]

    loigiai_latex = " \\\\\n".join(y_list)

    return rf"""\begin{{ex}}
Cho $m$ là số thực dương khác $1$. Rút gọn biểu thức sau về dạng $M = \log_{{{a}}} (m^k) + C$:
$M = \log_{{{a}}} (m^{{{n}}}) + \log_{{{a**2}}} m \cdot \log_{{m}} ({a}^{{{n}}}) - \log_{{\sqrt{{{a}}}}} m$
Tính giá trị của $S = k + 2C$.
\shortans{{ ${k_val + 2*constant_term}$ }}
\loigiai{{
{loigiai_latex} \\
Vậy $S = {k_val} + 2 \cdot {latex(constant_term)} = {k_val + 2*constant_term}$.
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
