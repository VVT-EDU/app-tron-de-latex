import random
from sympy import symbols, latex, Rational, simplify

def vn_format(number):
    """Định dạng số theo chuẩn Việt Nam, bọc trong $ $."""
    str_num = str(number)
    if '/' in str_num: 
        return f"${latex(number)}$"
    if '.' in str_num:
        parts = str_num.split('.')
        return f"${parts[0]},{parts[1]}$"
    return f"${str_num}$"

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    p, q, r = random.randint(1, 2), random.randint(1, 2), random.randint(1, 3)
    m, n, k = random.choice([3, 4, 5]), random.choice([2, 3]), random.randint(2, 3)
    
    mn = m * n
    exp_total = Rational(p) + Rational(q, m) + Rational(r, mn)
    a_val = exp_total / k
    m_val, n_val = a_val.p, a_val.q
    
    u, v = random.randint(1, 2), random.randint(1, 2)
    T_result = u * m_val + v * n_val
    name = random.choice(['P', 'A', 'Q', 'S'])
    
    # 2. TRÌNH BÀY NỘI DUNG (Đã sửa lỗi đóng ngoặc ở biến bai_tap)
    inner_tex = rf"x^{{{p}}} \cdot \sqrt[{{{m}}}]{{x^{{{q}}} \cdot \sqrt[{{{n}}}]{{x^{{{r}}}}}}}"
    
    # Dùng ngoặc đơn bao quanh để Python hiểu là một khối chuỗi liên tục
    bai_tap = (
        rf"Cho biểu thức ${name} = \log_{{{x}^{{{k}}}}} \left( {inner_tex} \right)$ với $x > 0$ và $x \neq 1$. "
        rf"Biết giá trị của biểu thức ${name}$ viết dưới dạng phân số tối giản là $a = \dfrac{{m}}{{n}}$ "
        rf"(với $m, n \in \mathbb{{N}}^*$). Tính giá trị của biểu thức $T = {f'{u}' if u > 1 else ''}m + {f'{v}' if v > 1 else ''}n$."
    )

    return rf"""\begin{{ex}}
{bai_tap}
\shortans{{ {T_result} }}
\loigiai{{
    Thực hiện biến đổi biểu thức bên trong dấu logarit về dạng lũy thừa của $x$:
    \begin{{itemize}}
        \item Ta có: ${inner_tex} = x^{{{p}}} \cdot x^{{\frac{{{q}}}{{{m}}}}} \cdot x^{{\frac{{{r}}}{{{mn}}}}} = x^{{{p} + \frac{{{q}}}{{{m}}} + \frac{{{r}}}{{{mn}}}}}$.
        \item Tổng các số mũ: ${p} + \dfrac{{{q}}}{{{m}}} + \dfrac{{{r}}}{{{mn}}} = {vn_format(exp_total)}$.
        \item Khi đó: ${name} = \log_{{{x}^{{{k}}}}} \left( x^{{{latex(exp_total)}}} \right) = \dfrac{{1}}{{{k}}} \cdot {latex(exp_total)} \cdot \log_x x = {vn_format(a_val)}$.
        \item Vì $a = \dfrac{{{m_val}}}{{{n_val}}}$ tối giản nên $m = {m_val}, n = {n_val}$.
        \item Vậy $T = {u} \cdot {m_val} + {v} \cdot {n_val} = {T_result}$.
    \end{{itemize}}
    Đáp số: $T = {T_result}$.
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
