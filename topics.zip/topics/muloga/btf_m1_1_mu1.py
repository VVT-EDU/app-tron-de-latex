import random
import sympy as sp
from sympy import symbols, latex, simplify, Rational

# --- Import hàm của bạn (Giả sử bạn để trong file thuvien hoặc khai báo trực tiếp) ---
# Nếu bạn để file riêng: from topics.thuvien.thuvien_nhanvao_dsdungsai_rachoice import *
# Ở đây tôi viết lại hàm để đảm bảo code chạy độc lập được:

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    # Lấy ngẫu nhiên 2 đúng, 2 sai
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    
    dsdung = [dung[i] for i in indices_dung]
    dssai = [sai[i] for i in indices_sai]
    
    # Định dạng theo chuẩn LaTeX của bạn
    dung1 = r'\True ' + f"${dsdung[0]}$"
    dung2 = r'\True ' + f"${dsdung[1]}$"
    sai1 = f"${dssai[0]}$"
    sai2 = f"${dssai[1]}$"
    
    choice = [dung1, sai1, sai2, dung2]
    random.shuffle(choice)
    
    choice_str = f"\\choiceTF \n {{ {choice[0]} }}\n {{ {choice[1]} }}\n {{ {choice[2]} }}\n {{ {choice[3]} }}"
    return [choice_str, ""]

def generate():
    # Khai báo biến SymPy
    # Khai báo positive=True để SymPy hiểu a > 0, giúp rút gọn căn thức mượt mà
    a = symbols('a', positive=True) 
    
    # Tạo các số nguyên ngẫu nhiên làm số mũ
    m = random.randint(2, 6)
    n = random.randint(2, 6)
    p = random.randint(2, 5)
    
    # --- Tập hợp các mệnh đề ĐÚNG ---
    # Sử dụng Rational(m, n) để tạo phân số đẹp trong LaTeX
    y1 = f"a^{{{m}}} \\cdot a^{{{n}}} = a^{{{m+n}}}"
    y2 = f"\\frac{{a^{{{m+n}}}}}{{a^{{{p}}}}} = a^{{{m+n-p}}}"
    y3 = f"\\sqrt[{p}]{{a^{{{m}}}}} = a^{{\\frac{{{m}}}{{{p}}}}}"
    y4 = f"(a^{{{m}}})^{{{n}}} = a^{{{m*n}}}"
    y5 = f"a^0 = 1 \\text{{ với }} a \\neq 0"
    y6 = f"a^{{{-m}}} = \\frac{{1}}{{a^{{{m}}}}}"
    
    dung = [y1, y2, y3, y4, y5, y6]

    # --- Tập hợp các mệnh đề SAI (Các lỗi sai kinh điển) ---
    s1 = f"a^{{{m}}} \\cdot a^{{{n}}} = a^{{{m*n}}}"  # Sai: Lấy mũ nhân mũ
    s2 = f"\\frac{{a^{{{m}}}}}{{a^{{{n}}}}} = a^{{\\frac{{{m}}}{{{n}}}}}" # Sai: Chia thành chia mũ
    s3 = f"\\sqrt[{p}]{{a^{{{m}}}}} = a^{{{m-p}}}" # Sai: Căn thành trừ mũ
    s4 = f"(a^{{{m}}})^{{{n}}} = a^{{{m+n}}}" # Sai: Lũy thừa của lũy thừa thành cộng mũ
    s5 = f"a^{{{m}}} + a^{{{n}}} = a^{{{m+n}}}" # Sai: Cộng hai lũy thừa thành cộng mũ
    s6 = f"\\sqrt{{a^{{{m}}} + a^{{{n}}}}} = a^{{\\frac{{{m}}}{{2}}}} + a^{{\\frac{{{n}}}{{2}}}}" # Sai: Căn của tổng
    
    sai = [s1, s2, s3, s4, s5, s6]

    # Thực hiện trộn câu hỏi
    luachon = nhanvao_dsdungsai_rachoice_dungsai(dung, sai)
    choice = luachon[0]
    
    # Tạo nội dung đề bài
    bai = f"Cho biểu thức lũy thừa cơ số $a > 0$."
    bai += f" \\textbf{{ Xét tính đúng sai của các khẳng định sau:}}"
    
    # Tạo lời giải (Liệt kê các khẳng định đúng)
    lg_list = [f"${item}$" for item in dung]
    loigiai = " \\\\\n".join(lg_list)
    
    # Ráp thành cấu trúc môi trường ex của LaTeX
    thanhde = (f"\\begin{{ex}}\n"
               f"{bai}\n"
               f"{choice}\n"
               f"\\loigiai{{ Các khẳng định đúng là: \\\\\n {loigiai} }}\n"
               f"\\end{{ex}}")
    
    # Dọn dẹp các ký tự thừa nếu có
    thanhde = thanhde.replace("\\frac", "\\dfrac")
    
    return thanhde

# Test thử hàm
# print(generate_somu())
