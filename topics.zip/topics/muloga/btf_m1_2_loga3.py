import random
import sympy as sp
from sympy import symbols, latex, Rational, sqrt, log

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """
    Trộn 2 đúng, 2 sai. 
    Đảm bảo nhãn \True nằm ngoài dấu $ để tương thích với định dạng LaTeX.
    """
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
        
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Qt6 Scanner Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ
    a = random.choice([2, 3, 5])
    a_sq = a**2
    
    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # --- CÂU ĐÚNG ---
    d1 = r"$\text{Với } x > 0 \text{ và } m, n \in \mathbb{R} \text{ thì } (x^m)^n = (x^n)^m$"
    d2 = r"$\text{Với } x > 0 \text{ và } m \in \mathbb{R} \text{ thì } x^{2m} = (x^m)^2$"
    d3 = f"$\\log_{{{a}}} ({a_sq}x) = 2 + \\log_{{{a}}} x \\text{{ với }} x > 0$"
    d4 = f"$\\log_{{{a}}} \\sqrt{{x}} = \\dfrac{{1}}{{2}} \\log_{{{a}}} x \\text{{ với }} x > 0$"

    # --- CÂU SAI ---
    s1 = f"$\\log_{{{a}}} ({a_sq}x) = {a_sq} + \\log_{{{a}}} x \\text{{ với }} x > 0$"
    s2 = r"$\log_{\sqrt{3}} x + \log_{\frac{1}{3}}(3x^3 y) + \log_9(3y^3) = 1 \text{ với mọi } x, y > 0$"
    s3 = r"$\log_a (x+y) = \log_a x + \log_a y \text{ với mọi } x, y > 0$"
    s4 = r"$(x+y)^m = x^m + y^m \text{ với mọi } x, y > 0, m \neq 1$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = r"\textbf{Đúng}. Theo tính chất lũy thừa: $(x^m)^n = x^{m \cdot n} = x^{n \cdot m} = (x^n)^m$."
        elif content == d2:
            note = r"\textbf{Đúng}. Theo tính chất lũy thừa: $x^{2m} = x^{m \cdot 2} = (x^m)^2$."
        elif content == d3:
            note = f"\\textbf{{Đúng}}. Ta có $\\log_{{{a}}} ({a_sq}x) = \\log_{{{a}}} {a}^{{2}} + \\log_{{{a}}} x = 2 + \\log_{{{a}}} x$."
        elif content == d4:
            note = f"\\textbf{{Đúng}}. Ta có $\\log_{{{a}}} \\sqrt{{x}} = \\log_{{{a}}} x^{{1/2}} = \\dfrac{{1}}{{2}} \\log_{{{a}}} x$."
        elif content == s1:
            note = f"\\textbf{{Sai}}. Vì $\\log_{{{a}}} ({a_sq}x) = \\log_{{{a}}} {a}^2 + \\log_{{{a}}} x = 2 + \\log_{{{a}}} x$."
        elif content == s2:
            note = r"\textbf{Sai}. Biến đổi các cơ số về cùng cơ số $3$: $\text{VT} = 2\log_3 x - (1 + 3\log_3 x + \log_3 y) + \frac{1}{2}(1 + 3\log_3 y) = -\log_3 x + \frac{1}{2}\log_3 y - \frac{1}{2}$."
        elif content == s3:
            note = r"\textbf{Sai}. Lôgarit của một tổng không bằng tổng các lôgarit. Quy tắc đúng là $\log_a(xy) = \log_a x + \log_a y$."
        elif content == s4:
            note = r"\textbf{Sai}. Lũy thừa của một tổng không có tính chất phân phối như phép nhân."
        else:
            note = ""
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Cho $x, y$ là hai số thực dương và $m, n$ là hai số thực tùy ý. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde.replace("\\frac", "\\dfrac")
