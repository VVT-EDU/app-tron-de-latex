import random
import math
from sympy import symbols, latex, solve, simplify

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    # Cơ số a (thường chọn 2 hoặc 3 để nghiệm đẹp)
    a = random.choice([2, 3])
    # Hệ số m trong x^2 - mx
    m = random.choice([1, 2, 3])
    # Hằng số k
    k = random.choice([1, 2])
    
    # Tính toán các giá trị trung gian
    # Bất phương trình: log_a(1/(x^2-mx)) + log_a(x) + k >= 0
    # Biến đổi: log_a(x) + log_a(a^k) >= log_a(x^2 - mx)
    # => a^k * x >= x^2 - mx
    # => x^2 - (m + a^k)x <= 0
    # => 0 <= x <= m + a^k
    
    ak = a**k
    upper_bound = m + ak
    
    # 2. ĐIỀU KIỆN VÀ NGHIỆM
    # Điều kiện: x^2 - mx > 0 và x > 0 => x > m
    # Nghiệm kết hợp: m < x <= upper_bound
    
    so_nghiem = ak # Số nguyên dương là (m + a^k) - m = a^k
    danh_sach_nghiem = list(range(m + 1, upper_bound + 1))
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bt_goc = rf"\log_{a}\dfrac{{1}}{{x^2-{m}x}}+\log_{a}x+{k}\ge 0"
    
    bai_tap = (
        f"Có bao nhiêu số nguyên dương là nghiệm của bất phương trình ${bt_goc}$?"
    )

    # 4. TRÌNH BÀY LỜI GIẢI
    y_list = [
        rf"Điều kiện: $\heva{{&x^2-{m}x>0\\&x>0}}\Leftrightarrow x>{m}$.",
        f"Bất phương trình tương đương với:",
        rf"$\Leftrightarrow \log_{a}x + \log_{a}{ak} \ge \log_{a}(x^2-{m}x)$",
        rf"$\Leftrightarrow \log_{a}({ak}x) \ge \log_{a}(x^2-{m}x)$",
        rf"$\Leftrightarrow {ak}x \ge x^2-{m}x$ (do cơ số ${a} > 1$)",
        rf"$\Leftrightarrow x^2-{m+ak}x \le 0 \Leftrightarrow 0 \le x \le {upper_bound}$.",
        f"Kết hợp với điều kiện $x > {m}$, ta được: ${m} < x \\le {upper_bound}$.",
        f"Vì $x$ là số nguyên dương nên $x \\in \\{{ {', '.join(map(str, danh_sach_nghiem))}\\}}$.",
        f"Vậy có ${so_nghiem}$ số nguyên dương thỏa mãn bất phương trình."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
{bai_tap}
\shortans{{ ${so_nghiem}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
