import random
import math

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """
    Trộn 2 đúng, 2 sai theo định dạng \choiceTF.
    """
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
        
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Ứng dụng Logarit - Thang đo Richter)
# =============================================================================

def generate():
    # 1. THÔNG SỐ CỐ ĐỊNH CỦA CÔNG THỨC
    # log x = 11.8 + 1.5M
    
    # Tính toán các giá trị mẫu
    # M = 2 => log x = 14.8 => x = 10^14.8 erg
    # M = 3 => log x = 16.3 => x = 10^16.3 erg = 10^9.3 jun ≈ 2*10^9 jun
    
    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    d1 = r"$\text{Trận động đất } 3 \text{ độ Richter tạo ra năng lượng khoảng } 2 \cdot 10^9 \text{ jun}$"
    d2 = r"$\text{Năng lượng trận } 5 \text{ độ Richter gấp } 1000 \text{ lần trận } 3 \text{ độ Richter}$"
    d3 = r"$\text{Với } 4 \le M \le 6, \text{ năng lượng } x \text{ (erg) thỏa mãn } 10^{17,8} \le x \le 10^{20,8}$"
    d4 = r"$\text{Trận động đất } 2 \text{ độ Richter tạo ra năng lượng } x = 10^{14,8} \text{ erg}$"

    s1 = r"$\text{Trận động đất } 2 \text{ độ Richter tạo ra năng lượng khoảng } 6,3 \cdot 10^{34} \text{ erg}$"
    s2 = r"$\text{Trận động đất } 5 \text{ độ Richter tạo ra năng lượng gấp } 100 \text{ lần trận } 3 \text{ độ Richter}$"
    s3 = r"$\text{Nếu năng lượng tăng gấp } 10 \text{ lần thì độ lớn } M \text{ tăng thêm } 1 \text{ đơn vị}$"
    s4 = r"$\text{Trận động đất } 0 \text{ độ Richter thì không tạo ra năng lượng (} x=0 \text{)}$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = r"\textbf{Đúng}. $M=3 \Rightarrow \log x = 11,8 + 1,5 \cdot 3 = 16,3 \Rightarrow x = 10^{16,3} \text{ erg}$. Đổi sang jun: $x = 10^{16,3} \cdot 10^{-7} = 10^{9,3} \approx 2 \cdot 10^9 \text{ jun}$."
        elif content == d2:
            note = r"\textbf{Đúng}. $\log x_1 - \log x_2 = 1,5(M_1 - M_2) = 1,5(5-3) = 3 \Rightarrow \frac{x_1}{x_2} = 10^3 = 1000$."
        elif content == d3:
            note = r"\textbf{Đúng}. $M=4 \Rightarrow \log x = 17,8$; $M=6 \Rightarrow \log x = 20,8$. Vậy $10^{17,8} \le x \le 10^{20,8}$."
        elif content == d4:
            note = r"\textbf{Đúng}. $M=2 \Rightarrow \log x = 11,8 + 1,5 \cdot 2 = 14,8 \Rightarrow x = 10^{14,8}$."
        elif content == s1:
            note = r"\textbf{Sai}. $\log x = 14,8 \Rightarrow x = 10^{14,8} \approx 6,3 \cdot 10^{14} \text{ erg}$."
        elif content == s2:
            note = r"\textbf{Sai}. Tỉ số năng lượng là $10^{1,5 \cdot 2} = 10^3 = 1000$ lần."
        elif content == s3:
            note = r"\textbf{Sai}. Nếu $x$ tăng $10$ lần thì $\log x$ tăng $1$ đơn vị, dẫn đến $M$ tăng $1/1,5 \approx 0,67$ đơn vị."
        elif content == s4:
            note = r"\textbf{Sai}. Với $M=0, \log x = 11,8 \Rightarrow x = 10^{11,8} > 0$."
        else:
            note = ""
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Công thức $\\log x=11,8+1,5M$ cho biết mối liên hệ giữa năng lượng $x$ tạo ra (tính theo erg) với độ lớn $M$ theo thang Richter của một trận động đất. Biết $1$ erg tương đương $10^{{-7}}$ jun. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde.replace(".", ",").replace(" erg", " \\text{ erg}").replace(" jun", " \\text{ jun}")
