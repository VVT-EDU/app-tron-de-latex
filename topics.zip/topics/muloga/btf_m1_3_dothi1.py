import random
import math

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai theo định dạng \choiceTF."""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (So sánh cơ số Lôgarit qua đồ thị - Qt6 Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ NGẪU NHIÊN
    # Theo đồ thị: a < b (do đồ thị b nằm dưới a khi x > 1) và c < 1 (nghịch biến)
    # Ta chọn mốc y_k để tạo khẳng định trung điểm
    y_k = random.randint(2, 4)
    
    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # --- CÁC CÂU ĐÚNG ---
    d1 = r"$\text{Trong các hàm số đã cho, có đúng hai hàm số đồng biến trên } (0; +\infty)$"
    d2 = f"$\\text{{Đường thẳng }} y={y_k} \\text{{ cắt }} Oy, y=\\log_ax, y=\\log_bx \\text{{ tại }} H, M, N. \\text{{ Nếu }} M \\text{{ là trung điểm }} HN \\text{{ thì }} b^{{{y_k}}}=2a^{{{y_k}}}$"
    d3 = r"$\text{Mối quan hệ giữa các cơ số là } b > a > 1 > c > 0$"
    d4 = r"$\text{Bất phương trình } \log_cx > \log_c2 \text{ có tập nghiệm là } S = (0; 2)$"

    # --- CÁC CÂU SAI ---
    s1 = r"$\text{Trong ba số } a, b, c \text{ có đúng hai số nhỏ hơn } 1$"
    s2 = r"$\text{Mối quan hệ giữa các cơ số là } a > b > c$"
    s3 = r"$\text{Hàm số } y=\log_cx \text{ đồng biến trên khoảng } (0; +\infty)$"
    s4 = f"$\\text{{Nếu }} M \\text{{ là trung điểm }} HN \\text{{ (với }} y={y_k}\\text{{) thì }} a^{{{y_k}}}=2b^{{{y_k}}}$"
    s5 = r"$\text{Bất phương trình } \log_cx > \log_c2 \text{ tương đương với } x > 2$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4, s5]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = r"\textbf{Đúng}. Đồ thị $y=\log_ax$ và $y=\log_bx$ đi lên nên $a, b > 1$. Đồ thị $y=\log_cx$ đi xuống nên $0 < c < 1$."
        elif content == d3:
            note = r"\textbf{Đúng}. Kẻ đường thẳng $y=1$ cắt hai đồ thị đồng biến tại $x=a$ và $x=b$. Vì $b$ nằm xa trục tung hơn nên $b > a > 1$."
        elif "trung điểm" in content and "\\True" in item:
            note = f"\\textbf{{Đúng}}. $H(0; {y_k}), M(a^{{{y_k}}}; {y_k}), N(b^{{{y_k}}}; {y_k})$. $M$ là trung điểm $\\Rightarrow x_N + x_H = 2x_M \\Rightarrow b^{{{y_k}}} = 2a^{{{y_k}}}$."
        elif content == s5:
            note = r"\textbf{Sai}. Vì cơ số $c < 1$ nên hàm số nghịch biến, bất phương trình đổi chiều thành $x < 2$. Kết hợp điều kiện $x > 0$ ta được $0 < x < 2$."
        else:
            note = r"\textbf{Kiểm tra}. Dựa vào hướng đi của đồ thị (tính đơn điệu) và vị trí tương đối để so sánh các cơ số."
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Cho $a, b, c$ là ba số thực dương khác $1$. Đồ thị các hàm số $y=\\log_ax, y=\\log_bx, y=\\log_cx$ được cho như hình vẽ. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    \\begin{{center}}
        \\begin{{tikzpicture}}[font=\\footnotesize, line join=round, line cap=round, >=stealth, scale=0.9]
            \\draw[->](-0.5,0)--(4.5,0)node [below]{{$x$}};
            \\draw[->](0,-2)--(0,2.5)node [left] {{$y$}};
            \\node[below left] at (0,0) {{$O$}};
            \\draw[smooth,samples=100, color=blue] plot[domain=0.2:4](\\x,{{ln(\\x)/ln(1.5)}}) node[right] {{$y=\\log_ax$}};
            \\draw[smooth,samples=100, color=red] plot[domain=0.1:4](\\x,{{ln(\\x)/ln(3)}}) node[right] {{$y=\\log_bx$}};
            \\draw[smooth,samples=100, color=violet] plot[domain=0.2:4](\\x,{{-ln(\\x)/ln(2)}}) node[right] {{$y=\\log_cx$}};
            \\fill (1,0) circle (1pt) node[below] {{$1$}};
        \\end{{tikzpicture}}
    \\end{{center}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde
