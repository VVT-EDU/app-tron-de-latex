import random
import math
from sympy import symbols, log, latex, simplify
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP THAM SỐ
    # Chọn phần trăm độ phóng xạ còn lại (từ 70% đến 84%)
    phantram = random.choice([70, 72, 74, 75, 77, 78, 80, 81, 82, 83, 84])
    tisophantram = phantram / 100
    
    # Chu kỳ bán rã của C14
    T_ban_ra = 5730
    
    # 2. TÍNH TOÁN ĐỘ TUỔI t
    # Công thức: H = H0 * e^(-lambda * t) với lambda = ln(2) / T
    # => H/H0 = e^(- (ln2/T) * t)
    # => ln(H/H0) = - (ln2/T) * t
    # => t = - (T * ln(H/H0)) / ln2
    
    t_chinh_xac = - (T_ban_ra * math.log(tisophantram)) / math.log(2)
    kq_lam_tron = int(round_half_up(t_chinh_xac, 0))
    
    # 3. TRÌNH BÀY ĐỀ BÀI
    bai_tap = (
        f"Trong cây cối có chất phóng xạ $_6^{{14}}C$. Khảo sát một mẫu gỗ cổ, các nhà khoa học đo được "
        f"độ phóng xạ của nó bằng ${phantram}\\%$ độ phóng xạ của mẫu gỗ tươi cùng loại. "
        f"Biết chu kì bán rã của $_6^{{14}}C$ là $T = {T_ban_ra}$ năm. "
        f"Độ phóng xạ của chất tại thời điểm $t$ được cho bởi công thức $H = H_0 e^{{-\\lambda t}}$ "
        f"với $H_0$ là độ phóng xạ ban đầu, $\\lambda = \\frac{{\\ln 2}}{{T}}$ là hằng số phóng xạ. "
        f"Xác định độ tuổi của mẫu gỗ cổ đó (làm tròn kết quả đến hàng đơn vị)."
    )

    # 4. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Theo giả thiết, ta có tỉ số độ phóng xạ: $\\frac{{H}}{{H_0}} = {phantram}\\% = {tisophantram}$.",
        f"Thay vào công thức $H = H_0 e^{{-\\lambda t}}$, ta được: $e^{{-\\lambda t}} = {tisophantram}$.",
        f"Lấy logarit tự nhiên hai vế: $-\\lambda t = \\ln({tisophantram})$.",
        f"$\\Rightarrow t = -\\frac{{\\ln({tisophantram})}}{{\\lambda}} = -\\frac{{\\ln({tisophantram})}}{{\\frac{{\\ln 2}}{{{T_ban_ra}}}}} = -\\frac{{{T_ban_ra} \\cdot \\ln({tisophantram})}}{{\\ln 2}}$.",
        f"Tính toán giá trị: $t \\approx {t_chinh_xac:.2f}$ (năm).",
        f"Làm tròn đến hàng đơn vị, ta được tuổi của mẫu gỗ là ${kq_lam_tron}$ năm."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
{bai_tap}
\shortans{{ ${kq_lam_tron}$ năm }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
