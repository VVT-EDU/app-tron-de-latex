import random
import math

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai theo định dạng \choiceTF."""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Khảo sát hàm mũ cơ số nhỏ hơn 1 - Qt6 Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ NGẪU NHIÊN
    # f(x) = (1/a)^x
    a = random.choice([2, 3, 5])
    
    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # --- CÁC CÂU ĐÚNG ---
    d1 = f"$\\text{{Với hai số thực }} a < b \\text{{ bất kì, ta luôn có }} f(a) > f(b)$"
    d2 = f"$\\text{{Đồ thị của hàm số luôn nằm phía trên trục hoành}}$"
    d3 = f"$\\text{{Hàm số đã cho nghịch biến trên khoảng }} (-\\infty; +\\infty)$"
    d4 = f"$\\text{{Tập nghiệm của bất phương trình }} 1 < f(x) < {a**2} \\text{{ là }} (-2; 0)$"

    # --- CÁC CÂU SAI ---
    s1 = f"$\\text{{Tập xác định của hàm số là }} (0;+\\infty)$"
    s2 = f"$\\text{{Đồ thị hàm số đi qua điểm }} (1; 0)$"
    s3 = f"$\\text{{Tập giá trị của hàm số là }} \\mathbb{{R}}$"
    s4 = f"$\\text{{Tập nghiệm của bất phương trình }} 1 < f(x) < {a**2} \\text{{ có đúng một phần tử nguyên dương}}$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = f"\\textbf{{Đúng}}. Vì cơ số $\\frac{{1}}{{{a}}} < 1$ nên hàm số nghịch biến, do đó $a < b \\Rightarrow f(a) > f(b)$."
        elif content == d2:
            note = f"\\textbf{{Đúng}}. Hàm số mũ $y=a^x$ luôn nhận giá trị dương với mọi $x \\in \\mathbb{{R}}$."
        elif content == d4:
            note = f"\\textbf{{Đúng}}. $1 < (\\frac{{1}}{{{a}}})^x < {a**2} \\Leftrightarrow {a}^0 < {a}^{{-x}} < {a}^2 \\Leftrightarrow 0 < -x < 2 \\Leftrightarrow -2 < x < 0$."
        elif content == s1:
            note = f"\\textbf{{Sai}}. Tập xác định của hàm số mũ là $\\mathbb{{R}}$."
        elif content == s3:
            note = f"\\textbf{{Sai}}. Tập giá trị của hàm số mũ là $(0; +\\infty)$."
        elif content == s4:
            note = f"\\textbf{{Sai}}. Tập nghiệm $(-2; 0)$ không chứa số nguyên dương nào."
        else:
            note = r"\textbf{Kiểm tra}. Dựa vào các tính chất cơ bản của hàm số mũ $y=a^x$ với $0 < a < 1$."
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Cho hàm số $y=f(x)=\\left(\\dfrac{{1}}{{{a}}}\\right)^x$. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde
