import random
from sympy import symbols, solve, S, latex
from fractions import Fraction

def nhanvao_dsdungsai_rachoice_motdung(dung, sai):
    # Dùng r ở đầu để tránh lỗi \c trong \choice
    selected_dung = dung[0]
    clean_sai = list(set([s for s in sai if s != selected_dung]))
    while len(clean_sai) < 3:
        clean_sai.append(rf"$\mathbb{{R}}$") # Dùng rf
    selected_sai = random.sample(clean_sai, 3)
    choices = [r'\True ' + selected_dung] + selected_sai
    random.shuffle(choices)
    
    # Dùng rf và double braces cho \choice
    return (f"\\choice \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def generate():
    x = symbols('x')
    dang = random.choice(['bac_nhat', 'bac_hai'])
    
    if dang == 'bac_nhat':
        a = random.choice([-3, -2, -1, 1, 2, 3])
        b = random.randint(-10, 10)
        f_x = a*x + b
        sol = solve(f_x > 0, x, domain=S.Reals)
        
        # SỬA LỖI TẠI ĐÂY: Dùng rf và double braces cho ký hiệu tập hợp
        dssai = [
            f"${latex(solve(f_x >= 0, x, domain=S.Reals))}$",
            f"${latex(solve(f_x < 0, x, domain=S.Reals))}$",
            rf"$\mathbb{{R}} \setminus \{{ {latex(Fraction(-b, a) if a != 0 else 0)} \}}$"
        ]
        
    else:
        x1 = random.randint(-5, 2)
        x2 = x1 + random.randint(1, 5)
        he_so_a = random.choice([-1, 1])
        f_x = he_so_a * (x - x1) * (x - x2)
        sol = solve(f_x > 0, x, domain=S.Reals)
        
        # Dùng rf cho \mathbb
        dssai = [
            f"${latex(solve(f_x >= 0, x, domain=S.Reals))}$",
            f"${latex(solve(f_x < 0, x, domain=S.Reals))}$",
            rf"$\mathbb{{R}}$"
        ]

    correct_val = f"${latex(sol)}$"
    # Thay thế Union bằng ký hiệu LaTeX chuẩn
    correct_val = correct_val.replace('Interval.open', '').replace('Union', r'\cup')

    toan = nhanvao_dsdungsai_rachoice_motdung([correct_val], dssai)
    co_so = random.choice([2, 3, 5, 10, 'e'])
    
    # Dùng raw string cho các lệnh logarit
    log_name = r"\ln" if co_so == 'e' else (r"\log" if co_so == 10 else rf"\log_{{{co_so}}}")

    return rf"""\begin{{ex}}
Tìm tập xác định $D$ của hàm số $y = {log_name} \left( {latex(f_x)} \right)$.
{toan}
\loigiai{{
Hàm số $y = {log_name} [f(x)]$ xác định khi và chỉ khi $f(x) > 0$.
Ta có: ${latex(f_x)} > 0$.
Giải bất phương trình trên, ta được $x \in {correct_val.replace('$', '')}$.
Vậy tập xác định của hàm số là $D = {correct_val.replace('$', '')}$.
}}
\end{{ex}}"""

print(generate())
