import random
import math

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """
    Trộn 2 đúng, 2 sai. 
    Đảm bảo nhãn \True nằm ngoài $ $ để tránh lỗi biên dịch.
    """
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi: Danh sách dung/sai không đủ phần tử", []]
        
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    
    # Gán nhãn \True cho câu đúng
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Khấu hao máy móc - Hàm số mũ)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ
    P0 = random.choice([400, 500, 600, 800]) # Giá trị ban đầu (triệu đồng)
    h = random.choice([2, 3, 4, 5])          # Chu kỳ bán rã giá trị (năm)
    
    # 2. TÍNH TOÁN CÁC MỐC GIÁ TRỊ
    P_h = P0 * 0.5
    
    year_le = random.randint(1, h)
    month_le = random.choice([3, 6, 9])
    t_le = year_le + month_le/12
    P_le = round(P0 * (0.5)**(t_le/h), 0)
    
    t3 = random.randint(1, 2)
    P_t3 = P0 * (0.5)**(t3/h)
    giam_t3 = round(P0 - P_t3, 0)
    
    P_1 = P0 * (0.5)**(1/h)
    percent_1 = round((1 - P_1/P0) * 100, 1)
    percent_1_str = str(percent_1).replace('.', ',')

    # 3. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} bên trong $ $)
    d1 = f"$\\text{{Giá trị còn lại của máy sau }} {h} \\text{{ năm sử dụng là }} {int(P_h)} \\text{{ triệu đồng}}$"
    d2 = f"$\\text{{Giá trị còn lại của máy sau }} {year_le} \\text{{ năm }} {month_le} \\text{{ tháng sử dụng xấp xỉ }} {int(P_le)} \\text{{ triệu đồng}}$"
    d3 = f"$\\text{{Sau }} {t3} \\text{{ năm đưa vào sử dụng thì giá trị của máy giảm }} {int(giam_t3)} \\text{{ triệu đồng so với ban đầu}}$"
    d4 = f"$\\text{{Sau }} 1 \\text{{ năm đưa vào sử dụng thì giá trị máy giảm khoảng }} {percent_1_str}\\% \\text{{ so với ban đầu của nó}}$"

    s1 = f"$\\text{{Giá trị còn lại của máy sau }} {h} \\text{{ năm sử dụng là }} {int(P_h + 30)} \\text{{ triệu đồng}}$"
    s2 = f"$\\text{{Giá trị còn lại của máy sau }} {year_le} \\text{{ năm }} {month_le} \\text{{ tháng sử dụng là }} {int(P_le - 15)} \\text{{ triệu đồng}}$"
    s3 = f"$\\text{{Sau }} {t3} \\text{{ năm sử dụng, giá trị máy còn lại đúng }} {int(giam_t3)} \\text{{ triệu đồng}}$" 
    s4 = f"$\\text{{Sau }} 1 \\text{{ năm sử dụng, giá trị máy giảm đúng }} {str(round(percent_1 + 4, 1)).replace('.', ',')}\\%$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 4. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_parts = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = f"\\textbf{{Đúng}}. $P({h}) = {P0} \\cdot \\left(\\dfrac{{1}}{{2}}\\right)^{{\\frac{{{h}}}{{{h}}}}} = {int(P_h)}$ triệu đồng."
        elif content == d2:
            note = f"\\textbf{{Đúng}}. Đổi {year_le} năm {month_le} tháng $= {t_le}$ năm. $P({t_le}) = {P0} \\cdot \\left(\\dfrac{{1}}{{2}}\\right)^{{\\frac{{{t_le}}}{{{h}}}}} \\approx {int(P_le)}$ triệu đồng."
        elif content == d3:
            note = f"\\textbf{{Đúng}}. Giá trị sau {t3} năm là $P({t3}) \\approx {int(P_t3)}$. Độ giảm: ${P0} - {int(P_t3)} = {int(giam_t3)}$ triệu đồng."
        elif content == d4:
            note = f"\\textbf{{Đúng}}. Giá trị còn lại sau 1 năm $P(1) = {P0} \\cdot (0,5)^{{1/{h}}} \\approx {int(P_1)}$. Độ giảm: $1 - \\frac{{{int(P_1)}}}{{{P0}}} \\approx {percent_1_str}\\% $."
        elif content == s1:
            note = f"\\textbf{{Sai}}. Giá trị đúng phải là ${int(P_h)}$ triệu đồng."
        elif content == s2:
            note = f"\\textbf{{Sai}}. Giá trị xấp xỉ phải là ${int(P_le)}$ triệu đồng."
        elif content == s3:
            note = f"\\textbf{{Sai}}. Đây là số tiền đã khấu hao (giảm đi), không phải giá trị còn lại."
        elif content == s4:
            note = f"\\textbf{{Sai}}. Tính toán phần trăm giảm cho kết quả xấp xỉ ${percent_1_str}\\%$."
        else: note = ""
        loigiai_parts.append(f"\\itemch {note}")

    # 5. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Tại một xí nghiệp, giá trị còn lại của một chiếc máy sau thời gian $t$ (năm) sử dụng được tính bởi công thức $P(t)={P0} \\cdot \\left(\\dfrac{{1}}{{2}}\\right)^{{\\dfrac{{t}}{{{h}}}}}$, trong đó $P(t)$ tính bằng triệu đồng. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_parts[0]}
            {loigiai_parts[1]}
            {loigiai_parts[2]}
            {loigiai_parts[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde.replace("\\frac", "\\dfrac").replace(".0", "")
