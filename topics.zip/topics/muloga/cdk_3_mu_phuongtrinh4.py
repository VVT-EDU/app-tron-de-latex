import random
from sympy import symbols, Eq, expand, simplify, solveset, latex, sqrt
from decimal import Decimal, ROUND_HALF_UP

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THÔNG SỐ
    x = symbols('x')
    a_val = random.choice([2, 3, 4, 5, 6, 7, 8])
    
    # Thiết lập cơ số liên hợp: a1 = sqrt(1 + a^2) - a và b1 = sqrt(1 + a^2) + a
    # Tích a1 * b1 = (1 + a^2) - a^2 = 1
    expr_inside = 1 + a_val**2
    a1 = sqrt(expr_inside) - a_val
    b1 = sqrt(expr_inside) + a_val
    
    # 2. THIẾT LẬP SỐ MŨ
    # mu1 = (x - a)(x + 2)
    # mu2 = (x - a)(x + a)
    mu1_expr = (x - a_val) * (x + 2)
    mu2_expr = (x - a_val) * (x + a_val)
    
    mu1_expanded = expand(mu1_expr)
    mu2_expanded = expand(mu2_expr)
    
    # 3. PHƯƠNG TRÌNH VÀ GIẢI
    pt1 = Eq(a1**mu1_expanded, b1**mu2_expanded)
    
    # Logic giải: a1 = b1**(-1) => b1**(-mu1) = b1**(mu2) => -mu1 = mu2
    mu1_negated = -mu1_expanded
    pt_logic = Eq(mu1_negated, mu2_expanded)
    pt_final = simplify(Eq(mu1_negated - mu2_expanded, 0))
    
    # Tìm tập nghiệm
    nghiem = solveset(pt_logic, x)
    danh_sach_nghiem = list(nghiem)
    tong_nghiem = sum(danh_sach_nghiem)
    
    # Tính giá trị số để làm tròn
    val_tong = float(tong_nghiem.evalf())
    res_final = int(round_half_up(val_tong, 0))
    
    # 4. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Nhận xét: $({latex(a1)})({latex(b1)}) = 1 \\Rightarrow {latex(a1)} = ({latex(b1)})^{{-1}}$",
        f"Phương trình tương đương: $({latex(b1)})^{{-( {latex(mu1_expanded)} )}} = ({latex(b1)})^{{{latex(mu2_expanded)}}}$",
        f"$\\Leftrightarrow -({latex(mu1_expanded)}) = {latex(mu2_expanded)}$",
        f"$\\Leftrightarrow {latex(pt_final.lhs)} = 0$",
        f"Tập nghiệm của phương trình là $S = \\{{ {', '.join([latex(n) for n in danh_sach_nghiem])} \\}}$",
        f"Vậy tổng các nghiệm là ${latex(tong_nghiem)}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
Cho phương trình ${latex(pt1)}$. Tính tổng các nghiệm của phương trình đã cho.
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

# Thực thi
if __name__ == "__main__":
    print(generate())
