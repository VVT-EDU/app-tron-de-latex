import random

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai theo định dạng \choiceTF."""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Khảo sát hàm Logarit cơ số a < 1 - Qt6 Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ NGẪU NHIÊN
    # Chọn các cơ số đẹp dạng thập phân: 0.2, 0.5, 0.25
    base_info = random.choice([
        {"val": 0.5, "str": "0,5", "point": r"\left(\dfrac{1}{2}; 1\right)"},
        {"val": 0.2, "str": "0,2", "point": r"\left(\dfrac{1}{5}; 1\right)"},
        {"val": 0.25, "str": "0,25", "point": r"\left(\dfrac{1}{4}; 1\right)"}
    ])
    a_str = base_info["str"]
    point_str = base_info["point"]

    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # --- CÁC CÂU ĐÚNG ---
    d1 = f"$\\text{{Hàm số nghịch biến trên khoảng }} (0;+\\infty)$"
    d2 = f"$\\text{{Đồ thị hàm số cắt trục hoành tại điểm }} A(1;0)$"
    d3 = f"$\\text{{Đồ thị hàm số đi qua điểm }} N{point_str}$"
    d4 = f"$\\text{{Tập xác định của hàm số là }} \\mathscr{{D}}=(0;+\\infty)$"
    d5 = f"$\\text{{Trục tung là đường tiệm cận đứng của đồ thị hàm số}}$"

    # --- CÁC CÂU SAI ---
    s1 = f"$\\text{{Hàm số có tập xác định }} \\mathscr{{D}}=\\mathbb{{R}}$"
    s2 = f"$\\text{{Hàm số đồng biến trên khoảng }} (0;+\\infty)$"
    s3 = f"$\\text{{Đồ thị hàm số cắt trục tung tại điểm }} (0;1)$"
    s4 = f"$\\text{{Tập giá trị của hàm số là }} (0;+\\infty)$" # Tập giá trị phải là R
    s5 = f"$\\text{{Đồ thị hàm số đi qua điểm }} M(1; {a_str})$" # Phải là (a; 1)

    dung_list = [d1, d2, d3, d4, d5]
    sai_list = [s1, s2, s3, s4, s5]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = f"\\textbf{{Đúng}}. Do cơ số $a={a_str}<1$ nên hàm số nghịch biến trên tập xác định."
        elif content == d4:
            note = f"\\textbf{{Đúng}}. Điều kiện xác định của hàm lôgarit là biểu thức lấy lôgarit phải dương ($x>0$)."
        elif content == s3:
            note = f"\\textbf{{Sai}}. Đồ thị hàm lôgarit không bao giờ cắt trục tung vì $x$ luôn lớn hơn $0$."
        elif content == s4:
            note = f"\\textbf{{Sai}}. Tập giá trị của hàm số lôgarit là $\\mathbb{{R}}$."
        else:
            note = r"\textbf{Kiểm tra}. Dựa vào các tính chất cơ bản của hàm số lôgarit $y=\log_ax$."
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Cho hàm số $y=\\log_{{{a_str}}} x$. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde
