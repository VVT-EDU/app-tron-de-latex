import random
import sympy as sp
from sympy import symbols, latex, Rational

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ (Đã sửa lỗi định dạng ngoặc nhọn)
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    r"""Trộn 2 đúng, 2 sai và xử lý lỗi Extra } trong LaTeX"""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", ""]
        
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    
    # Quan trọng: Không để khoảng trắng dư thừa sau \True và trước nội dung
    ds_dung = [r'\True ' + item for item in [dung[i] for i in indices_dung]]
    ds_sai = [item for item in [sai[i] for i in indices_sai]]
    
    choices = ds_dung + ds_sai
    random.shuffle(choices)
    
    # Định dạng: Mỗi phương án nằm gọn trong cặp { ... }
    # Lưu ý: Không bọc thêm cặp {} nào bên trong nội dung nếu không cần thiết
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, ""]

# =============================================================================
# HÀM TẠO BÀI TOÁN
# =============================================================================

def generate():
    a, x, y = symbols('a x y', positive=True)
    
    # Tạo hằng đẳng thức đẹp
    k_val = random.choice([3, 4, 5, 6, 7]) 
    gt_2x = k_val**2 - 2                   
    
    # Danh sách các câu Đúng (Không bọc $ trong Python, sẽ bọc ở bước cuối hoặc để nguyên)
    # Ở đây tôi bọc sẵn $...$ để đảm bảo LaTeX nhận diện đúng môi trường toán học
    dung = [
        r"$a^0 = 1 \text{ và } \sqrt[n]{a} = a^{\frac{1}{n}}$",
        f"$\\text{{Nếu }} a^{{2x}} + a^{{-2x}} = {gt_2x} \\text{{ thì }} a^x + a^{{-x}} = {k_val}$",
        r"$\dfrac{a^x}{a^y} = a^{x-y}$",
        r"$(a^x)^y = a^{xy}$"
    ]
    
    # Danh sách các câu Sai
    sai = [
        r"$a^x \cdot a^y = a^{xy}$",
        f"$\\text{{Nếu }} a^{{2x}} + a^{{-2x}} = {gt_2x} \\text{{ thì }} a^x + a^{{-x}} = {k_val - 1}$",
        r"$a^x + a^y = a^{x+y}$",
        r"$\sqrt[n]{a^m} = a^{n-m}$"
    ]
    
    choice_tf, _ = nhanvao_dsdungsai_rachoice_dungsai(dung, sai)
    
    # Lời giải
    loigiai = f"""
    \\begin{{itemchoice}}
        \\itemch Đúng. Ta có $a^0=1$ và $\\sqrt[n]{{a}} = a^{{\\frac{{1}}{{n}}}}$.
        \\itemch Sai. Quy tắc nhân lũy thừa là cộng số mũ.
        \\itemch Đúng. $(a^x+a^{{-x}})^2 = a^{{2x}} + a^{{-2x}} + 2 = {gt_2x} + 2 = {k_val**2}$.
    \\end{{itemchoice}}
    """

    thanhde = f"""\\begin{{ex}}
    Cho số thực dương $a$ ($a \\neq 1$) và hai số thực $x, y$ tùy ý. \\textbf{{Xác định tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{ {loigiai} }}
\\end{{ex}}"""

    return thanhde.replace("\\frac", "\\dfrac")
