import random
from sympy import symbols, simplify, latex, fraction, root, Integer

def generate():
    # 1. THIẾT LẬP BIẾN
    m = symbols('m', positive=True)
    a = random.choice([2, 3, 4, 5])
    
    # Sử dụng m**(1/2) và m**(3/2) nhưng sẽ hiển thị dạng căn thức
    # Hằng đẳng thức: (sqrt(m) + a)(m - a*sqrt(m) + a^2) = sqrt(m)^3 + a^3 = sqrt(m^3) + a^3
    
    # Định nghĩa các thành phần biểu thức
    f1_tu = root(m, 2) + a
    f1_mau = m - a * root(m, 2) + a**2
    
    f2 = 1 / (root(m, 2) + a)
    
    multiplier = (root(m**3, 2) + a**3) / m
    
    # Biểu thức tổng quát P
    ps_initial_expr = (f1_tu / f1_mau - f2) * multiplier
    
    # 2. RÚT GỌN
    # Kết quả rút gọn logic: 
    # Trong ngoặc quy đồng ra: [ (sqrt(m)+a)^2 - (m - a*sqrt(m) + a^2) ] / (sqrt(m^3) + a^3)
    # = [ m + 2a*sqrt(m) + a^2 - m + a*sqrt(m) - a^2 ] / (sqrt(m^3) + a^3)
    # = 3a*sqrt(m) / (sqrt(m^3) + a^3)
    # Nhân với multiplier rút gọn hết mẫu, còn lại 3a*sqrt(m) / m
    
    ps_final = simplify(ps_initial_expr)
    tu, mau = fraction(ps_final)
    
    # 3. TÍNH TOÁN KẾT QUẢ S = k + t - m - (3a-1)sqrt(m) 
    # Để kết quả ra số đẹp (triệt tiêu hết m), ta thiết kế S phù hợp
    # Ở đây k = 3*a*sqrt(m), t = m. Vậy S = k + t - m - 3*a*sqrt(m) = 0
    # Tôi sẽ lấy S = k + t - m để kết quả là 3a*sqrt(m) (vẫn còn căn) 
    # Hoặc S = (k/sqrt(m)) + t - m để ra hằng số 3a.
    
    res_val = 3 * a
    
    # 4. TRÌNH BÀY (Ép kiểu hiển thị căn thức)
    def to_latex_math(expr):
        # Chuyển đổi m**(1/2) thành \sqrt{m} và m**(3/2) thành \sqrt{m^3}
        s = latex(expr)
        s = s.replace('m^{1.5}', r'\sqrt{m^3}').replace('m^{\frac{3}{2}}', r'\sqrt{m^3}')
        s = s.replace('m^{0.5}', r'\sqrt{m}').replace('m^{\frac{1}{2}}', r'\sqrt{m}')
        return s

    y_list = [
        rf"Bước 1: Quy đồng mẫu thức trong ngoặc với mẫu chung là $(\sqrt{{m}} + {a})(m - {a}\sqrt{{m}} + {a^2}) = \sqrt{{m^3}} + {a**3}$.",
        rf"Bước 2: Rút gọn biểu thức trong ngoặc:",
        rf"$A = \frac{{(\sqrt{{m}} + {a})^2 - (m - {a}\sqrt{{m}} + {a^2})}}{{\sqrt{{m^3}} + {a**3}}} = \frac{{m + {2*a}\sqrt{{m}} + {a^2} - m + {a}\sqrt{{m}} - {a^2}}}{{\sqrt{{m^3}} + {a**3}}} = \frac{{{3*a}\sqrt{{m}}}}{{\sqrt{{m^3}} + {a**3}}}$.",
        rf"Bước 3: Nhân với biểu thức bên ngoài: $P = \frac{{{3*a}\sqrt{{m}}}}{{\sqrt{{m^3}} + {a**3}}} \cdot \frac{{\sqrt{{m^3}} + {a**3}}}{{m}} = \frac{{{3*a}\sqrt{{m}}}}{{m}}$.",
        rf"Bước 4: Xác định tử $k = {to_latex_math(tu)}$ và mẫu $t = {to_latex_math(mau)}$.",
        rf"Bước 5: Tính $S = \frac{{k}}{{\sqrt{{m}}}} + t - m = \frac{{{3*a}\sqrt{{m}}}}{{\sqrt{{m}}}} + m - m = {res_val}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    return rf"""\begin{{ex}}
Cho biểu thức $P = \left( \frac{{\sqrt{{m}} + {a}}}{{m - {a}\sqrt{{m}} + {a^2}}} - \frac{{1}}{{\sqrt{{m}} + {a}}} \right) \cdot \frac{{\sqrt{{m^3}} + {a**3}}}{{m}}$ (với $m > 0$).
Biến đổi $P$ về dạng phân thức $\frac{{k}}{{t}}$. Tính giá trị của biểu thức $S = \frac{{k}}{{\sqrt{{m}}}} + t - m$.
\shortans{{ ${res_val}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
