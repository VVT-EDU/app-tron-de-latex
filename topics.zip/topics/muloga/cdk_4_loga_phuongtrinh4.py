import random
from sympy import symbols, log, Eq, expand, solve, latex, S, Intersection, simplify
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THÔNG SỐ
    x = symbols('x')
    h_value = random.randint(1, 5)
    a = 2 * h_value + 1
    
    # Biểu thức mũ mu = a*x^2 + (1-a)*x
    mu = a*x**2 + (1-a)*x
    
    # 2. XÂY DỰNG PHƯƠNG TRÌNH
    # pt: log10(a^mu - a + 10) = 1
    # Trong SymPy, log(x, 10) là logarit cơ số 10
    bieu_thuc_trong_log = a**mu - a + 10
    pt = Eq(log(bieu_thuc_trong_log, 10), 1)
    
    # 3. CÁC BƯỚC GIẢI CHI TIẾT
    # Bước 1: Khử logarit: a^mu - a + 10 = 10^1
    pt_buoc1 = Eq(bieu_thuc_trong_log, 10)
    
    # Bước 2: Đưa về phương trình mũ cơ bản: a^mu = a
    pt_buoc2 = Eq(a**mu, a)
    
    # Bước 3: So sánh số mũ: mu = 1
    pt_buoc3 = Eq(mu, 1)
    
    # Bước 4: Giải phương trình bậc hai: ax^2 + (1-a)x - 1 = 0
    pt_bac2 = Eq(expand(mu - 1), 0)
    nghiem = solve(pt_bac2, x)
    
    # 4. TÍNH TỔNG NGHIỆM VÀ KIỂM TRA
    dk = S.Reals # Logarit xác định khi a^mu - a + 10 > 0. Với a^mu = a, biểu thức = 10 > 0 (TM)
    tap_nghiem = set(nghiem)
    tong_nghiem = sum(list(tap_nghiem))
    
    # Kết quả số học
    res_final = int(round_half_up(float(tong_nghiem.evalf()), 0))
    
    # 5. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Phương trình đã cho: ${latex(pt)}$",
        f"$\\Leftrightarrow {latex(pt_buoc1)}$",
        f"$\\Leftrightarrow {latex(pt_buoc2)}$",
        f"$\\Leftrightarrow {latex(pt_buoc3)}$",
        f"$\\Leftrightarrow {latex(pt_bac2)}$",
        f"$\\Leftrightarrow x = {latex(nghiem[0])} \\text{{ hoặc }} x = {latex(nghiem[1])}$",
        f"Thử lại, ta có tập nghiệm $S = \\{{ {', '.join([latex(n) for n in tap_nghiem])} \\}}$",
        f"Vậy tổng các nghiệm là ${latex(tong_nghiem)}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 6. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
Cho phương trình ${latex(pt)}$. Tính tổng các nghiệm của phương trình đã cho.
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
