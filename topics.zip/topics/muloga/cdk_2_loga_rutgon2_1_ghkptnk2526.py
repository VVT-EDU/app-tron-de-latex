import random
from sympy import symbols, log, simplify, logcombine, latex, sqrt, Rational
from decimal import Decimal, ROUND_HALF_UP

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THÔNG SỐ
    # m là số thực dương để logarit và logcombine hoạt động chuẩn xác
    m = symbols('m', positive=True)
    k_sym = symbols('k')
    
    # Chọn ngẫu nhiên h_value để tạo mu = 2h + 1
    h_value = random.randint(1, 5)
    mu = 2 * h_value + 1
    
    # 2. XÂY DỰNG BIỂU THỨC BAN ĐẦU
    # bt = log(m) + log(m^mu) - log(m^(1/mu))
    bt1 = log(m)
    bt2 = log(m**mu)
    bt3 = log(m**(Rational(1, mu))) # Dùng Rational để giữ phân số 1/mu
    
    bt_sum = bt1 + bt2 - bt3
    
    # 3. RÚT GỌN VÀ TRÍCH XUẤT k
    # Bước 1: Simplify biểu thức tổng quát
    bt_simplified = simplify(bt_sum)
    # Bước 2: Dùng logcombine với force=True để đưa các hệ số vào trong số mũ
    bt_combined = logcombine(bt_simplified, force=True)
    
    # Trích xuất số mũ k từ m^k bên trong log(m^k)
    # bt_combined thường có dạng log(m^k), nên args[0] chính là m^k
    inside_log = bt_combined.args[0]
    powers_dict = inside_log.as_powers_dict()
    sok = powers_dict.get(m, 0) # Giá trị k cần tìm
    
    # 4. TÍNH TOÁN KẾT QUẢ LÀM TRÒN (Nếu cần)
    val_k = float(sok.evalf())
    res_final = round_half_up(val_k, 2) # Làm tròn đến 2 chữ số thập phân để hiển thị

    # 5. TRÌNH BÀY NỘI DUNG CÂU HỎI
    M_target = log(m**k_sym)
    bai = f"Với $m$ là số thực dương. Rút gọn biểu thức $M = {latex(bt_sum)}$ ta được $M = {latex(M_target)}$."
    cau_hoi = f"{bai} Tính giá trị của tham số $k$."
    
    # 6. TRÌNH BÀY LỜI GIẢI
    # Các bước biến đổi logarit
    y_list = [
        f"Ta có: $M = {latex(bt1)} + {latex(bt2)} - {latex(bt3)}$",
        f"Áp dụng quy tắc logarit: $M = \\ln(m) + {mu}\\ln(m) - \\frac{{1}}{{{mu}}}\\ln(m)$",
        f"Rút gọn hệ số: $M = \\left( 1 + {mu} - \\frac{{1}}{{{mu}}} \\right) \\ln(m)$",
        f"Đưa hệ số vào trong logarit: $M = {latex(bt_combined)}$",
        f"Đối chiếu với dạng $M = {latex(M_target)}$, ta có $k = {latex(sok)}$"
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 7. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
{cau_hoi}
\shortans{{ ${latex(sok)}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

# Thực thi hàm
if __name__ == "__main__":
    print(generate())
