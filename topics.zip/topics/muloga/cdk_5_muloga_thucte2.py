import random
from sympy import symbols, Eq, solve, latex, Rational, sqrt, simplify
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP THAM SỐ
    t = symbols('t')
    soluongbandau = random.choice([1000, 2000, 3000, 4000, 5000])
    ngay = random.choice([4, 6, 8]) # Chọn số ngày chẵn để tính toán đẹp hơn
    tang_rate = random.choice([0.1, 0.15, 0.2, 0.25]) # Tỉ lệ tăng (10% - 25%)
    
    phantramtang = int(tang_rate * 100)
    p0 = Rational(soluongbandau)
    
    # Số lượng sau 2 ngày: P(2) = p0 * (1 + tang_rate)
    p2 = simplify(p0 * (1 + tang_rate))
    
    # 2. XÁC ĐỊNH THAM SỐ a
    # P(2) = P0 * a^2 => a = sqrt(P2/P0)
    a_val = sqrt(p2 / p0)
    
    # 3. TÍNH TOÁN KẾT QUẢ
    # P(t) = P0 * a^t
    pt_func = p0 * a_val**t
    pt_ngay = pt_func.subs(t, ngay)
    
    kq_so_thuc = float(pt_ngay.evalf())
    kq_lam_tron = int(round_half_up(kq_so_thuc, 0))
    
    # 4. TRÌNH BÀY LỜI GIẢI
    bai_tap = (
        f"Thực hiện một mẻ nuôi cấy vi khuẩn với ${soluongbandau}$ vi khuẩn ban đầu. "
        f"Nhà sinh học phát hiện ra số lượng vi khuẩn tăng thêm ${phantramtang}\\%$ sau mỗi hai ngày. "
        f"Công thức $P(t)=P_0 \\cdot a^t$ cho phép tính số lượng vi khuẩn sau $t$ ngày kể từ thời điểm ban đầu. "
        f"Xác định các tham số $P_0, a$ và tính số lượng vi khuẩn sau ${ngay}$ ngày."
    )

    y_list = [
        f"Tại thời điểm ban đầu ($t=0$), ta có $P(0) = P_0 = {soluongbandau}$.",
        f"Sau hai ngày ($t=2$), số lượng vi khuẩn là: $P(2) = {soluongbandau} + {phantramtang}\\% \\cdot {soluongbandau} = {p2}$.",
        f"Theo công thức $P(t) = P_0 \\cdot a^t$, ta có: ${soluongbandau} \\cdot a^2 = {p2}$",
        f"$\\Rightarrow a^2 = \\frac{{{p2}}}{{{soluongbandau}}} = {float(p2/p0)} \\Rightarrow a = {latex(a_val)} \\approx {float(a_val):.4f}$.",
        f"Vậy hàm số là $P(t) = {soluongbandau} \\cdot \\left({latex(a_val)}\\right)^t$.",
        f"Số lượng vi khuẩn sau ${ngay}$ ngày là: $P({ngay}) = {soluongbandau} \\cdot \\left({latex(a_val)}\\right)^{ngay} = {latex(pt_ngay)}$.",
        f"Sử dụng máy tính bỏ túi, ta được $P({ngay}) \\approx {kq_lam_tron}$ vi khuẩn."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
{bai_tap}
\shortans{{ ${kq_lam_tron}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
