import random

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    r"""
    Trộn 2 đúng, 2 sai theo định dạng \choiceTF.
    """
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
        
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Tập xác định & Tập giá trị hàm hợp - Qt6 Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ
    k_year = 2026
    base_g = random.choice([2, 3, 5])
    
    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # --- CÂU ĐÚNG ---
    d1 = f"$\\text{{Hàm số }} f(x)=\\ln(x^{{{k_year}}}+1) \\text{{ có tập giá trị là }} [0;+\\infty)$"
    d2 = f"$\\text{{Hàm số }} g(x)={base_g}^{{x^2+1}} \\text{{ có tập xác định là }} \\mathbb{{R}}$"
    d3 = f"$\\text{{Hàm số }} g(x)={base_g}^{{x^2+1}} \\text{{ có tập giá trị là }} [{base_g};+\\infty)$"
    d4 = f"$\\text{{Với mọi }} x \\in \\mathbb{{R}}, \\text{{ biểu thức }} x^{{{k_year}}}+1 \\text{{ luôn dương nên }} f(x) \\text{{ xác định trên }} \\mathbb{{R}}$"

    # --- CÂU SAI ---
    s1 = f"$\\text{{Hàm số }} f(x)=\\ln(x^{{{k_year}}}+1) \\text{{ có tập xác định là }} (0;+\\infty)$"
    s2 = f"$\\text{{Tập giá trị của hàm số }} g(x)={base_g}^{{x^2+1}} \\text{{ là }} (0;+\\infty)$" # Quên điều kiện x^2+1 >= 1
    s3 = f"$\\text{{Hàm số }} f(x) \\text{{ đạt giá trị nhỏ nhất tại }} x=1$" # Phải là x=0
    s4 = f"$\\text{{Hàm số }} g(x) \\text{{ nghịch biến trên khoảng }} (0;+\\infty)$" # Phải là đồng biến

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = f"\\textbf{{Đúng}}. Vì $x^{{{k_year}}} \\ge 0 \\Rightarrow x^{{{k_year}}}+1 \\ge 1 \\Rightarrow \\ln(x^{{{k_year}}}+1) \\ge \\ln 1 = 0$. Tập giá trị là $[0;+\\infty)$."
        elif content == d2:
            note = f"\\textbf{{Đúng}}. Số mũ $x^2+1$ xác định với mọi $x \\in \\mathbb{{R}}$."
        elif content == d3:
            note = f"\\textbf{{Đúng}}. Vì $x^2+1 \\ge 1 \\Rightarrow {base_g}^{{x^2+1}} \\ge {base_g}^1 = {base_g}$."
        elif content == d4:
            note = f"\\textbf{{Đúng}}. Do ${k_year}$ là số chẵn nên $x^{{{k_year}}} \\ge 0 \\Rightarrow x^{{{k_year}}}+1 \\ge 1 > 0$ với mọi $x$."
        elif content == s1:
            note = f"\\textbf{{Sai}}. Hàm số xác định với mọi $x \\in \\mathbb{{R}}$ vì $x^{{{k_year}}}+1 > 0$ với mọi $x$."
        elif content == s2:
            note = f"\\textbf{{Sai}}. Vì $x^2+1 \\ge 1$ nên tập giá trị phải bắt đầu từ ${base_g}^1 = {base_g}$."
        elif content == s3:
            note = f"\\textbf{{Sai}}. Hàm số $f(x)$ đạt giá trị nhỏ nhất là $0$ khi $x^{{{k_year}}}+1=1 \\Leftrightarrow x=0$."
        elif content == s4:
            note = f"\\textbf{{Sai}}. Với $x > 0$, khi $x$ tăng thì $x^2+1$ tăng, dẫn đến $g(x)$ đồng biến."
        else:
            note = ""
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Cho hai hàm số $f(x)=\\ln(x^{{{k_year}}}+1)$ và $g(x)={base_g}^{{x^2+1}}$. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde
