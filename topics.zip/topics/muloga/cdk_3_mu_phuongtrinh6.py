import random
from sympy import symbols, Eq, expand, simplify, solve, latex, Rational
from decimal import Decimal, ROUND_HALF_UP

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THÔNG SỐ
    x, t = symbols('x t')
    h_value = random.randint(1, 4)
    
    a = Rational(h_value + 1)
    mu1 = Rational(1, 2) + a/2
    mu2 = Rational(1, 2)
    
    # Ẩn phụ t = 2^x
    bphu = 2**x
    
    # 2. XÂY DỰNG PHƯƠNG TRÌNH THEO t (Bậc 3)
    val_t1 = 2**mu1
    val_t2 = 2**mu2
    val_t3 = -2**mu2 # Nghiệm âm để học sinh loại
    
    t1, t2, t3 = t - val_t1, t - val_t2, t - val_t3
    
    btt = expand(t1 * t2 * t3)
    ptt = Eq(btt, 0)      # Phương trình t khai triển
    ptt_factored = Eq(t1 * t2 * t3, 0) # Phương trình t dạng tích
    
    # 3. GIẢI VÀ TÌM NGHIỆM X
    # Giải phương trình bậc 3 theo t
    ngt = solve(ptt_factored, t)
    ngt_sorted = sorted(ngt) # Sắp xếp nghiệm t
    
    # Thay t = 2^x vào phương trình gốc
    pt_x = ptt.subs(t, bphu)
    
    # Tìm nghiệm x thực (chỉ nhận t > 0)
    nghiem_x = []
    for t_val in ngt:
        if t_val > 0:
            sol_x = solve(Eq(bphu, t_val), x)
            nghiem_x.extend(sol_x)
            
    nghiem_x = [simplify(sol) for sol in nghiem_x]
    tap_nghiem = set(nghiem_x)
    tong_nghiem = sum(tap_nghiem)
    
    # Tính toán giá trị làm tròn
    val_tong = float(tong_nghiem.evalf())
    res_final = int(round_half_up(val_tong, 0))
    
    # 4. TRÌNH BÀY LỜI GIẢI
    # Xác định các nghiệm t để trình bày (ngt_sorted thường là [âm, dương, dương])
    t_am = ngt_sorted[0]
    t_duong1 = ngt_sorted[1]
    t_duong2 = ngt_sorted[2]

    y_list = [
        f"Phương trình đã cho: ${latex(pt_x)} = 0$",
        f"Đặt $t = {latex(bphu)}$ (điều kiện $t > 0$).",
        f"Phương trình trở thành: ${latex(ptt)}$",
        f"$\\Leftrightarrow {latex(ptt_factored)}$",
        f"$\\Leftrightarrow t = {latex(t_am)} \\text{{ (loại)}}; \\quad t = {latex(t_duong1)}; \\quad t = {latex(t_duong2)}$.",
        f"Với $t = {latex(t_duong1)} \\Rightarrow {latex(bphu)} = {latex(t_duong1)} \\Rightarrow x = {latex(solve(Eq(bphu, t_duong1), x)[0])}$.",
        f"Với $t = {latex(t_duong2)} \\Rightarrow {latex(bphu)} = {latex(t_duong2)} \\Rightarrow x = {latex(solve(Eq(bphu, t_duong2), x)[0])}$.",
        f"Tập nghiệm của phương trình là $S = \\{{ {', '.join([latex(n) for n in tap_nghiem])} \\}}$.",
        f"Vậy tổng các nghiệm là ${latex(tong_nghiem)}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
Cho phương trình ${latex(pt_x)} = 0$. Tính tổng các nghiệm thực của phương trình đã cho.
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
