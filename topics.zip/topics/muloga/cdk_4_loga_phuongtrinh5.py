import random
from sympy import symbols, log, Eq, expand, solve, latex, solveset, Interval, oo, Intersection, S, simplify

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    from decimal import Decimal, ROUND_HALF_UP
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THAM SỐ
    x = symbols('x')
    h_value = random.randint(1, 4)
    a = 2 * h_value + 1  # Đảm bảo a là số lẻ > 1
    
    # Biểu thức trong logarit
    bt1 = x**2 - a*x + a**2
    bt2 = x + a
    
    # 2. TÌM ĐIỀU KIỆN XÁC ĐỊNH (DK)
    # bt1 luôn dương vì biệt thức Delta = a^2 - 4a^2 = -3a^2 < 0 và hệ số x^2 > 0
    dk1 = solveset(bt1 > 0, x, domain=S.Reals)
    dk2 = solveset(bt2 > 0, x, domain=S.Reals)
    dk = Intersection(dk1, dk2)
    
    # 3. THIẾT LẬP PHƯƠNG TRÌNH VÀ CÁC BƯỚC GIẢI
    # log_a(bt1) - log_a(bt2) = 1
    bai = f"\\log_{{{a}}}{{({latex(bt1)})}} - \\log_{{{a}}}{{({latex(bt2)})}} = 1"
    
    # Bước 1: Logarit của một thương
    y1 = f"$\\Leftrightarrow \\log_{{{a}}}{{\\frac{{{latex(bt1)}}}{{{latex(bt2)}}}}} = 1$"
    
    # Bước 2: Khử logarit: bt1/bt2 = a^1
    y2 = f"$\\Leftrightarrow \\frac{{{latex(bt1)}}}{{{latex(bt2)}}} = {a}$"
    
    # Bước 3: Quy đồng và rút gọn
    # (x^2 - ax + a^2) = a(x + a) => x^2 - ax + a^2 = ax + a^2 => x^2 - 2ax = 0
    pt_he_qua = Eq(bt1, a * bt2)
    pt_rut_gon = simplify(bt1 - a * bt2)
    y3 = f"$\\Leftrightarrow {latex(expand(pt_rut_gon))} = 0$"
    
    # 4. GIẢI VÀ KIỂM TRA NGHIỆM
    nghiem_tho = solve(Eq(pt_rut_gon, 0), x)
    nghiem_set = set(nghiem_tho)
    
    # Lọc nghiệm theo điều kiện
    tap_nghiem_thuc = Intersection(dk, nghiem_set)
    danh_sach_nghiem = list(tap_nghiem_thuc)
    tong_nghiem = sum(danh_sach_nghiem)
    
    # Trình bày nghiệm
    str_nghiem = "; ".join([f"x = {latex(n)}" for n in sorted(danh_sach_nghiem)])
    
    # 5. TỔNG HỢP LỜI GIẢI
    y_list = [
        f"Phương trình: {bai}",
        f"Điều kiện xác định: $x > -{a}$",
        y1,
        y2,
        y3,
        f"$\\Leftrightarrow {str_nghiem}$ (thỏa mãn điều kiện)",
        f"Tập nghiệm của phương trình là $S = \\{{ {', '.join([latex(n) for n in danh_sach_nghiem])} \\}}$",
        f"Vậy tổng các nghiệm là ${latex(tong_nghiem)}$"
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 6. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
Cho phương trình ${bai}$. Tính tổng các nghiệm của phương trình đã cho.
\shortans{{ ${latex(tong_nghiem)}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
