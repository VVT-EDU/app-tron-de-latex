import random
from sympy import symbols, simplify, latex, fraction, root, Integer

def generate():
    # 1. THIẾT LẬP BIẾN
    m = symbols('m', positive=True)
    a_val = random.choice([2, 3, 4, 5])
    a_pow3 = a_val**3
    
    # Định nghĩa căn bậc 3 để dùng trong trình bày
    # Chúng ta dùng root(m, 3) để Sympy hiểu bản chất toán học
    cb3 = root(m, 3)
    
    # Thiết lập biểu thức P theo hằng đẳng thức (a-b)(a^2 + ab + b^2) = a^3 - b^3
    # P = [ (m - a^3) / (sqrt[3]{m} - a) ] - sqrt[3]{m^2}
    # Biến đổi: (sqrt[3]{m} - a)(sqrt[3]{m^2} + a*sqrt[3]{m} + a^2) / (sqrt[3]{m} - a) - sqrt[3]{m^2}
    # Kết quả rút gọn sẽ là: a*sqrt[3]{m} + a^2
    
    tu_1 = m - a_pow3
    mau_1 = cb3 - a_val
    ps1 = tu_1 / mau_1
    
    # Biểu thức P hoàn chỉnh
    ps_initial_expr = ps1 - cb3**2
    
    # 2. RÚT GỌN CHẶT CHẼ
    # ps_final sẽ là a*m^(1/3) + a^2
    ps_final = simplify(ps_initial_expr)
    
    # Lấy tử và mẫu của phân thức cuối cùng
    # Lưu ý: Sympy có thể để mẫu là 1
    tu, mau = fraction(ps_final)
    
    # 3. TÍNH TOÁN KẾT QUẢ S = k + t - m^(1/3)
    # Ở trình độ lớp 11, ta thường yêu cầu tính giá trị biểu thức không còn m
    # Ta đặt k = tử, t = mẫu. Tính S = k - a*root(m,3) + t
    S_expr = simplify(tu - a_val * cb3 + mau)
    res_final = int(S_expr.evalf())

    # 4. TRÌNH BÀY (Ép kiểu hiển thị căn bậc 3)
    # Sử dụng replace để đảm bảo latex luôn ra dạng \sqrt[3]{...}
    def to_latex_root(expr):
        return latex(expr).replace('m^{1/3}', r'\sqrt[3]{m}').replace('m^{2/3}', r'\sqrt[3]{m^2}')

    y_list = [
        f"Cho biểu thức $P = {to_latex_root(ps_initial_expr)}$",
        f"Ta có hằng đẳng thức: $m - {a_pow3} = (\\sqrt[3]{{m}} - {a_val})(\\sqrt[3]{{m^2}} + {a_val}\\sqrt[3]{{m}} + {a_val**2})$",
        f"Khi đó: $P = \\frac{{(\\sqrt[3]{{m}} - {a_val})(\\sqrt[3]{{m^2}} + {a_val}\\sqrt[3]{{m}} + {a_val**2})}}{{\\sqrt[3]{{m}} - {a_val}}} - \\sqrt[3]{{m^2}}$",
        f"Rút gọn ta được: $P = \\sqrt[3]{{m^2}} + {a_val}\\sqrt[3]{{m}} + {a_val**2} - \\sqrt[3]{{m^2}} = {to_latex_root(ps_final)}$",
        f"Đối chiếu $P = \\frac{{k}}{{t}}$, ta có $k = {to_latex_root(tu)}$ và $t = {to_latex_root(mau)}$",
        f"Vậy $S = k - {a_val}\\sqrt[3]{{m}} + t = ({to_latex_root(tu)}) - {a_val}\\sqrt[3]{{m}} + {to_latex_root(mau)} = {res_final}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    return rf"""\begin{{ex}}
Cho biểu thức $P = {to_latex_root(ps_initial_expr)}$ (với $m > 0, m \neq {a_pow3}$). 
Biến đổi $P$ về dạng phân thức $P = \frac{{k}}{{t}}$. Tính giá trị biểu thức $S = k - {a_val}\sqrt[3]{{m}} + t$.
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
