import random
from sympy import symbols, latex, Rational, simplify

def vn_format(number):
    """Định dạng số theo chuẩn Việt Nam, bọc trong $ $."""
    str_num = str(number)
    if '/' in str_num: 
        return f"${latex(number)}$"
    if '.' in str_num:
        parts = str_num.split('.')
        return f"${parts[0]},{parts[1]}$"
    return f"${str_num}$"

def generate():
    # 1. THIẾT LẬP BIẾN VÀ SỐ MŨ
    x, y = symbols('x y')
    # Chọn mẫu số m từ 2 đến 5
    m = random.choice([2, 3, 4, 5])
    
    # Thiết kế số mũ a, b sao cho khác 0
    # Ví dụ: P = (x^3 * y) / (x * y^2) toàn bộ căn bậc m
    # a = (3-1)/m = 2/m, b = (1-2)/m = -1/m
    a = Rational(2, m)
    b = Rational(-1, m)
    
    # 2. TẠO HỆ SỐ k, h KHÁC 0 SAO CHO T LÀ SỐ TỰ NHIÊN
    # k và h phải là bội của m để khử mẫu
    k_coeff = random.randint(1, 3)
    h_coeff = random.randint(1, 3)
    
    k = k_coeff * m
    h = h_coeff * m
    
    # Tính T = ka + hb = k*(2/m) + h*(-1/m) = 2*k_coeff - h_coeff
    # Đảm bảo T > 0 để là số tự nhiên
    if 2 * k_coeff <= h_coeff:
        k_coeff += 2 # Điều chỉnh để T luôn dương
        k = k_coeff * m
        
    T_val = int(k * a + h * b)
    name = random.choice(['P', 'Q', 'A', 'M', 'N'])
    
    # 3. TRÌNH BÀY NỘI DUNG
    bai_tap = (
        rf"Cho biểu thức ${name} = \sqrt[{m}]{{\dfrac{{x^3 y}}{{x y^2}}}}$ với $x, y > 0$. "
        rf"Biết rằng biểu thức ${name}$ được rút gọn về dạng $x^a y^b$. "
        rf"Giá trị của biểu thức $T = {k}a + {h}b$ bằng bao nhiêu?"
    )

    return rf"""\begin{{ex}}
{bai_tap}
\shortans{{ {T_val} }}
\loigiai{{
    Biến đổi biểu thức ${name}$ về dạng lũy thừa với số mũ hữu tỉ:
    \begin{{itemize}}
        \item Ta có: ${name} = \left( \dfrac{{x^3 y}}{{x y^2}} \right)^{{1/{m}}} = \left( x^2 y^{{-1}} \right)^{{1/{m}}}$.
        \item Suy ra: ${name} = x^{{2/{m}}} \cdot y^{{-1/{m}}}$.
        \item Từ đó ta xác định được: $a = {vn_format(a)}$ và $b = {vn_format(b)}$.
        \item Tính giá trị biểu thức $T$:
        \item $T = {k} \cdot \left( {latex(a)} \right) + {h} \cdot \left( {latex(b)} \right) = {2 * k_coeff} - {h_coeff} = {T_val}$.
    \end{{itemize}}
    Vậy giá trị của $T$ là {vn_format(T_val)}.
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
