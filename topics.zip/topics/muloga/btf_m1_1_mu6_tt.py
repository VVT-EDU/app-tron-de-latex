import random
import math

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    r"""Trộn 2 đúng, 2 sai theo định dạng \choiceTF."""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Gửi tiết kiệm nhập gốc - Qt6 Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ NGẪU NHIÊN
    P = random.choice([200, 300, 400, 500, 600]) # Số tiền gốc (triệu)
    r_val = random.choice([0.45, 0.5, 0.55, 0.6]) # Lãi suất (%)
    r = r_val / 100
    r_str = str(r_val).replace('.', ',')

    # Tính toán các mốc dữ liệu
    # Mốc 5 tháng
    P5 = round(P * (1 + r)**5, 1)
    # Mốc 12 tháng (1 năm)
    P12 = round(P * (1 + r)**12, 1)
    # Mốc gấp đôi (P_n = 2P => n = log(2)/log(1+r))
    n_double = math.ceil(math.log(2) / math.log(1 + r))
    # Mốc 3 năm (36 tháng)
    P36 = round(P * (1 + r)**36, 1)
    target_3y = math.ceil(P36 / 10) * 10 # Số tròn chục gần nhất với P36

    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # --- CÁC CÂU ĐÚNG ---
    d1 = f"$\\text{{Sau đúng }} 5 \\text{{ tháng, số tiền lãnh được là }} {str(P5).replace('.', ',')} \\text{{ triệu đồng}}$"
    d2 = f"$\\text{{Sau đúng }} 1 \\text{{ năm, số tiền lãnh được là }} {str(P12).replace('.', ',')} \\text{{ triệu đồng}}$"
    d3 = f"$\\text{{Để lãnh được số tiền gấp đôi số tiền gốc ban đầu, cần gửi ít nhất }} {n_double} \\text{{ tháng}}$"
    d4 = f"$\\text{{Tổng số tiền sau }} n \\text{{ tháng gửi được tính theo công thức }} P_n = {P} \\cdot (1 + {r})^n$"

    # --- CÁC CÂU SAI ---
    s1 = f"$\\text{{Sau đúng }} 1 \\text{{ năm, số tiền lãnh được là }} {str(round(P12 + 5, 1)).replace('.', ',')} \\text{{ triệu đồng}}$"
    s2 = f"$\\text{{Nếu gửi đúng }} 3 \\text{{ năm thì số tiền nhận được là }} {target_3y} \\text{{ triệu đồng}}$"
    s3 = f"$\\text{{Sau mỗi tháng, số tiền lãi được cộng vào vốn nên sau 2 tháng lãi suất tăng lên }} {r_val * 2}\\%$ "
    s4 = f"$\\text{{Chỉ cần gửi ngân hàng }} {n_double - 30} \\text{{ tháng để số tiền tăng gấp đôi}}$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = f"\\textbf{{Đúng}}. $P_5 = {P} \\cdot (1 + {r})^5 \\approx {str(P5).replace('.', ',')}$."
        elif content == d2:
            note = f"\\textbf{{Đúng}}. $P_{{12}} = {P} \\cdot (1 + {r})^{{12}} \\approx {str(P12).replace('.', ',')}$."
        elif content == d3:
            note = f"\\textbf{{Đúng}}. $P_n \\ge 2 \\cdot {P} \\Leftrightarrow (1+{r})^n \\ge 2 \\Rightarrow n \\ge \\log_{{1+{r}}}2 \\approx {round(math.log(2)/math.log(1+r), 2)} \\Rightarrow n={n_double}$."
        elif content == s2:
            note = f"\\textbf{{Sai}}. Sau 3 năm (36 tháng), số tiền là $P_{{36}} = {P} \\cdot (1 + {r})^{{36}} \\approx {str(P36).replace('.', ',')}$, không bằng ${target_3y}$."
        elif content == s3:
            note = f"\\textbf{{Sai}}. Lãi suất hàng tháng là cố định $r = {r_str}\\%$, chỉ có tiền gốc thay đổi."
        else:
            note = r"\textbf{Kiểm tra}. Sử dụng công thức $A = P(1+r)^n$ với $r$ là lãi suất mỗi kỳ hạn."
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Ông Dũng gửi số tiền ${P}$ triệu đồng vào ngân hàng với lãi suất ${r_str}\\%/\\text{{tháng}}$. Biết rằng nếu không rút tiền ra khỏi ngân hàng thì cứ sau mỗi tháng, số tiền lãi sẽ được nhập vào vốn ban đầu. Trong suốt quá trình gửi ông không rút tiền ra và lãi suất không thay đổi. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde
