import random
from sympy import symbols, Eq, expand, simplify, solveset, latex
from decimal import Decimal, ROUND_HALF_UP

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THÔNG SỐ
    x = symbols('x')
    a_val = random.choice([2, 3, 4, 5])  # Tham số trong số mũ
    base_val = random.choice([2, 3, 5])   # Cơ số a1
    base_sq = base_val**2                 # Cơ số b1 = a1^2
    
    # 2. XÂY DỰNG CÁC BIỂU THỨC MŨ
    # mu1 = (x - a)(x - 2a)
    # mu2 = (x - a)(x + a)
    mu1 = (x - a_val) * (x - 2 * a_val)
    mu2 = (x - a_val) * (x + a_val)
    
    # Phương trình ban đầu: base_val^mu1 = base_sq^mu2
    pt1 = Eq(base_val**expand(mu1), base_sq**expand(mu2))
    
    # 3. GIẢI PHƯƠNG TRÌNH
    # Đưa về cùng cơ số base_val: base_val^mu1 = base_val^(2*mu2)
    # Suy ra mu1 = 2 * mu2
    mu1_expanded = expand(mu1)
    mu2_doubled = expand(2 * mu2)
    
    pt_logic = Eq(mu1_expanded, mu2_doubled)
    pt_simplified = simplify(Eq(mu1_expanded - mu2_doubled, 0))
    
    # Tìm tập nghiệm
    nghiem = solveset(pt_logic, x)
    danh_sach_nghiem = list(nghiem)
    tong_nghiem = sum(danh_sach_nghiem)
    
    # Làm tròn kết quả
    res_final = int(round_half_up(float(tong_nghiem), 0))
    
    # 4. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Phương trình đã cho: ${latex(pt1)}$",
        f"Đưa về cùng cơ số ${base_val}$: ${base_val}^{{{latex(mu1_expanded)}}} = ({base_val}^2)^{{{latex(expand(mu2))}}}$",
        f"$\\Leftrightarrow {base_val}^{{{latex(mu1_expanded)}}} = {base_val}^{{{latex(mu2_doubled)}}}$",
        f"$\\Leftrightarrow {latex(mu1_expanded)} = {latex(mu2_doubled)}$",
        f"$\\Leftrightarrow {latex(pt_simplified.lhs)} = 0$",
        f"Tập nghiệm của phương trình là $S = \\{{ {', '.join([latex(n) for n in danh_sach_nghiem])} \\}}$",
        f"Vậy tổng các nghiệm là ${latex(tong_nghiem)}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
Cho phương trình ${latex(pt1)}$. Tính tổng các nghiệm của phương trình đã cho (làm tròn đến hàng đơn vị).
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

# Thực thi
if __name__ == "__main__":
    print(generate())
