import random
from fractions import Fraction

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    all_indices = random.sample(range(6), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    choices = [r'\True ' + dung[i] for i in idx_dung] + [sai[i] for i in idx_sai]
    random.shuffle(choices)
    return f"\\choiceTF \n {{ {choices[0]} }}\n {{ {choices[1]} }}\n {{ {choices[2]} }}\n {{ {choices[3]} }}"

def to_latex(frac):
    if frac.denominator == 1: return str(frac.numerator)
    return rf"\dfrac{{{frac.numerator}}}{{{frac.denominator}}}"

def generate():
    # --- 1. THAM SỐ CHO A (Căn lồng căn bậc cao) ---
    # A = sqrt[m]{ x^n * sqrt[p]{x^q} }
    m, p = 2, 2
    n, q = 3, 5
    f_A = Fraction(n * p + q, m * p) # Mũ của A là 11/4
    
    # --- 2. THAM SỐ CHO B (Phân thức bậc cao) ---
    # B = (x^{2k} + x^k + 1) / (x^k + sqrt(x^k) + 1) -> Dạng hằng đẳng thức mở rộng
    # Ta chọn đơn giản hơn: B = (x^{2k} - 1) / (x^k + 1) = x^k - 1
    k = random.randint(2, 4)
    f_B_exp = Fraction(k, 1)

    # --- 3. CHUẨN BỊ CHUỖI LATEX TRƯỚC (Tránh lỗi Syntax lồng) ---
    exp_A = to_latex(f_A)
    exp_B = to_latex(f_B_exp)
    neg_exp_B = to_latex(-f_B_exp)

    # --- 4. DANH SÁCH 6 CẶP ĐỐI ỨNG #DEPPY ---
    dung_list = [
        rf"$A = x^{{{exp_A}}}$",
        rf"$B = x^{{{exp_B}}} - 1$",
        rf"$A \cdot (B+1) = x^{{{to_latex(f_A + f_B_main if 'f_B_main' in locals() else f_A + f_B_exp)}}}$",
        rf"$\text{{Với }} x = 1, \text{{ biểu thức }} A + B \text{{ có giá trị bằng }} 1$",
        rf"$\dfrac{{B+1}}{{x}} = x^{{{k-1}}}$",
        rf"$B = (x^{{{to_latex(f_B_exp/2)}}} - 1)(x^{{{to_latex(f_B_exp/2)}}} + 1)$"
    ]
    
    sai_list = [
        rf"$A = x^{{{to_latex(f_A + 1)}}}$",
        rf"$B = x^{{{k}}} + 1$",
        rf"$A = B + 1$",
        rf"$\text{{Với}} x = 1, \text{{ giá trị }} A \cdot B = 1$",
        rf"$B+1 = x^{{{2*k}}}$",
        rf"$B = x^{{{k-1}}}$"
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 5. RÁP LATEX ---
    A_tex = rf"\sqrt[{{{m}}}]{{x^{{{n}}} \cdot \sqrt[{{{p}}}]{{x^{{{q}}}}}}}"
    B_tex = rf"\dfrac{{x^{{{2*k}}} - 1}}{{x^{{{k}}} + 1}}"

    # Tách phần lời giải ra để tránh lỗi f-string lồng quá sâu
    loi_giai_A = rf"A = \left( x^{{{n}}} \cdot x^{{{q}/{p}}} \right)^{{1/{m}}} = x^{{{exp_A}}}"
    loi_giai_B = rf"B = \dfrac{{(x^{{{k}}}-1)(x^{{{k}}}+1)}}{{x^{{{k}}}+1}} = x^{{{k}}}-1"

    return rf"""\begin{{ex}}
    Cho các biểu thức $A = {A_tex}$ và $B = {B_tex}$ với $x > 0$.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        \textbf{{Rút gọn biểu thức:}}
        \begin{{itemize}}
            \item ${loi_giai_A}$.
            \item ${loi_giai_B}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

#print(generate())
