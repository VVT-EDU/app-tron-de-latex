import random
from sympy import symbols, Eq, expand, simplify, solve, latex, Rational, sqrt
from decimal import Decimal, ROUND_HALF_UP

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THÔNG SỐ
    x, t, k = symbols('x t k')
    h_value = random.randint(1, 4)
    
    a = Rational(h_value + 1)
    # mu1 = 1/2 + a/2, mu2 = 1/2
    mu1 = Rational(1, 2) + a/2
    mu2 = Rational(1, 2)
    
    # Hai ẩn phụ cho hai cơ số khác nhau
    bphu1 = 2**x
    bphu2 = 3**x
    
    # 2. XÂY DỰNG PHƯƠNG TRÌNH DẠNG TÍCH (t - A)(k - B) = 0
    val_t = 2**mu1
    val_k = 3**mu2
    
    t_factor = t - val_t
    k_factor = k - val_k
    
    # Khai triển để tạo phương trình phức tạp: tk - B.t - A.k + AB = 0
    btt = expand(t_factor * k_factor)
    ptt = Eq(btt, 0)
    ptt_factored = Eq(t_factor * k_factor, 0)
    
    # 3. GIẢI VÀ TÌM NGHIỆM X
    # Thế ngược t = 2^x và k = 3^x vào phương trình
    pt_x = btt.subs({t: bphu1, k: bphu2})
    
    # Giải phương trình tích: 2^x = val_t hoặc 3^x = val_k
    sol1 = solve(Eq(bphu1, val_t), x)
    sol2 = solve(Eq(bphu2, val_k), x)
    
    nghiem_x = sol1 + sol2
    nghiem_x = [simplify(sol) for sol in nghiem_x if sol.is_real]
    tap_nghiem = set(nghiem_x)
    tong_nghiem = sum(tap_nghiem)
    
    # Giá trị làm tròn
    val_tong = float(tong_nghiem.evalf())
    res_final = int(round_half_up(val_tong, 0))
    
    # 4. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Phương trình đã cho: ${latex(pt_x)} = 0$",
        f"Đặt $t = 2^x > 0$ và $k = 3^x > 0$.",
        f"Phương trình trở thành: ${latex(ptt)}$",
        f"$\\Leftrightarrow {latex(ptt_factored)}$",
        f"$\\Leftrightarrow \\begin{{cases}} t = {latex(val_t)} \\\\ k = {latex(val_k)} \\end{{cases}}$",
        f"Với $t = {latex(val_t)} \\Rightarrow 2^x = {latex(val_t)} \\Rightarrow x = {latex(sol1[0])}$",
        f"Với $k = {latex(val_k)} \\Rightarrow 3^x = {latex(val_k)} \\Rightarrow x = {latex(sol2[0])}$",
        f"Tập nghiệm của phương trình là $S = \\{{ {', '.join([latex(n) for n in tap_nghiem])} \\}}$",
        f"Vậy tổng các nghiệm là ${latex(tong_nghiem)}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
Cho phương trình ${latex(pt_x)} = 0$. Tính tổng các nghiệm của phương trình.
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
