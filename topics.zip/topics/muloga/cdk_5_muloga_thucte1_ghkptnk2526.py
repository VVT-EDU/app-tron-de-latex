import random
import math
from sympy import symbols, Eq, solve, latex, log, simplify
from decimal import Decimal, ROUND_HALF_UP

def generate():
    # 1. THIẾT LẬP THAM SỐ BÀI TOÁN
    n = symbols('n') # Số năm cần tìm
    P = random.choice([200, 300, 400, 500])  # Vốn ban đầu (triệu đồng)
    r = random.choice([0.05, 0.055, 0.06, 0.065, 0.07, 0.075]) # Lãi suất
    A = random.choice([600, 700, 800, 900]) # Mục tiêu (triệu đồng)
    
    # Đảm bảo mục tiêu phải lớn hơn số tiền ban đầu
    while A <= P:
        A += 200

    phantram_r = round(r * 100, 1)
    
    # 2. XÂY DỰNG CÔNG THỨC
    # Tổng tiền T = P * (1 + r)^n
    T_bieu_thuc = P * (1 + r)**n
    
    # 3. GIẢI BẤT PHƯƠNG TRÌNH: T >= A
    # n >= log(A/P) / log(1 + r)
    n_chinh_xac = math.log(A / P) / math.log(1 + r)
    so_nam_toi_thieu = math.ceil(n_chinh_xac)
    
    # 4. TRÌNH BÀY LỜI GIẢI
    bai_tap = (
        f"Gia đình bạn An gửi tiết kiệm ${P}$ triệu đồng vào ngân hàng với lãi suất ${phantram_r}\\%$ một năm "
        f"theo thể thức lãi kép hằng năm. Biết rằng lãi suất không thay đổi theo thời gian. "
        f"Hỏi sau ít nhất bao nhiêu năm, gia đình bạn An thu được tổng số tiền (cả gốc lẫn lãi) "
        f"không dưới ${A}$ triệu đồng?"
    )

    y_list = [
        f"Gọi $n$ là số năm gia đình bạn An gửi tiết kiệm ($n \\in \\mathbb{{N}}^*$).",
        f"Công thức lãi kép: $T = P(1 + r)^n$, trong đó $P = {P}$, $r = {r}$.",
        f"Theo đề bài, ta cần tìm $n$ nhỏ nhất sao cho: ${P} \\cdot (1 + {r})^n \\geq {A}$",
        f"$\\Leftrightarrow (1,0{int(phantram_r*10) if phantram_r % 1 == 0 else phantram_r})^n \\geq \\frac{{{A}}}{{{P}}}$", # Trình bày số thập phân đẹp
        f"$\\Leftrightarrow n \\geq \\log_{{1 + {r}}} \\left( \\frac{{{A}}}{{{P}}} \\right)$",
        f"$\\Leftrightarrow n \\geq {n_chinh_xac:.2f}$",
        f"Vì $n$ là số nguyên nên $n \\geq {so_nam_toi_thieu}$.",
        f"Vậy thời gian tối thiểu là ${so_nam_toi_thieu}$ năm."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ
    content = rf"""\begin{{ex}}
{bai_tap}
\shortans{{ ${so_nam_toi_thieu}$ năm }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
