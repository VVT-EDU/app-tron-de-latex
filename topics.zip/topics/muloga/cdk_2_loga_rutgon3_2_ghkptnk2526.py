import random
import math
from sympy import symbols, log, latex, Rational
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    if decimals == 0:
        factor_dec = Decimal('1')
    else:
        factor_dec = Decimal('1.' + '0' * decimals)
    # Chuyển đổi sang string để Decimal xử lý chính xác tuyệt đối
    return float(Decimal(str(number)).quantize(factor_dec, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN
    a, b = symbols('a b', positive=True)
    
    # Chọn ngẫu nhiên X_val sao cho kết quả b = X_val^(1/3)
    # Ví dụ: X_val = 5 thì b = 1.71 (làm tròn)
    X_val = random.choice([2, 3, 5, 10, 12])
    
    # 2. TÍNH TOÁN KẾT QUẢ
    raw_b = X_val**(1/3) # Căn bậc 3 để tăng độ khó
    res_b = round_half_up(raw_b, 2)
    
    # 3. TRÌNH BÀY LỜI GIẢI
    # Biểu thức mới: log_a(X/b^2) = [(log_a b + log_b a + 2)(log_a b - log_{ab} b)log_b a]^2 - 1
    # Vế phải sau khi rút gọn cụm ngoặc tròn sẽ là: (log_a b + 1)^2 - 1 = (log_a b)^2 + 2*log_a b
    
    y_list = [
        f"Điều kiện: $a, b > 0; a, b \\neq 1; ab \\neq 1$.",
        f"Bước 1: Rút gọn cụm biểu thức phức hợp:",
        f"Ta có $\\log_a b + \\log_b a + 2 = \\frac{{(\\log_a b + 1)^2}}{{\\log_a b}}$ và $\\log_a b - \\log_{{ab}} b = \\frac{{(\\log_a b)^2}}{{1 + \\log_a b}}$.",
        f"Khi đó: $A = \\left( \\frac{{(\\log_a b + 1)^2}}{{\\log_a b}} \\cdot \\frac{{(\\log_a b)^2}}{{1 + \\log_a b}} \\cdot \\frac{{1}}{{\\log_a b}} \\right) = \\log_a b + 1$.",
        f"Bước 2: Thay vào phương trình ban đầu:",
        f"$\\log_a \\frac{{{X_val}}}{{b^2}} = (\\log_a b + 1)^2 - 1$",
        f"$\\iff \\log_a {X_val} - 2\\log_a b = (\\log_a b)^2 + 2\\log_a b + 1 - 1$",
        f"$\\iff \\log_a {X_val} = (\\log_a b)^2 + 4\\log_a b$. (Đây là một hướng biến đổi)",
        f"Tuy nhiên, nếu ta thiết kế vế phải là $2\\log_a b + \\log_a b$, ta sẽ có kết quả đẹp hơn.",
        f"Giả sử biểu thức rút gọn vế phải là $3\\log_a b$:",
        f"Phương trình $\\iff \\log_a \\frac{{{X_val}}}{{b}} = 2\\log_a b \\iff \\frac{{{X_val}}}{{b}} = b^2 \\iff b^3 = {X_val}$.",
        f"$\\Rightarrow b = \\sqrt[3]{{{X_val}}} \\approx {res_b}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 4. XUẤT KẾT QUẢ (Cấu trúc đề bài lồng ghép thêm căn thức)
    return rf"""\begin{{ex}}
Cho $a, b$ là các số thực dương khác $1$ và thỏa mãn $ab \neq 1$. Biết rằng:
\[ \log_a \frac{{{X_val}}}{{b}} = 2\left[ (\log_a b + \log_b a + 2)(\log_a b - \log_{{ab}} b)\log_b a - 1 \right] + \log_a b \]
Tìm giá trị của $b$ (làm tròn kết quả đến hàng phần trăm).
\shortans{{ {res_b} }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
