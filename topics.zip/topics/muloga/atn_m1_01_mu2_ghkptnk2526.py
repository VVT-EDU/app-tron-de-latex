import random
from fractions import Fraction

def to_latex(frac):
    """Hiển thị phân số LaTeX tối giản, xử lý dấu âm đẹp."""
    if frac.denominator == 1:
        return str(frac.numerator)
    num = abs(frac.numerator)
    den = frac.denominator
    sign = "-" if frac.numerator < 0 else ""
    return rf"{sign}\dfrac{{{num}}}{{{den}}}"

def generate():
    ten_bt = random.choice(['P', 'Q', 'A', 'B', 'M', 'N'])
    
    # Lặp cho đến khi tạo được bộ thông số mà đáp án không bị quá "xấu" hoặc trùng lặp
    while True:
        m, p = random.randint(2, 4), random.randint(2, 4)
        n, q = random.randint(2, 5), random.randint(2, 5)
        
        exp_a = Fraction(n, m) - Fraction(1, p)
        exp_b = Fraction(1, m) - Fraction(q, p)
        val_S = exp_a + exp_b
        
        # --- QUẢN LÝ ĐÁP ÁN BẰNG SET ĐỂ KHÔNG TRÙNG ---
        # Lưu trữ dưới dạng Fraction để so sánh chính xác tuyệt đối
        ans_set = {val_S}
        
        # Tạo các phương án nhiễu logic
        potential_distractors = [
            exp_a - exp_b,                     # Sai dấu giữa a và b
            Fraction(n + 1, m) - Fraction(q, p), # Sai số mũ
            val_S + Fraction(1, 2),            # Lệch đơn vị
            val_S - Fraction(1, 2),
            Fraction(n + q, m + p),            # Lỗi cộng tử cộng mẫu (phổ biến ở HS)
            val_S * 2,                         # Nhân đôi
            val_S + 1
        ]
        
        for d in potential_distractors:
            if len(ans_set) < 4:
                ans_set.add(d)
        
        # Nếu vẫn chưa đủ 4 đáp án (do trùng lặp ngẫu nhiên), thêm số ngẫu nhiên
        while len(ans_set) < 4:
            ans_set.add(val_S + random.randint(-3, 3) + Fraction(1, 4))
            
        # Nếu đã đủ 4 đáp án phân biệt, thoát vòng lặp tạo số
        if len(ans_set) == 4:
            break

    # Chuyển đổi set thành list và định dạng LaTeX
    final_options = []
    for val in ans_set:
        prefix = r"\True " if val == val_S else ""
        final_options.append(rf"{prefix}{to_latex(val)}")
        
    random.shuffle(final_options)

    # Chuẩn bị hiển thị lời giải
    lt_a = to_latex(exp_a)
    lt_b = to_latex(exp_b)
    lt_S = to_latex(val_S)
    sign_b = "+" if exp_b >= 0 else ""

    return rf"""\begin{{ex}}
    Biểu thức ${ten_bt} = \dfrac{{\sqrt[{{{m}}}]{{x^{{{n}}}y}}}}{{\sqrt[{{{p}}}]{{xy^{{{q}}}}}}}$ với $x, y > 0$, được viết dưới dạng $x^{{a}}y^{{b}}$. Tính tổng $T = a + b$.
    \choice
    {{${final_options[0]}$}}
    {{${final_options[1]}$}}
    {{${final_options[2]}$}}
    {{${final_options[3]}$}}
    \loigiai{{
        Ta có: ${ten_bt} = \dfrac{{x^{{\frac{{{n}}}{{{m}}}}} \cdot y^{{\frac{{1}}{{{m}}}}}}}{{x^{{\frac{{1}}{{{p}}}}} \cdot y^{{\frac{{{q}}}{{{p}}}}}}} = x^{{\frac{{{n}}}{{{m}}} - \frac{{1}}{{{p}}}}} \cdot y^{{\frac{{1}}{{{m}}} - \frac{{{q}}}{{{p}}}}}$.
        Suy ra:
        $a = {lt_a}$, $b = {lt_b}$.
        Vậy $T = a + b = {lt_a} {sign_b} {lt_b} = {lt_S}$.
        Đáp án đúng là \textbf{{${lt_S}$}}.
    }}
\end{{ex}}"""

#print(generate())
