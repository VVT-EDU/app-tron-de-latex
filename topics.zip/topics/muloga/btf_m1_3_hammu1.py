import random
import math

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """
    Trộn 2 đúng, 2 sai theo định dạng \choiceTF.
    """
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
        
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Khảo sát hàm số mũ - Qt6 Scanner Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ
    a = random.choice([2, 3, 5])  # Cơ số a > 1
    mu_max = random.randint(4, 6)
    val_max = a**mu_max
    
    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # --- CÂU ĐÚNG ---
    d1 = f"$\\text{{Hàm số }} f(x)={a}^x \\text{{ có tập xác định là }} \\mathbb{{R}}$"
    d2 = f"$\\text{{Hàm số }} f(x)={a}^x \\text{{ đồng biến trên khoảng }} (-\\infty;+\\infty) \\text{{ vì có cơ số }} {a}>1$"
    d3 = f"$\\text{{Đồ thị hàm số }} f(x) \\text{{ luôn đi qua điểm }} M(0;1)$"
    d4 = f"$\\text{{Có đúng }} {mu_max} \\text{{ số nguyên dương }} x \\text{{ để }} f(x) \\le {val_max}$"

    # --- CÂU SAI ---
    s1 = f"$\\text{{Đồ thị hàm số }} f(x) \\text{{ luôn đi qua điểm }} A(1;0)$"
    s2 = f"$\\text{{Hàm số }} f(x)={a}^x \\text{{ nghịch biến trên khoảng }} (-\\infty;+\\infty)$"
    s3 = f"$\\text{{Tập giá trị của hàm số là }} [0;+\\infty)$" # Sai vì phải là (0; +inf)
    s4 = f"$\\text{{Có đúng }} {mu_max + 1} \\text{{ số nguyên dương }} x \\text{{ để }} f(x) \\le {val_max}$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = f"\\textbf{{Đúng}}. Hàm số mũ $y=a^x$ luôn xác định với mọi $x \\in \\mathbb{{R}}$."
        elif content == d2:
            note = f"\\textbf{{Đúng}}. Vì cơ số $a={a} > 1$ nên hàm số đồng biến trên $\\mathbb{{R}}$."
        elif content == d3:
            note = f"\\textbf{{Đúng}}. Với $x=0$ thì $f(0)={a}^0=1$, nên đồ thị qua điểm $(0;1)$."
        elif content == d4:
            note = f"\\textbf{{Đúng}}. $f(x) \\le {val_max} \\Leftrightarrow {a}^x \\le {a}^{{{mu_max}}} \\Leftrightarrow x \\le {mu_max}$. Các số nguyên dương là $\\{{1; 2; \\dots; {mu_max}\\}}$."
        elif content == s1:
            note = f"\\textbf{{Sai}}. Với $x=1$ thì $f(1)={a} \\neq 0$."
        elif content == s2:
            note = f"\\textbf{{Sai}}. Hàm số mũ với cơ số $a={a} > 1$ luôn đồng biến."
        elif content == s3:
            note = f"\\textbf{{Sai}}. Tập giá trị của hàm số mũ là $(0;+\\infty)$, không lấy giá trị bằng $0$."
        elif content == s4:
            note = f"\\textbf{{Sai}}. Chỉ có đúng {mu_max} số nguyên dương thỏa mãn $x \\le {mu_max}$."
        else:
            note = ""
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Xét hàm số $f(x)={a}^x$ trên tập số thực $\\mathbb{{R}}$. \\textbf{{Xác định tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde
