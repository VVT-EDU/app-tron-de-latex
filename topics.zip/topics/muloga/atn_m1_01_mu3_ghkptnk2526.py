import random
from fractions import Fraction

def to_latex(frac):
    """Định dạng LaTeX sạch cho phân số và số nguyên."""
    if frac.denominator == 1: return str(frac.numerator)
    num = abs(frac.numerator)
    den = frac.denominator
    sign = "-" if frac.numerator < 0 else ""
    return rf"{sign}\dfrac{{{num}}}{{{den}}}"

def generate():
    # 1. Khởi tạo tham số toán học
    # Chọn k sao cho biểu thức có dạng (x^k - y^k)(x^k + y^k) + sqrt(y^{4k})
    k = random.choice([Fraction(1, 2), Fraction(1, 4), Fraction(3, 4), Fraction(2, 3)])
    two_k = k * 2
    four_k = k * 4
    
    # Kết quả rút gọn cuối cùng là x^{2k}, nên a = 2k, b = 0
    val_S = two_k 
    
    # 2. Quản lý đáp án (Đảm bảo không trùng)
    ans_set = {val_S}
    potential_distractors = [
        k,                       # Quên nhân 2 ở hằng đẳng thức
        four_k,                  # Nhầm lũy thừa
        Fraction(1, 1),          # Giá trị ảo
        0,                       # Nhầm triệt tiêu hết
        val_S + Fraction(1, 2)   # Sai lệch đơn vị
    ]
    
    for d in potential_distractors:
        if len(ans_set) < 4:
            ans_set.add(d)
            
    ans_list = list(ans_set)
    random.shuffle(ans_list)
    
    # Tạo danh sách đáp án LaTeX
    options_latex = []
    for opt in ans_list:
        prefix = r"\True " if opt == val_S else ""
        options_latex.append(rf"{prefix}{to_latex(opt)}")

    # 3. Tạo chuỗi biểu thức LaTeX
    # Dạng: (x^k - y^k)(x^k + y^k) + \sqrt{y^{4k}}
    P_tex = rf"\left( x^{{{to_latex(k)}}} - y^{{{to_latex(k)}}} \right) \left( x^{{{to_latex(k)}}} + y^{{{to_latex(k)}}} \right) + \sqrt{{y^{{{to_latex(four_k)}}}}}"

    return rf"""\begin{{ex}}
    Rút gọn biểu thức ${P_tex}$ với $x, y > 0$, ta được kết quả dưới dạng $x^{{a}}y^{{b}}$. 
    Tính giá trị của tổng $T = a + b$.
    \choice
    {{${options_latex[0]}$}}
    {{${options_latex[1]}$}}
    {{${options_latex[2]}$}}
    {{${options_latex[3]}$}}
    \loigiai{{
        Thực hiện các bước biến đổi rút gọn:
        \begin{{itemize}}
            \item Sử dụng hằng đẳng thức $(u-v)(u+v) = u^2 - v^2$, ta có:
            \[ \left( x^{{{to_latex(k)}}} - y^{{{to_latex(k)}}} \right) \left( x^{{{to_latex(k)}}} + y^{{{to_latex(k)}}} \right) = \left( x^{{{to_latex(k)}}} \right)^2 - \left( y^{{{to_latex(k)}}} \right)^2 = x^{{{to_latex(two_k)}}} - y^{{{to_latex(two_k)}}}. \]
            \item Biến đổi phần căn thức: $\sqrt{{y^{{{to_latex(four_k)}}}}} = \left( y^{{{to_latex(four_k)}}} \right)^{{\frac{{1}}{{2}}}} = y^{{{to_latex(two_k)}}}$.
            \item Kết hợp lại: $(x^{{{to_latex(two_k)}}} - y^{{{to_latex(two_k)}}}) + y^{{{to_latex(two_k)}}} = x^{{{to_latex(two_k)}}}$.
        \end{{itemize}}
        Dựa vào kết quả $x^{{{to_latex(two_k)}}}$, ta có $a = {to_latex(two_k)}$ và $b = 0$.
        Vậy $T = a + b = {to_latex(val_S)}$.
        Đáp án đúng là \textbf{{${to_latex(val_S)}$}}.
    }}
\end{{ex}}"""

print(generate())
