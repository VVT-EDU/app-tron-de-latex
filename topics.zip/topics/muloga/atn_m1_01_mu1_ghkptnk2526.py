import random
from fractions import Fraction

def to_latex(frac):
    """Hiển thị số nguyên hoặc phân số LaTeX tối giản."""
    if frac.denominator == 1:
        return str(frac.numerator)
    return rf"\dfrac{{{frac.numerator}}}{{{frac.denominator}}}"

def generate():
    # --- 1. THIẾT KẾ BIỂU THỨC P ---
    n = random.randint(2, 4)
    m = random.randint(2, 5)
    p = random.randint(2, 4)
    q = random.randint(2, 7)
    
    exp_final = Fraction(n) + Fraction(p, m) - Fraction(q)
    
    # --- 2. TẠO CÁC PHƯƠNG ÁN ---
    # Bọc các giá trị x^... vào trong dấu $...$
    correct_val = rf"${{x^{{{to_latex(exp_final)}}}}}$"
    
    distractors = set()
    # Nhiễu 1: Nhầm quy tắc chia thành nhân
    distractors.add(rf"${{x^{{{to_latex(Fraction(n) + Fraction(p, m) + Fraction(q))}}}}}$")
    # Nhiễu 2: Nhầm căn thức
    distractors.add(rf"${{x^{{{to_latex(Fraction(n) + Fraction(p * m, 1) - Fraction(q))}}}}}$")
    # Nhiễu 3: Sai quy tắc nhân lũy thừa
    distractors.add(rf"${{x^{{{to_latex(Fraction(n) * Fraction(p, m) - Fraction(q))}}}}}$")
    
    options = list(distractors)
    while len(options) < 3:
        options.append(rf"${{x^{{{random.randint(5, 10)}}}}}$")
        
    # Chèn đáp án đúng có kèm \True (Dấu $ nằm sau \True)
    ans_list = options + [rf"\True {correct_val}"]
    random.shuffle(ans_list)

    # --- 3. RÁP LATEX ---
    P_tex = rf" \dfrac{{x^{{{n}}} \cdot \sqrt[{{{m}}}]{{x^{{{p}}}}}}}{{x^{{{q}}}}}"

    # Đảm bảo phần kết quả trong lời giải cũng nằm trong $...$
    return rf"""\begin{{ex}}
    Rút gọn biểu thức ${P_tex}$ với $x > 0$, ta được kết quả là
    \choice
    {{{ans_list[0]}}}
    {{{ans_list[1]}}}
    {{{ans_list[2]}}}
    {{{ans_list[3]}}}
    \loigiai{{
        Ta có: $P = x^{{{n}}} \cdot x^{{{to_latex(Fraction(p, m))}}} \cdot x^{{-{q}}} = x^{{{n} + {to_latex(Fraction(p, m))} - {q}}} = x^{{{to_latex(exp_final)}}}$.
        Vậy kết quả rút gọn là ${correct_val.replace('$', '')}$.
    }}
\end{{ex}}"""

#print(generate())
