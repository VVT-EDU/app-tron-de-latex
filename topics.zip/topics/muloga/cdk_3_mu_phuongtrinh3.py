import random
from sympy import symbols, Eq, expand, simplify, solveset, latex, sqrt
from decimal import Decimal, ROUND_HALF_UP

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THÔNG SỐ
    x = symbols('x')
    a_val = random.choice([2, 3, 4, 5, 6, 7, 8])
    
    a1 = a_val
    b1 = a_val + 1
    
    # Số mũ chung mu1 = x * (x - sqrt(a))
    # Lưu ý: Để đề bài đẹp, ta có thể dùng sqrt(a_val) trực tiếp
    can_a = sqrt(a_val)
    mu1 = x * (x - can_a)
    mu1_expanded = expand(mu1)
    
    # 2. XÂY DỰNG PHƯƠNG TRÌNH
    # pt1: a^f(x) = (a+1)^f(x)
    pt1 = Eq(a1**mu1_expanded, b1**mu1_expanded)
    
    # 3. GIẢI CHI TIẾT
    # Bước 1: Chia hai vế cho b1^mu1 => (a1/b1)^mu1 = 1
    pt2 = Eq((simplify(a1/b1))**mu1_expanded, 1)
    
    # Bước 2: Vì a1/b1 != 1 nên số mũ phải bằng 0
    pt3 = Eq(mu1_expanded, 0)
    pt4 = simplify(pt3)
    
    # Tìm tập nghiệm
    nghiem = solveset(pt4, x)
    danh_sach_nghiem = list(nghiem)
    tong_nghiem = sum(danh_sach_nghiem)
    
    # Tính giá trị số để làm tròn (nếu cần)
    val_tong = float(tong_nghiem.evalf())
    res_final = round_half_up(val_tong, 2) # Làm tròn 2 chữ số thập phân
    
    # 4. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Phương trình: ${latex(pt1)}$",
        f"Chia hai vế cho ${b1}^{{{latex(mu1_expanded)}}}$, ta được: $\\left(\\frac{{{a1}}}{{{b1}}}\\right)^{{{latex(mu1_expanded)}}} = 1$",
        f"Vì $\\frac{{{a1}}}{{{b1}}} \\neq 1$, nên phương trình tương đương: ${latex(mu1_expanded)} = 0$",
        f"$\\Leftrightarrow {latex(pt4)}$",
        f"Tập nghiệm của phương trình là $S = \\{{ {', '.join([latex(n) for n in danh_sach_nghiem])} \\}}$",
        f"Vậy tổng các nghiệm là ${latex(tong_nghiem)} \\approx {res_final}$"
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
Cho phương trình ${latex(pt1)}$. Tính tổng các nghiệm của phương trình đã cho.
\shortans{{ ${latex(res_final)}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

# Thực thi
if __name__ == "__main__":
    print(generate())
