import random
import sympy as sp
from sympy import symbols, latex, Rational, log

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """
    Trộn 2 đúng, 2 sai theo định dạng \choiceTF.
    Nhãn \True nằm ngoài dấu $ để tương thích với các gói định dạng LaTeX.
    """
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
        
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Biểu diễn Lôgarit - Qt6 Scanner Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ
    # Biểu diễn log_3 70 theo m = log 3, n = log 7
    m_val = symbols('m')
    n_val = symbols('n')
    
    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # --- CÂU ĐÚNG ---
    d1 = r"$\log_a \sqrt{a\sqrt{a}} = \dfrac{3}{4} \text{ với } a > 1$"
    d2 = r"$\log_a b^2 \cdot \log_{\sqrt{b}} c \cdot \log_{c^2} a^3 = 6 \text{ với } a, b, c > 1$"
    d3 = r"$\text{Cho } \log 3=m, \log 7=n. \text{ Khi đó } \log_3 70 = \dfrac{n+1}{m}$"
    d4 = r"$\text{Cho } \log_5 2=m, \log_5 3=n. \text{ Khi đó } \log_{250} 30 = \dfrac{m+n+1}{3+m}$"

    # --- CÂU SAI ---
    s1 = r"$\log_a \sqrt{a\sqrt{a}} = \dfrac{1}{4} \text{ với } a > 1$"
    s2 = r"$\log_a b^2 \cdot \log_{\sqrt{b}} c \cdot \log_{c^2} a^3 = \dfrac{1}{6} \text{ với } a, b, c > 1$"
    s3 = r"$\text{Cho } \log 3=m, \log 7=n. \text{ Khi đó } \log_3 70 = \dfrac{m+1}{n}$"
    s4 = r"$\text{Cho } \log_5 2=m, \log_5 3=n. \text{ Khi đó } \log_{250} 30 = (m+n+1)(3+m)$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = r"\textbf{Đúng}. $\log_a \sqrt{a\sqrt{a}} = \log_a \sqrt{a^{3/2}} = \log_a a^{3/4} = \dfrac{3}{4}$."
        elif content == d2:
            note = r"\textbf{Đúng}. $2\log_a b \cdot 2\log_b c \cdot \dfrac{3}{2}\log_c a = 2 \cdot 2 \cdot \dfrac{3}{2} \cdot (\log_a b \cdot \log_b c \cdot \log_c a) = 6$."
        elif content == d3:
            note = r"\textbf{Đúng}. $\log_3 70 = \dfrac{\log 70}{\log 3} = \dfrac{\log 7 + \log 10}{\log 3} = \dfrac{n+1}{m}$."
        elif content == d4:
            note = r"\textbf{Đúng}. $\log_{250} 30 = \dfrac{\log_5 30}{\log_5 250} = \dfrac{\log_5(2\cdot 3\cdot 5)}{\log_5(2\cdot 5^3)} = \dfrac{m+n+1}{m+3}$."
        elif content == s1:
            note = r"\textbf{Sai}. Tính toán đúng cho kết quả $\dfrac{3}{4}$."
        elif content == s2:
            note = r"\textbf{Sai}. Tích các hệ số là $2 \cdot 2 \cdot \frac{3}{2} = 6$, không phải $\frac{1}{6}$."
        elif content == s3:
            note = r"\textbf{Sai}. Phải là $\dfrac{\log 70}{\log 3} = \dfrac{n+1}{m}$."
        elif content == s4:
            note = r"\textbf{Sai}. Theo công thức đổi cơ số phải là một thương: $\dfrac{m+n+1}{3+m}$."
        else:
            note = ""
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Cho $a, b, c > 1$ và $m, n$ là các số thực được định nghĩa theo lôgarit tương ứng. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde.replace("\\frac", "\\dfrac")
