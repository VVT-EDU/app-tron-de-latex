import random
import sympy as sp
from sympy import symbols, latex, Rational, sqrt

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    r"""
    Trộn 2 đúng, 2 sai. 
    Nhãn \True nằm ngoài dấu $ để tương thích với các gói định dạng LaTeX.
    """
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
        
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Biến đổi Logarit nâng cao - Qt6 Scanner Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ
    # log_a(b) = m, log_a(c) = n
    m = random.randint(2, 6)
    n = random.randint(m + 1, 10)
    
    # Tính toán các giá trị biểu thức
    val_tich = m + n
    val_thuong_bc = Rational(n, m)
    val_b_c2 = m - 2*n
    
    # Tính log_{a^3} (sqrt(b) / c^2) = 1/3 * (1/2*m - 2*n)
    val_phuc_tap = Rational(1, 3) * (Rational(1, 2)*m - 2*n)

    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    d1 = f"$\\log_{{a}} bc = {val_tich}$"
    d2 = f"$\\log_{{b}} c = {latex(val_thuong_bc)}$"
    d3 = f"$\\log_{{a}} \\dfrac{{b}}{{c^2}} = {val_b_c2}$"
    d4 = f"$\\log_{{a^3}} \\dfrac{{\\sqrt{{b}}}}{{c^2}} = {latex(val_phuc_tap)}$"

    s1 = f"$\\log_{{a}} bc = {m - n}$"
    s2 = f"$\\log_{{b}} c = {latex(Rational(m, n))}$"
    s3 = f"$\\log_{{a}} \\dfrac{{b}}{{c^2}} = {m + 2*n}$"
    s4 = f"$\\log_{{a^3}} \\dfrac{{\\sqrt{{b}}}}{{c^2}} = {latex(val_phuc_tap + 1)}$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = f"\\textbf{{Đúng.}} $\\log_{{a}} bc = \\log_{{a}} b + \\log_{{a}} c = {m} + {n} = {val_tich}$."
        elif content == d2:
            note = f"\\textbf{{Đúng.}} $\\log_{{b}} c = \\dfrac{{\\log_{{a}} c}}{{\\log_{{a}} b}} = \\dfrac{{{n}}}{{{m}}} = {latex(val_thuong_bc)}$."
        elif content == d3:
            note = f"\\textbf{{Đúng.}} $\\log_{{a}} \\dfrac{{b}}{{c^2}} = \\log_{{a}} b - 2\\log_{{a}} c = {m} - 2 \\cdot {n} = {val_b_c2}$."
        elif content == d4:
            note = f"\\textbf{{Đúng.}} $\\log_{{a^3}} \\dfrac{{\\sqrt{{b}}}}{{c^2}} = \\dfrac{{1}}{{3}} \\left( \\dfrac{{1}}{{2}}\\log_{{a}} b - 2\\log_{{a}} c \\right) = \\dfrac{{1}}{{3}} \\left( \\dfrac{{1}}{{2}} \\cdot {m} - 2 \\cdot {n} \\right) = {latex(val_phuc_tap)}$."
        elif content == s1:
            note = f"\\textbf{{Sai.}} Vì quy tắc nhân là cộng các lôgarit: $\\log_{{a}} bc = {m} + {n} = {val_tich}$."
        elif content == s2:
            note = f"\\textbf{{Sai.}} Công thức đổi cơ số đúng phải là $\\dfrac{{\\log_{{a}} c}}{{\\log_{{a}} b}}$."
        elif content == s3:
            note = f"\\textbf{{Sai.}} Vì $\\log_{{a}} \\dfrac{{b}}{{c^2}} = \\log_{{a}} b - 2\\log_{{a}} c$."
        elif content == s4:
            note = f"\\textbf{{Sai.}} Tính toán theo các bước biến đổi lũy thừa cho kết quả là ${latex(val_phuc_tap)}$."
        else:
            note = ""
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Cho $\\log_{{a}}b={m}$, $\\log_{{a}}c={n}$ với $b, c > 0$ và $0 < a \\neq 1$. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde.replace("\\frac", "\\dfrac")
