import random

def generate():
    # 1. Thiết kế kịch bản: a^2 + b^2 = k*ab
    # Ta chọn k sao cho k + 2 là một số chính phương (để tạo (a+b)^2)
    # Các cặp (k, k+2): (7, 9) -> (a+b)^2=9ab, (23, 25) -> (a+b)^2=25ab
    k = random.choice([7, 23, 47])
    sqrt_k_plus_2 = int((k + 2)**0.5)
    
    # 2. Tạo khẳng định đúng: log(a+b)/sqrt_k_plus_2 = (log a + log b)/2
    # <=> 2 log((a+b)/sqrt_k_plus_2) = log(ab)
    # <=> log((a+b)/sqrt_k_plus_2)^2 = log(ab)
    
    ten_log = random.choice([r'\log', r'\ln', r'\log_2'])
    
    correct_ans = rf"{ten_log} \left( \dfrac{{a + b}}{{{sqrt_k_plus_2}}} \right) = \dfrac{{1}}{{2}} ({ten_log} a + {ten_log} b)"
    
    distractors = [
        rf"{ten_log} (a + b) = \dfrac{{1}}{{{sqrt_k_plus_2}}} ({ten_log} a + {ten_log} b)",
        rf"{ten_log} \left( \dfrac{{a + b}}{{{sqrt_k_plus_2}}} \right) = {ten_log} a + {ten_log} b",
        rf"2 {ten_log} (a + b) = {sqrt_k_plus_2} ({ten_log} a + {ten_log} b)"
    ]
    
    options = [rf"\True ${correct_ans}$"] + [rf"${d}$" for d in distractors]
    random.shuffle(options)

    return rf"""\begin{{ex}}
    Cho hai số thực dương $a, b$ thỏa mãn $a^2 + b^2 = {k}ab$. Khẳng định nào sau đây là đúng?
    \choice
    {{{options[0]}}}
    {{{options[1]}}}
    {{{options[2]}}}
    {{{options[3]}}}
    \loigiai{{
        Từ giả thiết $a^2 + b^2 = {k}ab$, ta biến đổi để tạo hằng đẳng thức:
        \begin{{itemize}}
            \item $a^2 + 2ab + b^2 = {k}ab + 2ab \Leftrightarrow (a + b)^2 = {k+2}ab$.
            \item $\Leftrightarrow \left( \dfrac{{a + b}}{{{sqrt_k_plus_2}}} \right)^2 = ab$.
            \item Lấy ${ten_log}$ hai vế ta được: ${ten_log} \left( \dfrac{{a + b}}{{{sqrt_k_plus_2}}} \right)^2 = {ten_log} (ab)$.
            \item $\Leftrightarrow 2 {ten_log} \left( \dfrac{{a + b}}{{{sqrt_k_plus_2}}} \right) = {ten_log} a + {ten_log} b$.
            \item $\Leftrightarrow {correct_ans}$.
        \end{{itemize}}
        Vậy đáp án đúng là khẳng định có ${correct_ans}$.
    }}
\end{{ex}}"""

#print(generate())
