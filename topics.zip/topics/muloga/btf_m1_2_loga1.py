import random
import sympy as sp
from sympy import symbols, latex, Rational

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    r"""Trộn câu hỏi và đảm bảo nhãn \True nằm ngoài $ $ để tránh lỗi biên dịch"""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Cấu trúc câu dẫn chuẩn \text{})
# =============================================================================

def generate():
    # 1. KHỞI TẠO DỮ LIỆU
    m = random.randint(2, 4)
    n = random.randint(2, 3)
    val_dung = n + m
    val_sai = n * m
    
    # --- DANH SÁCH DUNG (Câu dẫn nằm trong \text{}) ---
    d1 = f"$\\text{{Cho }} b>0, a>0, a\\neq 1 \\text{{ thỏa mãn }} \\log_ab={m} \\text{{ thì }} \\log_a(a^{n}b)={val_dung}$"
    d2 = f"$\\text{{Cho }} a>0, a\\neq 1 \\text{{ thì giá trị của }} \\log_{{\\sqrt{{a}}}}a=2$"
    d3 = f"$\\text{{Với các số thực dương }} x, y \\text{{ và }} a \\neq 1, \\text{{ ta luôn có }} \\log_a(xy) = \\log_ax + \\log_ay$"
    d4 = f"$\\text{{Nếu }} \\log_a b = {m} \\text{{ thì }} \\log_{{a^2}} b = {latex(Rational(m, 2))}$"

    # --- DANH SÁCH SAI (Câu dẫn nằm trong \text{}) ---
    s1 = f"$\\text{{Với các số thực dương }} x, y \\text{{ thì }} \\log_2\\left(\\dfrac{{x}}{{y}}\\right)=\\dfrac{{\\log_2x}}{{\\log_2y}}$"
    s2 = f"$\\text{{Cho }} a, b > 0, a \\neq 1 \\text{{ ta có }} \\log_a(b^n) = \\dfrac{{1}}{{n}}\\log_ab$"
    s3 = f"$\\text{{Với }} a>0, a\\neq 1 \\text{{ thì giá trị của }} \\log_a\\sqrt[n]{{a}} = {n}$"
    s4 = f"$\\text{{Nếu }} \\log_a b = {m} \\text{{ thì }} \\log_a(a^2b) = {val_sai}$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- LỜI GIẢI CHI TIẾT ---
    loigiai_parts = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            loigiai_parts.append(f"\\itemch \\textbf{{Đúng}}. Áp dụng quy tắc cộng: $\\log_a(a^{n}b) = \\log_a a^{n} + \\log_a b = {n} + {m} = {val_dung}$.")
        elif content == d2:
            loigiai_parts.append(f"\\itemch \\textbf{{Đúng}}. Ta có $\\log_{{a^{{1/2}}}} a = 2\\log_a a = 2$.")
        elif content == s1:
            loigiai_parts.append(f"\\itemch \\textbf{{Sai}}. Theo quy tắc lôgarit của một thương: $\\log_2\\left(\\dfrac{{x}}{{y}}\\right) = \\log_2x - \\log_2y$.")
        elif content == s2:
            loigiai_parts.append(f"\\itemch \\textbf{{Sai}}. Theo quy tắc lũy thừa: $\\log_a(b^n) = n\\log_ab$.")
        else:
            loigiai_parts.append(f"\\itemch \\textbf{{Kiểm tra}}. Áp dụng các tính chất cơ bản của lôgarit.")

    # --- RÁP MÃ LATEX ---
    thanhde = f"""\\begin{{ex}}
    Xét tính đúng sai của các khẳng định sau về lôgarit:
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_parts[0]}
            {loigiai_parts[1]}
            {loigiai_parts[2]}
            {loigiai_parts[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde.replace("\\frac", "\\dfrac")
