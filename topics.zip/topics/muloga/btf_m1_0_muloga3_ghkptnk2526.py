import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai theo chuẩn #deppy: Không trùng chỉ số, không lộ bài."""
    all_indices = random.sample(range(6), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    # A = log_2(log_x x^4) = log_2(4) = 2 (nhưng viết kiểu ẩn biến)
    base_nested = random.choice([2, 3])
    k = base_nested**random.randint(2, 3) # Để log_base(k) ra số nguyên (4 hoặc 8 hoặc 9)
    val_A = 2 if k == 4 or k == 9 else 3
    
    # B = x^{log_x (ln x)} = ln x (Dùng đẳng thức hoán vị)
    # Hoặc B = e^{ln(ln x)} = ln x
    # Chúng ta dùng: B = (ln x)^{log_x x} = ln x
    
    # --- 2. DANH SÁCH 6 CẶP ĐỐI ỨNG #DEPPY ---
    dung_list = [
        rf"$A = {val_A}$",                                          # Cặp 0: Hằng số ẩn
        rf"$B = \ln x$",                                           # Cặp 1: Rút gọn B
        rf"$e^{{B}} = x$",                                         # Cặp 2: Định nghĩa log tự nhiên
        rf"$\ln(A \cdot B) = \ln {val_A} + \ln(\ln x)$",           # Cặp 3: Tách log tích
        rf"$\text{{Với }} x = e, \text{{ tổng }} A + B = {val_A + 1}$", # Cặp 4: Thay số (ln e = 1)
        rf"$B > 0 \text{{ với mọi }} x > 1$"                       # Cặp 5: Tập giá trị
    ]
    
    sai_list = [
        rf"$A = \log_{{{base_nested}}} x$",                        # Cặp 0: Nhầm log lồng thành log thường
        rf"$B = x$",                                               # Cặp 1: Nhầm đẳng thức hoán vị
        rf"$B = e^x$",                                             # Cặp 2: Nhầm ngược hàm mũ và log
        rf"$\ln(A+B) = \ln {val_A} + \ln B$",                      # Cặp 3: Sai quy tắc cộng log
        rf"$\text{{Với}} x = e, \text{{ giá trị }} B = 0$",       # Cặp 4: Nhầm ln e = 0
        rf"$B > 0 \text{{ với mọi }} x > 0$"                       # Cặp 5: Quên điều kiện ln x xác định khi x > 1 để B > 0
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 3. ĐỊNH NGHĨA BIỂU THỨC ---
    A_tex = rf"\log_{{{base_nested}}} \left( \log_{{x}} x^{{{k}}} \right)"
    B_tex = rf"x^{{\log_{{x}}(\ln x)}}"

    return rf"""\begin{{ex}}
    Cho biểu thức $A = {A_tex}$ và $B = {B_tex}$ với $x > 1$.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        \textbf{{Biến đổi:}}
        \begin{{itemize}}
            \item $A = \log_{{{base_nested}}} ({k} \cdot \log_x x) = \log_{{{base_nested}}} {k} = {val_A}$.
            \item $B = x^{{\log_{{x}}(\ln x)}}$. Áp dụng công thức $a^{{\log_a \alpha}} = \alpha$, ta có $B = \ln x$.
        \end{{itemize}}
        Dựa vào $A = {val_A}$ và $B = \ln x$ để xét các khẳng định.
    }}
\end{{ex}}"""

print(generate())
