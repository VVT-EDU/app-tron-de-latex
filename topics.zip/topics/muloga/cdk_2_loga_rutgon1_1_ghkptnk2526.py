import random
from sympy import symbols, log, simplify, logcombine, latex, Rational
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    factor = Decimal('1') if decimals == 0 else Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    m = symbols('m', positive=True)
    k_sym = symbols('k')
    
    # Tham số ngẫu nhiên
    mu_val = random.choice([2, 3, 5])
    cso_a = 5
    cso_b = 2
    
    # M = log_{a^2}(m) * log_b(a^(1/mu))
    # M = (1/2 * log_a(m)) * (1/mu * log_b(a))
    # M = (1/(2*mu)) * (log_b(a) * log_a(m)) = (1/(2*mu)) * log_b(m)
    
    bt1 = log(m, cso_a**2)
    bt2 = log(cso_a**(Rational(1, mu_val)), cso_b)
    bt_prod = bt1 * bt2
    
    # Rút gọn chính xác bằng sympy
    bt_simplified = simplify(bt_prod)
    # Ép về dạng log(m^k, cso_b)
    # Lưu ý: log(m, b) trong sympy là log(m)/log(b)
    k_val = Rational(1, 2 * mu_val)
    
    # Tính S = 1/k
    s_val = 1 / k_val
    res_final = int(s_val)

    # 4. TRÌNH BÀY LỜI GIẢI THEO CÁC BƯỚC BIẾN ĐỔI LOGARIT
    y_list = [
        f"Ta có biểu thức: $M = \\log_{{{cso_a**2}}} m \\cdot \\log_{{{cso_b}}} {cso_a}^{{\\frac{{1}}{{{mu_val}}}}}$",
        f"Áp dụng tính chất $\\log_{{a^n}} b = \\frac{{1}}{{n}} \\log_a b$ và $\\log_a b^m = m \\log_a b$:",
        f"$M = \\left( \\frac{{1}}{{2}} \\log_{{{cso_a}}} m \\right) \\cdot \\left( \\frac{{1}}{{{mu_val}}} \\log_{{{cso_b}}} {cso_a} \\right)$",
        f"$M = \\frac{{1}}{{{2*mu_val}}} \\cdot \\left( \\log_{{{cso_b}}} {cso_a} \\cdot \\log_{{{cso_a}}} m \\right)$",
        f"Sử dụng công thức đổi cơ số $\\log_a b \\cdot \\log_b c = \\log_a c$, ta được:",
        f"$M = \\frac{{1}}{{{2*mu_val}}} \\log_{{{cso_b}}} m = \\log_{{{cso_b}}} m^{{\\frac{{1}}{{{2*mu_val}}}}}$",
        f"Đối chiếu với $M = \\log_{{{cso_b}}} m^k$, ta có $k = \\frac{{1}}{{{2*mu_val}}}$",
        f"Vậy $S = \\frac{{1}}{{k}} = {res_final}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    return rf"""\begin{{ex}}
Cho $m$ là số thực dương. Rút gọn biểu thức $M = \log_{{{cso_a**2}}} m \cdot \log_{{{cso_b}}} {cso_a}^{{\frac{{1}}{{{mu_val}}}}}$ ta được $M = \log_{{{cso_b}}} m^k$. Tính giá trị của $S = \frac{{1}}{{k}}$.
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
