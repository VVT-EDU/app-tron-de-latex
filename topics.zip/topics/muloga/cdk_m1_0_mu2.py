import random
from sympy import symbols, latex, Rational, simplify

def vn_format(number):
    """Định dạng số theo chuẩn Việt Nam, bọc trong $ $."""
    str_num = str(number)
    if '/' in str_num: 
        return f"${latex(number)}$"
    if '.' in str_num:
        parts = str_num.split('.')
        return f"${parts[0]},{parts[1]}$"
    return f"${str_num}$"

def generate():
    # 1. THIẾT LẬP THAM SỐ
    x = symbols('x')
    # Chọn mẫu số n cho số mũ (ví dụ n=2 hoặc n=3)
    n = random.choice([2, 3])
    
    # Thiết kế biểu thức: A = [ (x - 1)/(x^{1/n} + 1) ] + [ (x^{1/n} + 1) ]
    # Hoặc dạng phức tạp hơn một chút: 
    # A = (x - 1)/(x^{1/n} - 1) - (x^{(n-1)/n} + x^{(n-2)/n} + ... + 1)
    
    name = random.choice(['A', 'P', 'S', 'M'])
    
    if n == 2:
        # A = (x - 1)/(sqrt(x) + 1) + 1 = (sqrt(x)-1) + 1 = sqrt(x) = x^{1/2}
        expr_tex = rf"\dfrac{{x - 1}}{{x^{{1/2}} + 1}} + 1"
        a_val = Rational(1, 2)
        step_simplify = rf"$\dfrac{{x - 1}}{{x^{{1/2}} + 1}} = \dfrac{{(x^{{1/2}} - 1)(x^{{1/2}} + 1)}}{{x^{{1/2}} + 1}} = x^{{1/2}} - 1$"
    else: # n == 3
        # A = (x - 1)/(x^{1/3} - 1) - (x^{1/3} + 1) = (x^{2/3} + x^{1/3} + 1) - x^{1/3} - 1 = x^{2/3}
        expr_tex = rf"\dfrac{{x - 1}}{{x^{{1/3}} - 1}} - (x^{{1/3}} + 1)"
        a_val = Rational(2, 3)
        step_simplify = rf"$\dfrac{{x - 1}}{{x^{{1/3}} - 1}} = \dfrac{{(x^{{1/3}} - 1)(x^{{2/3}} + x^{{1/3}} + 1)}}{{x^{{1/3}} - 1}} = x^{{2/3}} + x^{{1/3}} + 1$"

    # 2. LINH ĐỘNG HỆ SỐ k ĐỂ T = k*a LÀ SỐ TỰ NHIÊN
    k = n * random.randint(2, 5)
    T_val = int(k * a_val)
    
    # 3. TRÌNH BÀY NỘI DUNG
    bai_tap = (
        rf"Cho biểu thức ${name} = {expr_tex}$ với $x > 0$ và $x \neq 1$. "
        rf"Biết rằng sau khi rút gọn, biểu thức có dạng ${name} = x^a$. "
        rf"Tính giá trị của biểu thức $T = {k}a$."
    )

    return rf"""\begin{{ex}}
{bai_tap}
\shortans{{ {T_val} }}
\loigiai{{
    Ta tiến hành rút gọn từng phần của biểu thức ${name}$:
    \begin{{itemize}}
        \item Sử dụng hằng đẳng thức để rút gọn phân thức:
        \item {step_simplify}.
        \item Thay vào biểu thức ${name}$, ta có:
        \item ${name} = {latex(simplify(a_val if n==2 else a_val+x**(1/3)+1-x**(1/3)-1))}$ (rút gọn các hạng tử đồng dạng).
        \item Kết quả rút gọn cuối cùng là: ${name} = x^{{{latex(a_val)}}}$.
        \item Suy ra $a = {vn_format(a_val)}$.
        \item Vậy $T = {k} \cdot {latex(a_val)} = {T_val}$.
    \end{{itemize}}
    Đáp số: $T = {T_val}$.
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
