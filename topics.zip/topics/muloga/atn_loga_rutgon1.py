import random
from fractions import Fraction

def to_latex_frac(n, d):
    """Hiển thị số nguyên hoặc phân số LaTeX tối giản."""
    frac = Fraction(n, d)
    if frac.denominator == 1:
        return str(frac.numerator)
    return rf"\dfrac{{{frac.numerator}}}{{{frac.denominator}}}"

def nhanvao_dsdungsai_rachoice_motdung(dung, sai):
    r"""Trộn 1 đúng, 3 sai theo định dạng \choice."""
    if len(dung) < 1 or len(sai) < 3:
        return "\\choice {Lỗi} {Lỗi} {Lỗi} {Lỗi}"
    
    selected_dung = dung[0]
    # Đảm bảo không lấy trùng đáp án đúng trong danh sách sai
    clean_sai = list(set([s for s in sai if s != selected_dung]))
    
    # Nếu không đủ 3 nhiễu, sinh thêm số ngẫu nhiên
    while len(clean_sai) < 3:
        clean_sai.append(f"${random.randint(-5, 10)}$")
        
    selected_sai = random.sample(clean_sai, 3)
    choices = [r'\True ' + selected_dung] + selected_sai
    random.shuffle(choices)
    
    return (f"\\choice \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def generate():
    # --- 1. THIẾT KẾ THÔNG SỐ ---
    # P = log_a ( a^n * sqrt[m]{a^p} )
    n = random.randint(2, 5)
    m = random.randint(2, 6)
    p = random.randint(1, 5)
    
    # Đảm bảo p/m không phải là số nguyên để nhìn giống căn thức hơn
    if p % m == 0:
        p = 1
        
    # Giá trị đúng: n + p/m
    val_frac = Fraction(n) + Fraction(p, m)
    correct_val = f"${to_latex_frac(val_frac.numerator, val_frac.denominator)}$"
    
    # --- 2. TẠO CÁC PHƯƠNG ÁN NHIỄU ---
    dssai = []
    # Nhiễu 1: Nhầm nhân thành chia (n - p/m)
    sai1 = Fraction(n) - Fraction(p, m)
    dssai.append(f"${to_latex_frac(sai1.numerator, sai1.denominator)}$")
    
    # Nhiễu 2: Nhầm căn thức nghịch đảo (n + m/p)
    sai2 = Fraction(n) + Fraction(m, p)
    dssai.append(f"${to_latex_frac(sai2.numerator, sai2.denominator)}$")
    
    # Nhiễu 3: Nhầm quy tắc log (n * p / m)
    sai3 = Fraction(n * p, m)
    dssai.append(f"${to_latex_frac(sai3.numerator, sai3.denominator)}$")
    
    # Nhiễu 4: Các lỗi tính toán cộng trừ hệ số đơn giản
    dssai.append(f"${n + p}$")
    dssai.append(f"${n + m}$")

    # --- 3. RÁP LATEX ---
    toan = nhanvao_dsdungsai_rachoice_motdung([correct_val], dssai)
    
    # Biểu thức P sử dụng biến 'a' để khớp với câu dẫn
    P_tex = rf"\log_{{a}} \left( a^{{{n}}} \cdot \sqrt[{{{m}}}]{{a^{{{p}}}}} \right)"

    return rf"""\begin{{ex}}
Cho số thực $a > 0, a \neq 1$. Giá trị của biểu thức $P = {P_tex}$ bằng
{toan}
\loigiai{{
Ta có: $P = \log_{{a}} \left( a^{{{n}}} \cdot a^{{\frac{{{p}}}{{{m}}}}} \right) 
= \log_{{a}} \left( a^{{{n} + \frac{{{p}}}{{{m}}}}} \right) 
= {n} + \dfrac{{{p}}}{{{m}}} = {correct_val.replace('$', '')}$.
}}
\end{{ex}}"""

# In kết quả kiểm tra
print(generate())
