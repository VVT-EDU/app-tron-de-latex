import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ 6 cặp khẳng định đối ứng kiểu #deppy."""
    all_indices = random.sample(range(6), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    # A = 1/log_{a} x + 1/log_{b} x = log_x (a*b)
    a_val = random.randint(2, 5)
    b_val = random.randint(2, 5)
    val_AB_product = a_val * b_val
    
    # B = x^{1/2} * x^{1/4} * x^{1/8}... rút gọn về x^{1 - 1/2^n}
    # Ở đây chọn kiểu lũy thừa hữu tỉ phức tạp: B = (x^p / x^q)^{1/r}
    p, q = random.randint(5, 9), random.randint(2, 4)
    r = random.randint(2, 3)
    val_B_exp = (p - q) / r # Giả sử là số mũ của x

    # --- 2. DANH SÁCH 6 CẶP ĐỐI ỨNG MỚI ---
    dung_list = [
        rf"$A = \log_{{x}}({val_AB_product})$",                          # Cặp 0: Rút gọn A
        rf"$\log_{{x}} B = \dfrac{{{p-q}}}{{{r}}}$",                    # Cặp 1: Rút gọn B
        rf"$A + \log_{{x}} B = \log_{{x}} \left( {val_AB_product} \cdot x^{{{p-q}/{r}}} \right)$", # Cặp 2: Tổng hợp
        rf"$\text{{Khi }} x = {val_AB_product} \text{{ thì }} A = 1$",   # Cặp 3: Điểm đặc biệt
        rf"$x^{{A}} = {val_AB_product}$",                               # Cặp 4: Định nghĩa mũ
        rf"$\dfrac{{A}}{{\log_{{x}} B}} = \dfrac{{{r} \log_{{x}} {val_AB_product}}}{{{p-q}}}$" # Cặp 5: Tỉ số
    ]
    
    sai_list = [
        rf"$A = \log_{{{val_AB_product}}} x$",                          # Cặp 0: Nhầm cơ số
        rf"$\log_{{x}} B = \dfrac{{{p+q}}}{{{r}}}$",                    # Cặp 1: Nhầm phép chia thành nhân
        rf"$A \cdot \log_{{x}} B = \log_{{x}} \left( {val_AB_product}^{{{(p-q)/r}}} \right)$", # Cặp 2: Nhầm tính chất log
        rf"$\text{{Khi }} x = {val_AB_product} \text{{ thì }} A = 0$",   # Cặp 3: Giá trị sai
        rf"$x^{{A}} = x^{{{val_AB_product}}}$",                         # Cặp 4: Nhầm log cơ số x
        rf"$\dfrac{{A}}{{\log_{{x}} B}} = {val_AB_product}$"           # Cặp 5: Sai tỉ số hằng
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 3. ĐỊNH NGHĨA BIỂU THỨC ---
    A_tex = rf"\dfrac{{1}}{{\log_{{{a_val}}} x}} + \dfrac{{1}}{{\log_{{{b_val}}} x}}"
    B_tex = rf"\sqrt[{{{r}}}]{{\dfrac{{x^{{{p}}}}}{{x^{{{q}}}}}}}"

    return rf"""\begin{{ex}}
    Cho các biểu thức $A = {A_tex}$ và $B = {B_tex}$ với $x > 0, x \neq 1$.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        \textbf{{Rút gọn biểu thức:}}
        \begin{{itemize}}
            \item $A = \log_{{x}} {a_val} + \log_{{x}} {b_val} = \log_{{x}}({a_val} \cdot {b_val}) = \log_{{x}} {val_AB_product}$.
            \item $B = \left( x^{{{p}-{q}}} \right)^{{1/{r}}} = x^{{{p-q}/{r}}}$. Suy ra $\log_{{x}} B = \dfrac{{{p-q}}}{{{r}}}$.
        \end{{itemize}}
        Dựa vào $A = \log_{{x}} {val_AB_product}$ và $\log_{{x}} B = \frac{{{p-q}}}{{{r}}}$ để kiểm tra khẳng định.
    }}
\end{{ex}}"""

#print(generate())
