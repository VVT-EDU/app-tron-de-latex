import random

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    r"""Trộn 2 đúng, 2 sai theo định dạng \choiceTF."""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Sửa lỗi Syntax và Định dạng)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ
    a = random.choice([2, 3, 5]) 
    k = random.randint(3, 5)  
    n_last = a**k             
    
    # 2. DANH SÁCH KHẲNG ĐỊNH
    # --- CÁC CÂU ĐÚNG ---
    d1 = r"$\text{Tập xác định của hàm số } y=\log_{" + str(a) + r"}x \text{ là } \mathscr{D}=(0;+\infty)$"
    d2 = r"$\text{Hàm số } y=\log_{" + str(a) + r"}x \text{ đồng biến trên tập xác định của nó}$"
    d3 = r"$\text{Đồ thị hàm số đi qua điểm } (" + str(a**2) + r";2)$"
    d4 = r"$\text{Tổng } T = \sum_{i=1}^{" + str(n_last-1) + r"} f\left(\dfrac{i}{i+1}\right) = -" + str(k) + r"$"

    # --- CÁC CÂU SAI ---
    s1 = r"$\text{Hàm số } y=\log_{" + str(a) + r"}x \text{ đồng biến trên } \mathbb{R}$"
    s2 = r"$\text{Đồ thị hàm số cắt trục tung tại điểm } (0;1)$"
    s3 = r"$\text{Tập giá trị của hàm số là } (0;+\infty)$"
    s4 = r"$\text{Tổng } T = f\left(\dfrac{1}{2}\right) + \dots + f\left(\dfrac{" + str(n_last-1) + r"}{" + str(n_last) + r"}\right) = " + str(k) + r"$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = r"\textbf{Đúng}. Điều kiện xác định là $x > 0$."
        elif content == d2:
            note = f"\\textbf{{Đúng}}. Do cơ số ${a} > 1$."
        elif content == d4:
            note = f"\\textbf{{Đúng}}. $T = \\log_{a} \\frac{{1}}{{2}} + \\log_{a} \\frac{{2}}{{3}} + \\dots = \\log_{a} 1 - \\log_{a} {n_last} = -{k}$."
        elif content == s1:
            note = r"\textbf{Sai}. Tập xác định chỉ là $(0;+\infty)$."
        elif content == s2:
            note = r"\textbf{Sai}. Đồ thị lôgarit nhận trục tung làm tiệm cận đứng."
        elif content == s3:
            note = r"\textbf{Sai}. Tập giá trị là $\mathbb{R}$."
        else:
            note = r"\textbf{Kiểm tra}. Dựa vào tính chất đồ thị hàm số lôgarit."
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = rf"""\begin{{ex}}
    Cho hàm số $y=f(x)=\log_{{{a}}}x$ có đồ thị $(C)$. \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        \begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \end{{itemchoice}}
    }}
\end{{ex}}"""

    return thanhde
