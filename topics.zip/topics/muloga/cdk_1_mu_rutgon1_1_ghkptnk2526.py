import random
from sympy import symbols, sqrt, simplify, latex, Rational
from decimal import Decimal, ROUND_HALF_UP

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP CÁC BIẾN VÀ THÔNG SỐ
    # Khai báo x, y dương để simplify hoạt động chính xác
    x, y = symbols('x y', positive=True)
    t_sym, k_sym = symbols('t k')
    
    a = random.choice([2, 3, 4, 5])
    b = random.choice([2, 3, 5, 7])
    c = random.choice([1, 3, 5])
    
    can = b
    mu1 = a - sqrt(can)
    mu2 = b + sqrt(can)
    mu3 = c - sqrt(can)
    
    # 2. XÂY DỰNG BIỂU THỨC
    # Biểu thức gốc
    bt = x**mu1 * (x*y)**mu2 / y**mu3
    
    # Các bước biến đổi để trình bày lời giải
    bt1 = x**mu1 * x**mu2 * y**mu2 / y**mu3
    bt2 = simplify(bt1)
    
    # 3. TRÍCH XUẤT SỐ MŨ VÀ TÍNH TỔNG
    # Lấy số mũ của x và y từ biểu thức đã rút gọn
    # bt2 có dạng x**t * y**k
    mux = bt2.as_powers_dict()[x]
    muy = bt2.as_powers_dict()[y]
    tong = mux + muy
    
    # Tính giá trị làm tròn
    val_tong_float = float(tong.evalf())
    res_final = int(round_half_up(val_tong_float, 0))
    
    # 4. TRÌNH BÀY NỘI DUNG CÂU HỎI
    M_label = x**t_sym * y**k_sym
    bai = f"Biểu thức $M={latex(bt)}$ với $x, y$ là các số thực dương, được biến đổi thành $M={latex(M_label)}$."
    cau_hoi = f"{bai} Tính $ t + k$ (làm tròn kết quả đến hàng đơn vị)."
    
    # 5. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Ta có: $M = {latex(bt1)}$",
        f"Rút gọn biểu thức: $M = {latex(bt2)}$",
        f"Suy ra $t = {latex(mux)}$ và $k = {latex(muy)}$",
        f"Khi đó tổng $S = t + k = {latex(tong)}$",
        f"Giá trị xấp xỉ: $S \\approx {val_tong_float:.2f}$",
        f"Làm tròn đến hàng đơn vị, ta được kết quả là ${res_final}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 6. XUẤT KẾT QUẢ THEO MẪU
    content = rf"""\begin{{ex}}
{cau_hoi}
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

# Thực thi
#if __name__ == "__main__":
print(generate())
