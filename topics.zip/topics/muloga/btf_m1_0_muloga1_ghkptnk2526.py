import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ 6 cặp khẳng định đối ứng không gây lộ bài."""
    all_indices = random.sample(range(6), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def generate():
    # --- 1. RANDOM THAM SỐ ---
    base = random.choice([2, 3, 5])
    k, m = random.randint(2, 4), random.randint(2, 3)
    p = random.randint(2, 4)
    
    val_A = k * m
    val_B_exp = p**2 

    # --- 2. DANH SÁCH 6 CẶP ĐỐI ỨNG (SO SÁNH KẾT QUẢ) ---
    # Mục tiêu: Học sinh phải tính xong cả A và B mới chọn được đúng sai
    dung_list = [
        rf"$\log_{{{base}}} A = \log_{{{base}}} {val_A}$",             # Cặp 0: So sánh qua log
        rf"$\ln B > (\ln x)^2$",                                       # Cặp 1: Bất đẳng thức (vì val_B_exp >= 4)
        rf"$\dfrac{{\ln B}}{{(\ln x)^2}} - A = {val_B_exp - val_A}$",  # Cặp 2: Hiệu sau rút gọn
        rf"$A \cdot (\ln x)^2 = \dfrac{{{val_A}}}{{{val_B_exp}}} \ln B$", # Cặp 3: Đẳng thức tỉ lệ
        rf"$\text{{Với }} x = e, \text{{ giá trị biểu thức }} B \text{{ là một số vô tỷ}}$", # Cặp 4: Tính chất số học
        rf"$B > 1 \text{{ với mọi }} x \neq 1$"                       # Cặp 5: Tính chất hàm mũ
    ]
    
    sai_list = [
        rf"$A = {val_A + 1}$",                                         # Cặp 0: Sai số hằng
        rf"$\ln B < (\ln x)^2$",                                       # Cặp 1: Ngược dấu bất đẳng thức
        rf"$\ln B - A = {val_B_exp - val_A}$",                         # Cặp 2: Sai vì thiếu (ln x)^2 ở B
        rf"$A \cdot \ln B = {val_A * p}(\ln x)^2$",                    # Cặp 3: Sai do quên bình phương p
        rf"$\text{{Với }} x = e, \text{{ giá trị biểu thức }} B \text{{ là một số nguyên}}$", # Cặp 4: Bẫy số nguyên
        rf"$B < 1 \text{{ khi }} 0 < x < 1$"                           # Cặp 5: Sai do bình phương luôn dương
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 3. ĐỊNH NGHĨA BIỂU THỨC ---
    A_tex = rf"\log_{{{base}}} x^{{{k}}} \cdot \log_{{x}} {base}^{{{m}}}"
    B_tex = rf"e^{{(\ln x^{{{p}}})^2}}"

    return rf"""\begin{{ex}}
    Cho các biểu thức $A = {A_tex}$ và $B = {B_tex}$ với $x > 0, x \neq 1$.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        Biến đổi rút gọn ta được:
        \begin{{itemize}}
            \item $A = {k}\log_{{{base}}} x \cdot {m}\log_x {base} = {k} \cdot {m} = {val_A}$.
            \item $\ln B = (\ln x^{{{p}}})^2 = ({p}\ln x)^2 = {val_B_exp}(\ln x)^2$.
        \end{{itemize}}
        Từ các kết quả rút gọn trên, ta đối chiếu để kiểm tra tính đúng sai của các khẳng định.
    }}
\end{{ex}}"""

#print(generate())
