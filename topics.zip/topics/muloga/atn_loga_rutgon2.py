import random
from fractions import Fraction

def to_latex_frac(n, d):
    """Hiển thị số nguyên hoặc phân số LaTeX tối giản."""
    frac = Fraction(n, d)
    if frac.denominator == 1:
        return str(frac.numerator)
    return rf"\dfrac{{{frac.numerator}}}{{{frac.denominator}}}"

def nhanvao_dsdungsai_rachoice_motdung(dung, sai):
    r"""Trộn 1 đúng, 3 sai theo định dạng \choice."""
    selected_dung = dung[0]
    clean_sai = list(set([s for s in sai if s != selected_dung]))
    while len(clean_sai) < 3:
        clean_sai.append(f"${random.randint(-10, 20)}$")
    selected_sai = random.sample(clean_sai, 3)
    choices = [r'\True ' + selected_dung] + selected_sai
    random.shuffle(choices)
    return (f"\\choice \n"
            f" {{ {choices[0]} }}\n"
            f" {{ {choices[1]} }}\n"
            f" {{ {choices[2]} }}\n"
            f" {{ {choices[3]} }}")

def generate():
    # --- 1. THIẾT KẾ BIỂU THỨC PHỨC TẠP ---
    # Dạng: P = log_{a^m} (a^n / sqrt[k]{a^p}) + a^{log_a(q)}
    a = 'a'
    n = random.randint(2, 5)
    m = random.randint(2, 3)
    k = random.randint(2, 4)
    p = random.randint(1, 3)
    q = random.randint(2, 6) # Số hạng tự do bên ngoài log

    # Bước 1: Tính log_{a^m} (a^n / a^{p/k}) = (1/m) * (n - p/k)
    val_log = Fraction(1, m) * (Fraction(n) - Fraction(p, k))
    # Bước 2: Cộng với q (vì a^{log_a(q)} = q)
    val_total = val_log + Fraction(q)
    
    correct_val = f"${to_latex_frac(val_total.numerator, val_total.denominator)}$"

    # --- 2. TẠO CÁC PHƯƠNG ÁN NHIỄU (Bẫy các lỗi phổ biến) ---
    dssai = []
    # Nhiễu 1: Nhầm dấu trong log (n + p/k) + q
    sai1 = Fraction(1, m) * (Fraction(n) + Fraction(p, k)) + Fraction(q)
    dssai.append(f"${to_latex_frac(sai1.numerator, sai1.denominator)}$")
    
    # Nhiễu 2: Quên đưa 1/m ra ngoài (n - p/k) + q
    sai2 = (Fraction(n) - Fraction(p, k)) + Fraction(q)
    dssai.append(f"${to_latex_frac(sai2.numerator, sai2.denominator)}$")
    
    # Nhiễu 3: Nhầm log(a^n/...) thành n * log(...) + q
    sai3 = Fraction(n, m) * Fraction(p, k) + Fraction(q)
    dssai.append(f"${to_latex_frac(sai3.numerator, sai3.denominator)}$")

    # --- 3. RÁP LATEX ---
    toan = nhanvao_dsdungsai_rachoice_motdung([correct_val], dssai)
    
    # Biểu thức P: \log_{a^{m}} \left( \frac{a^{n}}{\sqrt[k]{a^{p}}} \right) + a^{\log_{a} q}
    P_tex = rf"\log_{{{a}^{{{m}}}}} \left( \dfrac{{{a}^{{{n}}}}}{{\sqrt[{{{k}}}]{{{a}^{{{p}}}}}}} \right) + {a}^{{\log_{{{a}}} {q}}}"

    return rf"""\begin{{ex}}
Cho số thực $a > 0, a \neq 1$. Giá trị của biểu thức $P = {P_tex}$ bằng
{toan}
\loigiai{{
Ta biến đổi từng số hạng của biểu thức $P$:
\begin{{itemize}}
    \item Số hạng thứ nhất: $\log_{{{a}^{{{m}}}}} \left( \dfrac{{{a}^{{{n}}}}}{{\sqrt[{{{k}}}]{{{a}^{{{p}}}}}}} \right) = \dfrac{{1}}{{{m}}} \log_{{{a}}} \left( \dfrac{{{a}^{{{n}}}}}{{{a}^{{\frac{{{p}}}{{{k}}}}}}} \right) = \dfrac{{1}}{{{m}}} \left( {n} - \dfrac{{{p}}}{{{k}}} \right) = {to_latex_frac(val_log.numerator, val_log.denominator)}$.
    \item Số hạng thứ hai: ${a}^{{\log_{{{a}}} {q}}} = {q}$.
\end{{itemize}}
Vậy $P = {to_latex_frac(val_log.numerator, val_log.denominator)} + {q} = {correct_val.replace('$', '')}$.
}}
\end{{ex}}"""

print(generate())
