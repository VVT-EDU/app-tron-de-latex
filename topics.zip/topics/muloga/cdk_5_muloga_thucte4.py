import random
import math
from sympy import symbols, Eq, solve, latex, log
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP THAM SỐ
    M_sym = symbols('M')
    # Chọn độ Richter ngẫu nhiên từ 4.0 đến 8.0 để năng lượng đủ lớn
    do_Richter = random.choice([4.0, 5.0, 6.0, 7.0, 8.0]) 
    
    # Công thức: log10(E) = 11.4 + 1.5 * M
    bieu_thuc_mu = 11.4 + 1.5 * M_sym
    
    # 2. TÍNH TOÁN NĂNG LƯỢNG E
    # Tính số mũ: e_exponent = 11.4 + 1.5 * do_Richter
    e_exponent = float(bieu_thuc_mu.subs(M_sym, do_Richter))
    
    # E = 10^e_exponent
    E_val = 10**e_exponent
    
    # 3. CHUYỂN ĐỔI SANG DẠNG P * 10^k
    # somumuoi (k) là phần nguyên của e_exponent
    somumuoi = math.floor(e_exponent)
    P_val = E_val / (10**somumuoi)
    
    # Làm tròn P đến hàng đơn vị
    kq_cuoi = int(round_half_up(P_val, 0))
    
    # 4. TRÌNH BÀY ĐỀ BÀI VÀ LỜI GIẢI
    bai_tap = (
        f"Trong một trận động đất, năng lượng giải toả $E$ (đơn vị: Jun, kí hiệu $J$) "
        f"tại tâm địa chấn ở $M$ độ Richter được xác định xấp xỉ bởi công thức: "
        f"$\\log E \\approx 11,4 + 1,5M$. "
        f"Gọi $E_{{{do_Richter}}}$ là năng lượng giải toả tại tâm địa chấn của một trận động đất mạnh ${do_Richter}$ độ Richter. "
        f"Tính giá trị biểu thức $P = \\frac{{E_{{{do_Richter}}}}}{{10^{{{somumuoi}}}}}$ (làm tròn kết quả đến hàng đơn vị)."
    )

    y_list = [
        f"Thay $M = {do_Richter}$ vào công thức $\\log E \\approx 11,4 + 1,5M$, ta có:",
        f"$\\log E \\approx 11,4 + 1,5 \\cdot {do_Richter} = {e_exponent}$",
        f"$\\Rightarrow E \\approx 10^{{{e_exponent}}}$",
        f"Ta có thể viết lại: $E \\approx 10^{{{e_exponent - somumuoi} + {somumuoi}}} = 10^{{{e_exponent - somumuoi:.1f}}} \\cdot 10^{{{somumuoi}}}$",
        f"Khi đó: $P = \\frac{{E}}{{10^{{{somumuoi}}}}} = 10^{{{e_exponent - somumuoi:.1f}}}$",
        f"Tính toán giá trị: $P \\approx {P_val:.4f}$",
        f"Làm tròn đến hàng đơn vị, ta được $P \\approx {kq_cuoi}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 5. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
{bai_tap}
\shortans{{ ${kq_cuoi}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

if __name__ == "__main__":
    print(generate())
