import random
import math

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai theo định dạng \choiceTF."""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Khảo sát và Giải BPT Mũ - Qt6 Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ NGẪU NHIÊN
    # f(x) = (1/a)^x. Xét f(x) > (a^k)^(x^2) <=> a^-x > a^(k*x^2)
    # <=> -x > kx^2 <=> kx^2 + x < 0 <=> x(kx + 1) < 0
    # Nghiệm: -1/k < x < 0
    
    a = random.choice([2, 3])
    k = random.choice([2, 3, 4])
    val_pow = a**k # Ví dụ: 4, 8, 9, 27, 16, 81
    x_test = -2
    y_test = a**(-x_test)
    
    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    # --- CÁC CÂU ĐÚNG ---
    d1 = f"$\\text{{Giá trị của hàm số tại }} x={x_test} \\text{{ là }} f({x_test})={y_test}$"
    d2 = f"$\\text{{Phương trình }} f(x)=m \\text{{ có nghiệm khi và chỉ khi }} m > 0$"
    d3 = f"$\\text{{Tập nghiệm của bất phương trình }} f(x) > {val_pow}^{{x^2}} \\text{{ là }} S = \\left(-\\dfrac{{1}}{{{k}}}; 0\\right)$"
    d4 = f"$\\text{{Hàm số }} f(x) \\text{{ nghịch biến trên khoảng }} (-\\infty; +\\infty)$"

    # --- CÁC CÂU SAI ---
    s1 = r"$\text{Tập xác định của hàm số } f(x) \text{ là } \mathscr{D}=(0;+\infty)$"
    s2 = f"$\\text{{Tập nghiệm của bất phương trình }} f(x) > {val_pow}^{{x^2}} \\text{{ là }} S = \\left(-1; -\\dfrac{{1}}{{{k}}}\\right)$"
    s3 = f"$\\text{{Đồ thị hàm số }} f(x) \\text{{ cắt trục tung tại điểm }} (1; 0)$"
    s4 = f"$\\text{{Hàm số đã cho đồng biến trên }} \\mathbb{{R}}$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = f"\\textbf{{Đúng}}. $f({x_test}) = (\\frac{{1}}{{{a}}})^{{{x_test}}} = {a}^2 = {y_test}$."
        elif content == d2:
            note = f"\\textbf{{Đúng}}. Vì $f(x) = (\\frac{{1}}{{{a}}})^x$ luôn dương với mọi $x \\in \\mathbb{{R}}$."
        elif content == d3:
            note = f"\\textbf{{Đúng}}. $f(x) > {val_pow}^{{x^2}} \\Leftrightarrow {a}^{{-x}} > {a}^{{{k}x^2}} \\Leftrightarrow {k}x^2 + x < 0 \\Leftrightarrow -\\frac{{1}}{{{k}}} < x < 0$."
        elif content == s1:
            note = r"\textbf{Sai}.
