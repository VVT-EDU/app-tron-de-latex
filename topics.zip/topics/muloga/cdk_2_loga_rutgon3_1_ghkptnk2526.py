import random
import math
from sympy import symbols, log, latex
from decimal import Decimal, ROUND_HALF_UP

def round_half_up(number, decimals=0):
    if decimals == 0:
        factor_dec = Decimal('1')
    else:
        factor_dec = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor_dec, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN
    a, b = symbols('a b', positive=True)
    
    # Chọn một giá trị X_val ngẫu nhiên để b = sqrt(X_val)
    X_val = random.choice([3, 5, 6, 7, 8, 10, 11])
    
    # 2. TÍNH TOÁN KẾT QUẢ VỚI HÀM LÀM TRÒN MỚI
    raw_b = math.sqrt(X_val)
    res_b = round_half_up(raw_b, 2)
    
    # 3. TRÌNH BÀY LỜI GIẢI
    # Lưu ý: Sử dụng double braces {{ }} để LaTeX không bị Python hiểu lầm là biến
    y_list = [
        f"Điều kiện: $a, b > 0; a, b \\neq 1; ab \\neq 1$.",
        f"Biến đổi vế phải (VP):",
        f"$\\log_a b + \\log_b a + 2 = \\log_a b + \\frac{{1}}{{\\log_a b}} + 2 = \\frac{{(\\log_a b + 1)^2}}{{\\log_a b}}$.",
        f"$\\log_{{ab}} b = \\frac{{\\log_a b}}{{\\log_a (ab)}} = \\frac{{\\log_a b}}{{1 + \\log_a b}}$.",
        f"$\\Rightarrow \\log_a b - \\log_{{ab}} b = \\log_a b - \\frac{{\\log_a b}}{{1 + \\log_a b}} = \\frac{{(\\log_a b)^2}}{{1 + \\log_a b}}$.",
        f"Khi đó: $VP = \\left[ \\frac{{(\\log_a b + 1)^2}}{{\\log_a b}} \\right] \\cdot \\left[ \\frac{{(\\log_a b)^2}}{{1 + \\log_a b}} \\right] \\cdot \\frac{{1}}{{\\log_a b}} - 1$",
        f"$VP = (\\log_a b + 1) - 1 = \\log_a b$.",
        f"Phương trình trở thành: $\\log_a \\frac{{{X_val}}}{{b}} = \\log_a b \\iff \\frac{{{X_val}}}{{b}} = b \\iff b^2 = {X_val}$.",
        f"Vì $b > 0$ nên $b = \\sqrt{{{X_val}}} \\approx {res_b}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 4. XUẤT KẾT QUẢ
    # Dùng {{ab}} trong LaTeX để tránh lỗi NameError 'ab'
    return rf"""\begin{{ex}}
Cho $a, b$ là các số thực dương khác $1$ và thỏa mãn $ab \neq 1$. Biết rằng:
\[ \log_a \frac{{{X_val}}}{{b}} = (\log_a b + \log_b a + 2)(\log_a b - \log_{{ab}} b)\log_b a - 1 \]
Tìm giá trị của $b$ (làm tròn kết quả đến hàng phần trăm).
\shortans{{ {res_b} }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
