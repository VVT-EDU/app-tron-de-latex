import random
from sympy import symbols, latex, Rational, simplify

def vn_format(number):
    """Định dạng số theo chuẩn Việt Nam, bọc trong $ $."""
    str_num = str(number)
    if '/' in str_num: 
        return f"${latex(number)}$"
    if '.' in str_num:
        parts = str_num.split('.')
        return f"${parts[0]},{parts[1]}$"
    return f"${str_num}$"

def generate():
    # 1. THIẾT LẬP THAM SỐ
    a, b = symbols('a b')
    mode = random.choice(['sum', 'diff'])
    
    if mode == 'sum':
        k_val = random.choice([3, 4, 5, 7])
        ab_coeff = k_val**2 - 2
        formula_tex = rf"a^2 + b^2 = {ab_coeff}ab"
        base = k_val
        expr_inside = rf"\dfrac{{a + b}}{{{base}}}"
        # Chuỗi logic cho lời giải (Dùng raw string để tránh lỗi \R)
        logic_step = rf"$a^2 + 2ab + b^2 = {ab_coeff + 2}ab \Rightarrow (a+b)^2 = {base**2}ab$"
    else:
        k_val = 4
        ab_coeff = 12
        formula_tex = rf"a^2 + 4b^2 = {ab_coeff}ab"
        base = k_val
        expr_inside = rf"\dfrac{{a + 2b}}{{{base}}}"
        logic_step = rf"$a^2 + 4ab + 4b^2 = 16ab \Rightarrow (a+2b)^2 = 16ab$"

    # 2. HỆ SỐ X, Y LUÔN LÀ 1/2 TRONG DẠNG NÀY
    m_val = random.randint(2, 5) * 2 # Luôn chọn số chẵn
    n_val = random.randint(2, 5) * 2
    T_result = int(m_val * 0.5 + n_val * 0.5)
    
    name = random.choice(['P', 'S', 'Q', 'K'])

    # 3. TRÌNH BÀY NỘI DUNG
    bai_tap = (
        rf"Cho hai số thực dương $a, b$ thỏa mãn đẳng thức ${formula_tex}$. "
        rf"Biết rằng $\log_{{{base}}} \left( {expr_inside} \right) = x \log_{{{base}}} a + y \log_{{{base}}} b$. "
        rf"Tính giá trị của biểu thức $T = {m_val}x + {n_val}y$."
    )

    return rf"""\begin{{ex}}
{bai_tap}
\shortans{{ {T_result} }}
\loigiai{{
    Từ giả thiết ${formula_tex}$, ta biến đổi để tạo ra bình phương một tổng:
    \begin{{itemize}}
        \item Cộng thêm hạng tử phù hợp vào hai vế:
        \item {logic_step}
        \item Suy ra: $\left( {expr_inside} \right)^2 = ab \Rightarrow {expr_inside} = (ab)^{{1/2}}$.
        \item Lấy logarit cơ số ${base}$ hai vế, ta được:
        \item $\log_{{{base}}} \left( {expr_inside} \right) = \log_{{{base}}} (ab)^{{1/2}} = \dfrac{{1}}{{2}} \log_{{{base}}} a + \dfrac{{1}}{{2}} \log_{{{base}}} b$.
        \item Đối chiếu vế phải, ta có $x = \dfrac{{1}}{{2}}$ và $y = \dfrac{{1}}{{2}}$.
        \item Vậy $T = {m_val} \cdot \dfrac{{1}}{{2}} + {n_val} \cdot \dfrac{{1}}{{2}} = {T_result}$.
    \end{{itemize}}
    Đáp số: $T = {T_result}$.
}}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
