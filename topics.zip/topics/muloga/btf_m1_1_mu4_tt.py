import random
from sympy import Rational
from decimal import Decimal, ROUND_HALF_UP

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def round_half_up(number, decimals=0):
    """Làm tròn chuẩn số học: 0.5 lên 1"""
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(float(number))).quantize(factor, rounding=ROUND_HALF_UP))

def format_vn(number):
    """Chuyển số thành chuỗi có dấu phẩy thập phân kiểu VN, bỏ .0 nếu là số nguyên"""
    s = str(number)
    if s.endswith('.0'):
        s = s[:-2]
    return s.replace('.', ',')

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai theo định dạng \choiceTF của LaTeX"""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    
    selected_dung = random.sample(dung, 2)
    selected_sai = random.sample(sai, 2)
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (Sử dụng Rational, Decimal & r-strings)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ (Sử dụng Rational để tính toán chính xác)
    P1 = Rational(random.choice([100, 200, 300, 500])) # Triệu đồng
    P2 = P1 # Số tiền gửi thêm sau 6 tháng
    r_val = random.choice([1.5, 2.0, 2.5, 3.0])
    r_rat = Rational(str(r_val)) / 100 # Lãi suất theo quý
    
    # Tính toán các mốc (Chuyển sang float để làm tròn chuẩn ROUND_HALF_UP)
    # Sau 1 quý (3 tháng)
    lai_1_quy = round_half_up(P1 * r_rat, 2)
    
    # Sau 2 quý (6 tháng)
    T_6th = P1 * (1 + r_rat)**2
    T_6th_val = round_half_up(T_6th, 2)
    
    # Gửi thêm P2 sau 6 tháng -> Gốc mới
    Goc_moi = T_6th + P2
    
    # Sau 1 năm (tổng 4 quý, thêm 2 quý sau khi gửi thêm)
    T_1nam = Goc_moi * (1 + r_rat)**2
    T_1nam_val = round_half_up(T_1nam, 1) # Làm tròn đến hàng phần mười
    
    # Sau 2 năm (tổng 8 quý, thêm 6 quý sau khi gửi thêm)
    T_2nam = Goc_moi * (1 + r_rat)**6
    T_2nam_val = round_half_up(T_2nam, 1)

    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng r-string và \text{})
    d1 = f"$\\text{{Sau 3 tháng đầu tiên, số tiền lãi nhận được là }} {format_vn(lai_1_quy)} \\text{{ triệu đồng}}$"
    d2 = f"$\\text{{Nếu sau 6 tháng không gửi thêm tiền, số tiền nhận được là }} {format_vn(T_6th_val)} \\text{{ triệu đồng}}$"
    d3 = f"$\\text{{Sau 1 năm (4 quý), tổng số tiền nhận được là }} {format_vn(T_1nam_val)} \\text{{ triệu đồng}}$"
    d4 = f"$\\text{{Sau 2 năm, số tiền nhận được xấp xỉ }} {format_vn(T_2nam_val)} \\text{{ triệu đồng}}$"
    
    s1 = f"$\\text{{Sau 3 tháng đầu tiên, số tiền lãi nhận được là }} {format_vn(round_half_up(lai_1_quy + Rational(1,2), 1))} \\text{{ triệu đồng}}$"
    s2 = f"$\\text{{Số tiền sau 6 tháng nhận được nếu tính theo lãi đơn là }} {format_vn(round_half_up(P1 * (1 + 2*r_rat), 2))} \\text{{ triệu đồng}}$"
    s3 = f"$\\text{{Sau 1 năm số tiền nhận được là }} {format_vn(round_half_up(T_1nam_val - 5, 1))} \\text{{ triệu đồng}}$"
    s4 = f"$\\text{{Tổng số tiền nhận được sau 2 năm gửi tiết kiệm là một số nguyên}}$"
    
    dung = [d1, d2, d3, d4]
    sai = [s1, s2, s3, s4]
    
    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung, sai)
    
    # 3. XÂY DỰNG LỜI GIẢI
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = f"\\textbf{{Đúng}}. Tiền lãi sau quý đầu: ${format_vn(P1)} \\times {format_vn(r_val)}\\% = {format_vn(lai_1_quy)}$ triệu đồng."
        elif content == d2:
            note = f"\\textbf{{Đúng}}. Số tiền sau 2 quý: $T = {format_vn(P1)}(1+{format_vn(r_val)}\\%)^{{2}} \\approx {format_vn(T_6th_val)}$ triệu đồng."
        elif content == d3:
            note = f"\\textbf{{Đúng}}. Gốc mới: ${format_vn(T_6th_val)} + {format_vn(P2)} = {format_vn(T_6th_val + float(P2))}$. Sau 2 quý nữa: $T' \\approx {format_vn(T_1nam_val)}$ triệu đồng."
        elif content == d4:
            note = f"\\textbf{{Đúng}}. Sau 2 năm (thêm 6 quý gửi thêm): $T'' = {format_vn(T_6th_val + float(P2))}(1+{format_vn(r_val)}\\%)^{{6}} \\approx {format_vn(T_2nam_val)}$ triệu đồng."
        else:
            note = r"\textbf{Sai}. Kết quả tính toán không khớp với các bước áp dụng công thức lãi kép kỳ hạn quý."
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    de_bai = (f"Anh Nam gửi ${format_vn(P1)}$ triệu đồng vào ngân hàng với lãi suất ${format_vn(r_val)}\\%$/quý. "
              f"Biết rằng sau mỗi quý, số tiền lãi sẽ được nhập vào vốn ban đầu. Sau đúng $6$ tháng anh Nam gửi thêm ${format_vn(P2)}$ triệu đồng với kì hạn và lãi suất như trước đó (kết quả làm tròn đến hàng phần mười).")
    
    thanhde = rf"""\begin{{ex}}
    {de_bai} \textbf{{Xét tính đúng sai của các mệnh đề sau:}}
    {choice_tf}
    \loigiai{{
        \begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \end{{itemchoice}}
    }}
\end{{ex}}"""

    return thanhde
