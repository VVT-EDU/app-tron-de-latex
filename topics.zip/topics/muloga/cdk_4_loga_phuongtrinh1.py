import random
from sympy import simplify, symbols, log, Eq, expand, solve, latex, solveset, Interval, oo, Intersection, S
from decimal import Decimal, ROUND_HALF_UP

# Hàm làm tròn theo phương thức ROUND_HALF_UP
def round_half_up(number, decimals=0):
    if decimals == 0:
        factor = Decimal('1')
    else:
        factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

def generate():
    # 1. THIẾT LẬP BIẾN VÀ THÔNG SỐ
    x = symbols('x')
    h_value = random.randint(1, 5) # Chọn ngẫu nhiên h_value (tham số a)
    a = h_value
    
    # x1 = (x + a)(x - 2) + 1
    # x2 = 2(x + a)(x - 2) + 1
    expr_base = (x + a) * (x - 2)
    x1 = expand(expr_base + 1)
    x2 = expand(2 * expr_base + 1)
    
    # 2. ĐIỀU KIỆN XÁC ĐỊNH
    dk1 = solveset(x1 > 0, x, domain=S.Reals)
    dk2 = solveset(x2 > 0, x, domain=S.Reals)
    dk_tong_hop = Intersection(dk1, dk2)
    
    # 3. THIẾT LẬP PHƯƠNG TRÌNH
    # bt1 = log(x1), bt2 = log(x2)
    pt = Eq(log(x1), log(x2))
    
    # Phương trình hệ quả: x1 = x2
    pt_he_qua = Eq(x1, x2)
    
    # Chuyển vế: x1 - x2 = 0
    bieu_thuc_rut_gon = simplify(x1 - x2)
    pt_rut_gon = Eq(bieu_thuc_rut_gon, 0)
    
    # 4. GIẢI VÀ KIỂM TRA ĐIỀU KIỆN
    nghiem_tho = solve(pt_rut_gon, x)
    nghiem_set = set(nghiem_tho)
    
    # Lọc nghiệm thuộc tập xác định
    tap_nghiem_thuc = Intersection(dk_tong_hop, nghiem_set)
    danh_sach_nghiem = list(tap_nghiem_thuc)
    tong_nghiem = sum(danh_sach_nghiem)
    
    # Kết quả làm tròn
    val_tong = float(tong_nghiem.evalf())
    res_final = int(round_half_up(val_tong, 0))
    
    # 5. TRÌNH BÀY LỜI GIẢI
    y_list = [
        f"Phương trình đã cho: ${latex(pt)}$",
        f"Điều kiện xác định: $x \\in {latex(dk_tong_hop)}$",
        f"Phương trình tương đương: ${latex(pt_he_qua)}$",
        f"$\\Leftrightarrow {latex(pt_rut_gon)}$",
        f"$\\Leftrightarrow x \\in {latex(nghiem_set)}$",
        f"Đối chiếu điều kiện, ta có tập nghiệm $S = {latex(tap_nghiem_thuc)}$",
        f"Vậy tổng các nghiệm là ${latex(tong_nghiem)}$."
    ]
    
    loigiai_latex = " \\\\\n".join(y_list)

    # 6. XUẤT KẾT QUẢ THEO ĐỊNH DẠNG EX
    content = rf"""\begin{{ex}}
Cho phương trình ${latex(pt)}$. Tính tổng các nghiệm của phương trình đã cho.
\shortans{{ ${res_final}$ }}
\loigiai{{
{loigiai_latex}
}}
\end{{ex}}"""
    return content

# Thực thi
if __name__ == "__main__":
    print(generate())
