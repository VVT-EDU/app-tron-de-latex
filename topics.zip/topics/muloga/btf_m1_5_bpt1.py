import random
import math

# =============================================================================
# THƯ VIỆN HÀM HỖ TRỢ
# =============================================================================

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai theo định dạng \choiceTF."""
    if len(dung) < 2 or len(sai) < 2:
        return ["Lỗi danh sách", []]
    indices_dung = random.sample(range(len(dung)), 2)
    indices_sai = random.sample(range(len(sai)), 2)
    selected_dung = [dung[i] for i in indices_dung]
    selected_sai = [sai[i] for i in indices_sai]
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return [choice_str, choices]

# =============================================================================
# HÀM GENERATE (So sánh hàm Mũ - Qt6 Compatible)
# =============================================================================

def generate():
    # 1. KHỞI TẠO THÔNG SỐ NGẪU NHIÊN
    # f(x) = a^(x^2 - bx + c)
    # g(x) = (1/a)^(x - d) = a^(-x + d)
    # f(x) = g(x) <=> x^2 - bx + c = -x + d <=> x^2 - (b-1)x + (c-d) = 0
    
    a = random.choice([2, 3])
    b = random.randint(3, 5)
    # Chọn c, d sao cho phương trình có nghiệm thực (Delta > 0)
    # Ở đây ta chọn nghiệm trước để số đẹp: x1, x2
    x1 = random.randint(-2, 1)
    x2 = random.randint(2, 4)
    
    # x^2 - (x1+x2)x + x1*x2 = 0
    # So sánh với x^2 - (b-1)x + (c-d) = 0
    # => b-1 = x1+x2 => b = x1+x2+1
    # => c-d = x1*x2 => chọn c ngẫu nhiên rồi tính d
    b_val = x1 + x2 + 1
    c_val = random.randint(4, 10)
    d_val = c_val - (x1 * x2)
    
    # 2. DANH SÁCH KHẲNG ĐỊNH (Sử dụng \text{} lồng trong $ $)
    d1 = f"$\\text{{Hàm số }} g(x) = \\left(\\dfrac{{1}}{{{a}}}\\right)^{{x-{d_val}}} \\text{{ nghịch biến trên }} \\mathbb{{R}}$"
    d2 = f"$\\text{{Nghiệm của phương trình }} g(x)=1 \\text{{ là }} x={d_val}$"
    d3 = f"$\\text{{Tập nghiệm của phương trình }} f(x)=g(x) \\text{{ là }} S=\\{{{x1}; {x2}\\}}$"
    d4 = f"$\\text{{Bất phương trình }} f(x) \\leq g(x) \\text{{ có tập nghiệm là đoạn }} [{x1}; {x2}]$"

    s1 = f"$\\text{{Hàm số }} f(x) \\text{{ luôn đồng biến trên }} \\mathbb{{R}}$" # Sai vì là hàm bậc 2 trên mũ
    s2 = f"$\\text{{Nghiệm của phương trình }} g(x)=1 \\text{{ là một số âm }}$" # d_val luôn dương
    s3 = f"$\\text{{Phương trình }} f(x)=g(x) \\text{{ vô nghiệm }}$"
    s4 = f"$\\text{{Tập nghiệm của bất phương trình }} f(x) \\leq g(x) \\text{{ là }} (-\\infty; {x1}] \\cup [{x2}; +\\infty)$"

    dung_list = [d1, d2, d3, d4]
    sai_list = [s1, s2, s3, s4]

    choice_tf, selected_items = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # 3. XÂY DỰNG LỜI GIẢI CHI TIẾT
    loigiai_items = []
    for item in selected_items:
        content = item.replace(r'\True ', '')
        if content == d1:
            note = f"\\textbf{{Đúng}}. Do cơ số $0 < \\frac{{1}}{{{a}}} < 1$ nên $g(x)$ nghịch biến trên $\\mathbb{{R}}$."
        elif content == d2:
            note = f"\\textbf{{Đúng}}. $g(x)=1 \\Leftrightarrow x-{d_val}=0 \\Leftrightarrow x={d_val}$."
        elif content == d3:
            note = f"\\textbf{{Đúng}}. $f(x)=g(x) \\Leftrightarrow {a}^{{x^2-{b_val}x+{c_val}}} = {a}^{{-x+{d_val}}} \\Leftrightarrow x^2-({b_val}-1)x+({c_val}-{d_val})=0$. Giải ra $x={x1}, x={x2}$."
        elif content == d4:
            note = f"\\textbf{{Đúng}}. Vì cơ số ${a}>1$, $f(x) \\le g(x) \\Leftrightarrow x^2-({b_val}-1)x+({c_val}-{d_val}) \\le 0 \\Leftrightarrow x \\in [{x1}; {x2}]$."
        elif content == s1:
            note = f"\\textbf{{Sai}}. Số mũ là hàm bậc hai, nên hàm số có khoảng đồng biến và nghịch biến riêng."
        elif content == s4:
            note = f"\\textbf{{Sai}}. Do hệ số $a=1>0$ của tam thức bậc hai, tập nghiệm phải là đoạn giữa hai nghiệm."
        else:
            note = r"\textbf{Kiểm tra}. Đưa về cùng cơ số để giải phương trình và bất phương trình mũ."
        loigiai_items.append(f"\\itemch {note}")

    # 4. RÁP MÃ LATEX
    thanhde = f"""\\begin{{ex}}
    Cho hai hàm số $f(x)={a}^{{x^2-{b_val}x+{c_val}}}$ và $g(x)=\\left(\\dfrac{{1}}{{{a}}}\\right)^{{x-{d_val}}}$. \\textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \\loigiai{{
        \\begin{{itemchoice}}
            {loigiai_items[0]}
            {loigiai_items[1]}
            {loigiai_items[2]}
            {loigiai_items[3]}
        \\end{{itemchoice}}
    }}
\\end{{ex}}"""

    return thanhde.replace(".", ",")
