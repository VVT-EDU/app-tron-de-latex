import random
from fractions import Fraction

def to_latex(frac):
    """Hiển thị phân số LaTeX tối giản."""
    if frac.denominator == 1:
        return str(frac.numerator)
    num = abs(frac.numerator)
    sign = "-" if frac.numerator < 0 else ""
    return rf"{sign}\dfrac{{{num}}}{{{frac.denominator}}}"

def generate():
    # 1. Tham số toán học
    # Cho log_a(b) = x và log_a(c) = y. 
    # Tính P = log_{a^n * b^m} (b^p / c^q)
    a, b, c = 'a', 'b', 'c'
    n = random.randint(2, 4)
    m = random.randint(3,7)
    p = random.randint(2,6)
    q = random.randint(3,8)
    
    # Công thức: P = log_{a^n * b^m} (b^p * c^{-q})
    # Đổi sang cơ số a: P = [log_a(b^p * c^{-q})] / [log_a(a^n * b^m)]
    # P = (p*x - q*y) / (n + m*x)
    
    ten_bt = random.choice(['P', 'Q', 'A', 'M', 'T'])
    
    # 2. Tạo các phương án trắc nghiệm (Dạng phân thức chứa x, y)
    correct_ans = rf"\dfrac{{{p}x - {q}y}}{{{n} + {m}x}}"
    
    distractors = set()
    # Nhiễu 1: Sai quy tắc lũy thừa cơ số (không đưa xuống mẫu)
    distractors.add(rf"({n} + {m}x)({p}x - {q}y)")
    # Nhiễu 2: Nhầm dấu tử thức (phép chia thành nhân)
    distractors.add(rf"\dfrac{{{p}x + {q}y}}{{{n} + {m}x}}")
    # Nhiễu 3: Đảo ngược tử và mẫu
    distractors.add(rf"\dfrac{{{n} + {m}x}}{{{p}x - {q}y}}")

    options = [rf"\True ${correct_ans}$"]
    for d in list(distractors)[:3]:
        options.append(rf"$ {d}$")
    random.shuffle(options)

    # 3. Ráp LaTeX
    log_target = rf"\log_{{{a}^{{{n}}} {b}^{{{m}}}}} \left( \dfrac{{{b}^{{{p}}}}}{{{c}^{{{q}}}}} \right)"

    return rf"""\begin{{ex}}
    Cho các số thực dương $a, b, c$ khác $1$, thỏa mãn $\log_{a} b = x$ và $\log_{a} c = y$.
    Tính theo $x$ và $y$, biểu thức $ {log_target}$ bằng
    \choice
    {{{options[0]}}}
    {{{options[1]}}}
    {{{options[2]}}}
    {{{options[3]}}}
    \loigiai{{
        Sử dụng công thức đổi cơ số sang cơ số $a$, ta có:
        \begin{{itemize}}
            \item ${ten_bt} = \dfrac{{\log_{a} \left( \dfrac{{{b}^{{{p}}}}}{{{c}^{{{q}}}}} \right)}}{{\log_{a} ({a}^{{{n}}} {b}^{{{m}}})}}$.
            \item Tử thức: $\log_{a} {b}^{{{p}}} - \log_{a} {c}^{{{q}}} = {p}\log_{a} b - {q}\log_{a} c = {p}x - {q}y$.
            \item Mẫu thức: $\log_{a} {a}^{{{n}}} + \log_{a} {b}^{{{m}}} = {n} + {m}\log_{a} b = {n} + {m}x$.
            \item Vậy ${ten_bt} = {correct_ans}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

print(generate())
