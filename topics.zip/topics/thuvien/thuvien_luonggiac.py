from sympy import symbols, latex, Interval, expand, collect , S, Rational, diff, Point
import os, re, random 
import os
from sympy import symbols, sqrt, simplify, latex, factor, Eq, solve, solveset, apart, pi
from sympy import sin, cos, pi, exp, E, integrate
from sympy import symbols, sin, cos, tan, cot
from sympy import symbols, sqrt, latex, expand,Eq, trigsimp, expand_trig
x, y, z, t = symbols('x y z t')
# Đường dẫn tới thư mục
from sympy import symbols, solveset, sin, S, Intersection, Interval, pi
from decimal import Decimal, ROUND_HALF_UP

# Function to round numbers using ROUND_HALF_UP
def round_half_up(number, decimals=0):
    factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

output_directory = 'D:/py11_2025/data'
script_name = os.path.splitext(os.path.basename(__file__))[0]
def congthucsinacongb(a,b):
    return f"\\sin{{({latex(a+b)})}}=\\sin{{{latex(a)}}}\\cos{{{latex(b)}}}+\\sin{{{latex(b)}}}\\cos{{{latex(a)}}}"
def congthucsinatrub(a,b):
    return f"\\sin{{({latex(a-b)})}}=\\sin{{{latex(a)}}}\\cos{{{latex(b)}}}-\\sin{{{latex(b)}}}\\cos{{{latex(a)}}}"
def congthuccosacongb(a,b):
    return f"\\cos{{({latex(a+b)})}}=\\cos{{{latex(a)}}}\\cos{{{latex(b)}}}-\\sin{{{latex(a)}}}\\sin{{{latex(b)}}}"
def congthuccosatrub(a,b):
    return f"\\cos{{({latex(a-b)})}}=\\cos{{{latex(a)}}}\\cos{{{latex(b)}}}+\\sin{{{latex(a)}}}\\sin{{{latex(b)}}}"
def sincongsin_nhaphaibien(x,y):
    bt1=sin(x)+sin(y)
    bt2=2*sin((x+y)/2)*cos((x-y)/2)
    return [bt1, bt2]
def coscongcos_nhaphaibien(x,y):
    bt1=cos(x)+cos(y)
    bt2=2*cos((x+y)/2)*cos((x-y)/2)
    return [bt1, bt2]
def atn_don_txdmausincos_nhapham(ham):
    to=random.choice([3,4,5,6,7,8,9,10])
    cung=x
    ds=[pi/3,pi/4,pi/6, pi/2,pi]
    cung0=random.choice(ds)
    pt=Eq(ham(cung), ham(cung0))
    nghiem=solveset(pt, x, domain=S.Reals)
    R=S.Reals
    d1=R-nghiem
    ptghi=Eq(to/(ham(cung)-ham(cung0)),0)
    ##caudan=f"\\text{{Với }} n \\in \\mathbb{{Z}}"
    caudan =f"\\text{{ Phương trình }} {latex(ptghi)} \\text{{ có tập xác định là  }}"
    dung=[latex(d1)]
    ds.remove(cung0)
    c1,c2,c3=random.sample(ds,3)
    pt1=Eq(ham(cung), ham(c1))
    pt2=Eq(ham(cung), ham(c2))
    pt3=Eq(ham(cung), ham(c3))
    nghiem1=solveset(pt1, x, domain=S.Reals)
    nghiem2=solveset(pt2, x, domain=S.Reals)
    nghiem3=solveset(pt3, x, domain=S.Reals)
    s1,s2,s3=R-nghiem1, R-nghiem2, R- nghiem3

    sai=[latex(s1),latex(s2),latex(s3)]
    return [caudan, dung, sai]
#to=atn_don_txdmausincos_nhapham(sin)
#print(to)
def atn_don_nghiemphuongtrinhsincos_nhapham(ham):
    to=random.choice([3,4,5,6,7,8,9,10])
    cung=x+pi/to
    cung0=random.choice([pi/3, pi/4,pi/6, 2*pi/3])
    pt=Eq(ham(cung), ham(cung0))
    nghiem=solveset(pt, x, domain=S.Reals)
    nghiemghi = [s.lamda.expr if hasattr(s, 'lamda') else s for s in nghiem.args]
    x1=nghiemghi[0]
    x2=nghiemghi[1]
    d1,d2=x1,x2
    caudan=f"\\text{{Với }} n \\in \\mathbb{{Z}}"
    caudan +=f"\\text{{. Phương trình }} {latex(pt)} \\text{{ có nghiệm x là  }}"
    dung=[latex(d1), latex(d2)]
    s1,s2,s3,s4=random.sample([pi/3, pi/4,pi/6,pi/7,pi/8],4)
    d1s=(d1+s1)
    d2s=(d1+s2)
    d3s=(d1+s3)
    d4s=(d1+s4)
    sai=[latex(d1s),latex(d2s),latex(d3s),latex(d4s)]
    return [caudan, dung, sai]
#to=atn_don_nghiemphuongtrinh_nhapham(sin)
#print(to)
def atn_don_nghiemphuongtrinhthuoc_nhapham(ham):
    cung=random.choice([x+pi/3, x+pi/4, x+pi/5, x+pi/6, x+pi/7])
    cung0=random.choice([pi/3, pi/4,pi/6])
    pt=Eq(ham(cung), ham(cung0))
    nghiem=solveset(pt, x, domain=S.Reals)
    nd = Intersection(nghiem, Interval.open(0, 50))
    nd=list(nd)
    d1=Interval.open(nd[0], nd[2])
    d2=Interval.open(nd[1], nd[3])
    d3=Interval.open(nd[2], nd[4])
    d4=Interval.open(nd[3], nd[5])
    d5=Interval.open(nd[4], nd[6])
    caudan=f"\\text{{Phương trình }} {latex(pt)} \\text{{ có nghiệm thuộc }}"
    dung=[latex(d1),latex(d2),latex(d3),latex(d4),latex(d5)]
    d1s=Interval.open(nd[0], nd[1])
    d2s=Interval.open(nd[1], nd[2])
    d3s=Interval.open(nd[2], nd[3])
    d4s=Interval.open(nd[3], nd[4])
    d5s=Interval.open(nd[4], nd[5])
    sai=[latex(d1s),latex(d2s),latex(d3s),latex(d4s),latex(d5s)]
    return [caudan, dung, sai]
#to=atn_don_nghiemphuongtrinhthuoc_nhapham(tan)
#print(to)

def atn_cosin_tinhbieuthuc_khongnhap():
    t1,t2,t3=random.sample([3,4,5,6,7,8,9],3)
    s1,s2,s3,s4,s5=random.sample([-1,-2,1,2,3],5)
    giatri=Rational(1,t1)
    bt=cos(x)
    bt00=bt.rewrite(sin)
    bai=f"Biết ${latex(bt00)}={latex(giatri)}$"
    b11=(sin(x))**2+t2
    b1=expand_trig(b11)
    b1 = b1.subs(sin(x)**2, 1-cos(x)**2)
    b1=b1.subs(bt,giatri)
    bt1=f"{latex(b11)}={latex(b1)}"
    bt1s=f"{latex(b11)}={latex(b1+s1)}"
    b22=(sin(x)+t1/sin(x))**2
    b2 =  (expand(b22))
    b2 = b2.subs(sin(x)**2, 1-cos(x)**2)
    b2=b2.subs(bt,giatri)
    bt2=f"{latex(b22)}={latex(b2)}"
    bt2s=f"{latex(b22)}={latex(b2+s2)}"
    b33=(t1/sin(x))**2+t3
    b3 =  (expand(b33))
    b3 = b3.subs(sin(x)**2, 1-cos(x)**2)
    b3=b3.subs(bt,giatri)
    bt3=f"{latex(b33)}={latex(b3)}"
    bt3s=f"{latex(b33)}={latex(b3+s3)}"
    b44=cos(2*x)+t1
    b4 = (expand_trig(b44))
    b4 =b4.subs(sin(x)**2, 1-cos(x)**2)
    b4=b4.subs(bt,giatri)
    bt4=f"{latex(b44)}={latex(b4)}"
    bt4s=f"{latex(b44)}={latex(b4+s4)}"
    b55=(sin(x)/cos(x))**2+t3
    b5 =  (expand(b55))
    b5 = b5.subs(sin(x)**2, 1-cos(x)**2)
    b5=b5.subs(bt,giatri)
    bt5=f"{latex(b55)}={latex(b5)}"
    bt5s=f"{latex(b55)}={latex(b5+s5)}"
    dung=[bt1, bt2, bt3,bt4, bt5]
    sai=[bt1s,bt2s,bt3s,bt4s,bt5s]
    return [dung, sai, bai]
#to=atn_cosin_tinhbieuthuc_khongnhap()
#print(to)
def atn_cocos_tinhbieuthuc_khongnhap():
    t1,t2,t3=random.sample([3,4,5,6,7,8,9],3)
    s1,s2,s3,s4,s5=random.sample([-1,-2,1,2,3],5)
    giatri=Rational(1,t1)
    bt=cos(x)
    bai=f"Biết ${latex(bt)}={latex(giatri)}$"
    b11=(sin(x))**2+t2
    b1=expand_trig(b11)
    b1 = b1.subs(sin(x)**2, 1-cos(x)**2)
    b1=b1.subs(bt,giatri)
    bt1=f"{latex(b11)}={latex(b1)}"
    bt1s=f"{latex(b11)}={latex(b1+s1)}"
    b22=(sin(x)+t1/sin(x))**2
    b2 =  (expand(b22))
    b2 = b2.subs(sin(x)**2, 1-cos(x)**2)
    b2=b2.subs(bt,giatri)
    bt2=f"{latex(b22)}={latex(b2)}"
    bt2s=f"{latex(b22)}={latex(b2+s2)}"
    b33=(t1/sin(x))**2+t3
    b3 =  (expand(b33))
    b3 = b3.subs(sin(x)**2, 1-cos(x)**2)
    b3=b3.subs(bt,giatri)
    bt3=f"{latex(b33)}={latex(b3)}"
    bt3s=f"{latex(b33)}={latex(b3+s3)}"
    b44=cos(2*x)+t1
    b4 = (expand_trig(b44))
    b4 =b4.subs(sin(x)**2, 1-cos(x)**2)
    b4=b4.subs(bt,giatri)
    bt4=f"{latex(b44)}={latex(b4)}"
    bt4s=f"{latex(b44)}={latex(b4+s4)}"
    b55=(sin(x)/cos(x))**2+t3
    b5 =  (expand(b55))
    b5 = b5.subs(sin(x)**2, 1-cos(x)**2)
    b5=b5.subs(bt,giatri)
    bt5=f"{latex(b55)}={latex(b5)}"
    bt5s=f"{latex(b55)}={latex(b5+s5)}"
    dung=[bt1, bt2, bt3,bt4, bt5]
    sai=[bt1s,bt2s,bt3s,bt4s,bt5s]
    return [dung, sai, bai]

#to=atn_cocos_tinhbieuthuc_khongnhap()
#print(to)
    
    
def chuki_khongnhap():
    ds = [x,x+pi/10, 2*x, 3*x, 4*x+pi/5, 5*x+pi/11]
    t=random.choice([1])
    t=Rational(t)
    t1,t2,t3,t4 = random.sample(ds, 4)
    t1,t2,t3,t4 = t1*t, t2*t, t3*t, t4*t
    pt1=Eq(t1,2*pi)
    pt2=Eq(t2,2*pi)
    pt3=Eq(t3,2*pi)
    pt4=Eq(t4,2*pi)
    ng1=solve(pt1)[0]
    ng2=solve(pt2)[0]
    ng3=solve(pt3)[0]
    ng4=solve(pt4)[0]
    pt11=Eq(t1,pi)
    pt22=Eq(t2,pi)
    pt33=Eq(t3,pi)
    pt44=Eq(t4,pi)
    ng11=solve(pt11)[0]
    ng22=solve(pt22)[0]
    ng33=solve(pt33)[0]
    ng44=solve(pt44)[0]
    ham1=random.choice([sin, cos])
    ham2=random.choice([tan, cot])
    bt1=f"y={latex(ham1(t1))} \\text{{ có chu kì là }} T={latex(ng1)}"
    bt2=f"y={latex(ham1(t2))} \\text{{ có chu kì là }} T={latex(ng2)}"
    bt3=f"y={latex(ham1(t3))} \\text{{ có chu kì là }} T={latex(ng3)}"
    bt4=f"y={latex(ham1(t4))} \\text{{ có chu kì là }} T={latex(ng4)}"
    
    bt5=f"y={latex(ham2(t1))} \\text{{ có chu kì là }} T={latex(ng11)}"
    bt6=f"y={latex(ham2(t2))} \\text{{ có chu kì là }} T={latex(ng22)}"
    bt7=f"y={latex(ham2(t3))} \\text{{ có chu kì là }} T={latex(ng33)}"
    bt8=f"y={latex(ham2(t4))} \\text{{ có chu kì là }} T={latex(ng44)}"
    dung = [bt1, bt2, bt3, bt4, bt5, bt6, bt7, bt8]

    sa=random.choice([pi/4, pi/3,pi/2])
 
    bt1=f"y={latex(ham1(t1))} \\text{{ có chu kì là }} T={latex(ng1+sa)}"
    bt2=f"y={latex(ham1(t2))} \\text{{ có chu kì là }} T={latex(ng2+sa)}"
    bt3=f"y={latex(ham1(t3))} \\text{{ có chu kì là }} T={latex(ng3+sa)}"
    bt4=f"y={latex(ham1(t4))} \\text{{ có chu kì là }} T={latex(ng4+sa)}"
    
    bt5=f"y={latex(ham2(t1))} \\text{{ có chu kì là }} T={latex(ng11+sa)}"
    bt6=f"y={latex(ham2(t2))} \\text{{ có chu kì là }} T={latex(ng22+sa)}"
    bt7=f"y={latex(ham2(t3))} \\text{{ có chu kì là }} T={latex(ng33+sa)}"
    bt8=f"y={latex(ham2(t4))} \\text{{ có chu kì là }} T={latex(ng44+sa)}"
    sai = [bt1, bt2, bt3, bt4, bt5, bt6, bt7, bt8]

    return [dung, sai]
 

def radianvadodaicung_khongnhap():
    R = random.choice([2, 3, 4, 5, 6])
    bai = f"Đường tròn tâm $O(0;0)$ có bán kính $R={latex(R)}$"
    dst = [30, 45, 60, 90, 120, 135, 150, 180, 210, 360, 420]
    t01, t02, t03 = random.sample(dst, 3)
    t01rad = simplify(Rational(t01, 180) * pi)
    t02rad = simplify(Rational(t02, 180) * pi)
    t03rad = simplify(Rational(t03, 180) * pi)

  

    ds = [pi/6, pi/4, pi/3, pi/2, 2*pi/3, 3*pi/4, 2*pi]
    t1, t2, t3, t4 = random.sample(ds, 4)

    bt01 = f"a={latex(t01)}^\\circ = {latex(t01rad)} \\text{{ rad }}"
    bt02 = f"a={latex(t02)}^\\circ = {latex(t02rad)} \\text{{ rad }}"
    bt03 = f"a={latex(t03)}^\\circ = {latex(t03rad)} \\text{{ rad }}"
    bt2 = f"\\text{{Cung có số đo }} {latex(t1)} \\text{{ có độ dài }} l={latex(R*t1)}"
    bt3 = f"\\text{{Cung có số đo }} {latex(t2)} \\text{{ có độ dài }} l={latex(R*t2)}"
    bt4 = f"\\text{{Cung có số đo }} {latex(t3)} \\text{{ có độ dài }} l={latex(R*t3)}"
    bt5 = f"\\text{{Cung có số đo }} {latex(t4)} \\text{{ có độ dài }} l={latex(R*t4)}"

    dung = [bt01, bt02, bt03, bt2, bt3, bt4, bt5]

    sai_shift = random.choice(ds)
    bt01 = f"a={latex(t01)}^\\circ = {latex(t01rad + sai_shift)} \\text{{ rad }}"
    bt02 = f"a={latex(t02)}^\\circ = {latex(t02rad + sai_shift)} \\text{{ rad }}"
    bt03 = f"a={latex(t03)}^\\circ = {latex(t03rad + sai_shift)} \\text{{ rad }}"
    bt2 = f"\\text{{Cung có số đo }} {latex(t1)} \\text{{ có độ dài }} l={latex(R*t1 + sai_shift)}"
    bt3 = f"\\text{{Cung có số đo }} {latex(t2)} \\text{{ có độ dài }} l={latex(R*t2 + sai_shift)}"
    bt4 = f"\\text{{Cung có số đo }} {latex(t3)} \\text{{ có độ dài }} l={latex(R*t3 + sai_shift)}"
    bt5 = f"\\text{{Cung có số đo }} {latex(t4)} \\text{{ có độ dài }} l={latex(R*t4 + sai_shift)}"

    sai = [bt01, bt02, bt03, bt2, bt3, bt4, bt5]

    return [dung, sai, bai]
def hamchanhamle_khongnhap():
    t=random.choice([x,3*x, 5*x])
    bt1=f"y={latex(sin(t))} \\text{{ là hàm số lẻ }}"
    bt2=f"y={latex(t+sin(t))}  \\text{{ là hàm số lẻ}}"
    bt3=f"y={latex(sin(t)**3)}  \\text{{ là hàm số lẻ}}"
    bt4=f"y={latex(cos(t))}  \\text{{ là hàm số chẵn}}"
    bt5=f"y={latex(t**2+cos(t))}  \\text{{ là hàm số chẵn}}"
    bt6=f"y={latex(cos(t)**2)}  \\text{{ là hàm số chẵn}}"
    bt7=f"y={latex(sin(t)**2+cos(x))}  \\text{{ là hàm số chẵn}}"
    dung=[bt1,bt2,bt3,bt4,bt5,bt6,bt7]
    so=random.choice([1,2,3])
    bt1=f"y={latex(sin(t)+so)} \\text{{  là hàm số lẻ}}"
    bt2=f"y={latex(t+sin(t)+so)} \\text{{  là hàm số lẻ}}"
    bt3=f"y={latex(sin(t)**3+so)}  \\text{{ là hàm số lẻ}}"
    bt4=f"y={latex(cos(t)+t)} \\text{{ là hàm số chẵn}}"
    bt5=f"y={latex(t**2+cos(t)+t)}  \\text{{ là hàm số chẵn}}"
    bt6=f"y={latex(cos(t)**2+t)}  \\text{{ là hàm số chẵn}}"
    bt7=f"y={latex(sin(t)**2+cos(x)+t)}  \\text{{ là hàm số chẵn}}"
    
    sai=[bt1,bt2,bt3,bt4,bt5,bt6,bt7]
    return [dung, sai]
def luonggiac_acongb_nhapbienvaphanpi(a,b):
    bt0=f"\\sin{{\\left( {latex(a+b)} \\right) }}"
    bt1=expand_trig(sin(a+b))
    bt1=bt0+ f"={latex(bt1)}"
    bt0=f"\\cos{{\\left( {latex(a+b)} \\right) }}"
    bt2=expand_trig(cos(a+b))
    bt2=bt0+ f"={latex(bt2)}"
    bt0=f"\\sin{{\\left( {latex(a-b)} \\right) }}"
    bt3=expand_trig(sin(a-b))
    bt3=bt0+ f"={latex(bt3)}"
    bt0=f"\\cos{{\\left( {latex(a-b)} \\right) }}"
    bt4=expand_trig(cos(a-b))
    bt4=bt0+ f"={latex(bt4)}"
    bt0=f"\\sin{{\\left( {latex(a+a)} \\right) }}"
    bt5=expand_trig(sin(a+a))
    bt5=bt0+ f"={latex(bt5)}"
    bt0=f"\\cos{{\\left( {latex(a+a)} \\right) }}"
    bt6=expand_trig(cos(a+a))
    bt6=bt0+ f"={latex(bt6)}"
    dung= [bt1, bt2, bt3, bt4, bt5, bt6]
 
    bt0=f"\\sin{{\\left( {latex(a+b)} \\right) }}"
    bt1=expand_trig(cos(a+b))
    bt1=bt0+ f"={latex(bt1)}"
    bt0=f"\\cos{{\\left( {latex(a+b)} \\right) }}"
    bt2=expand_trig(sin(a+b))
    bt2=bt0+ f"={latex(bt2)}"
    bt0=f"\\sin{{\\left( {latex(a-b)} \\right) }}"
    bt3=expand_trig(cos(a-b))
    bt3=bt0+ f"={latex(bt3)}"
    bt0=f"\\cos{{\\left( {latex(a-b)} \\right) }}"
    bt4=expand_trig(sin(a-b))
    bt4=bt0+ f"={latex(bt4)}"
    bt0=f"\\sin{{\\left( {latex(a+a)} \\right) }}"
    bt5=expand_trig(cos(a+a))
    bt5=bt0+ f"={latex(bt5)}"
    bt0=f"\\cos{{\\left( {latex(a+a)} \\right) }}"
    bt6=expand_trig(sin(a+a))
    bt6=bt0+ f"={latex(bt6)}"
    sai= [bt1, bt2, bt3, bt4, bt5, bt6]
    return [dung, sai]
#to=luonggiac_acongb_nhapbienvaphanpisai(x, pi/4)
#print(to)
def cdk_tinhtheotichsincos_nhapbienvaso(x,a):
    x=a*x
    t=sin(x)*cos(x)
    b=random.choice([3,4,5,6,7,8,9])
    t0=Rational(1,b)
    bt=(sin(x)+cos(x))**2
    bt1=(sin(x)-cos(x))**2
    y01=f"$T_1={latex(bt)}$"
    y04=f"$T_2={latex(bt)}$"
    bai=f"Có ${latex(t)}={latex(t0)}$ và $T={latex(bt+b*bt1)}$. Tính $|T|$"
    bt=expand(bt)
    y1=f"$T_1={latex(bt)}$  " 
    bt=bt.subs(t, t0)
    y2=f"$T_1={latex(bt)}$"
    bt=trigsimp(bt)
    y3=f"$T_1={latex(bt)}$"

    bt1=expand(bt1)
    y4=f"$T_2={latex(bt1)}$   "
    bt1=bt1.subs(t, t0)
    y5=f"$T_2={latex(bt1)}$"
    bt1=trigsimp(bt1)
    y6=f"$T_2={latex(bt1)}$"
    y7=f"$T=T_1+{b}T_2={latex(bt+bt1*b)}$"
    kq=bt+bt1*b
    return [bai, y01,y1, y2, y3, y04, y4, y5, y6, y7, kq]
#to=cdk_tinhtheocos_nhapbienvaso(x,3)
#print(to)
def cdk_tinhtheocos2a_nhapbienvaso(x,a):
    t=expand_trig(cos(2*x))
    k=random.choice([2,3])
    t0=Rational(1,k)
    tu1=expand((t+a)**k)
    y01=f"${latex(t)}={latex(t0)}$"
    y1=f"$T={latex(tu1)}$"
    tu2=factor(tu1)
    y2=f"$T={latex(tu2)}$"
    tu3=tu2.subs(t,t0)
    y3=f"$T={latex(tu3)}$"
    
    m1, m2=sin(x)**2+cos(x)**2, sin(x)**2-cos(x)**2
    m1m2=m1*m2
    m=sin(x)**4-cos(x)**4
    y4=f"$M={latex(m)}={latex(m1m2)}$"
    m1m2rg=trigsimp(m1m2)
    y5=f"$M={latex(m1m2rg)}$"
    m3=m1m2rg.subs(cos(2*x),t0)
    y6=f"$M={latex(m3)}$"
    ps=tu3/m3
    y7=f"$P={latex(ps)}$"
    kq = ps.subs(x,pi/3)

    bai=f" Có ${latex(cos(2*x))}={latex(t0)}$ và $P={latex(tu1/m)}$ là biểu thức có nghĩa."
    bai +=f" Tính $|P|$ (làm tròn đến hàng đơn vị)" 
    #tu2=tu2.rewrite(cos(x)**2)
    return [bai, y01,y1,y2,y3,y4,y5,y6,y7, kq]
#to=cdk_tinhtheocos2a_nhapbienvaso(x,2)[-1]
#print(to)
def cdk_rutgontich_nhapbienvaso(x,a):
    chung=sin(x)+a
    thay=sin(x)+a*cos(x)
    k=random.choice([2,3])
    thay0=Rational(1+k**2,k)
    tu1=thay+k
    tu1=expand(tu1*chung)
    tu2=factor(tu1)
    
    y1=f"$T={latex(tu1)}={latex(tu2)}$"
    m2=(thay-k-a)*chung
    m1=expand(m2)
    y2=f"$M={latex(m1)}={latex(m2)}$"
    ps=simplify(tu2/m2)
    y3=f"$P={latex(ps)}$"
    kq=ps.subs(thay, thay0)
    kq=kq.subs(x, pi/3)
    y4=f"$P={latex(kq)}$"
    bai=f" Có ${latex(thay)}={latex(thay0)}$ và và $P={latex(tu1/m1)}$ là biểu thức có nghĩa."
    bai +=f" Tính $|P|$ (làm tròn đến hàng đơn vị)" 
    return [bai, y1,y2,y3,y4, kq]
def cdk_rutgontongthanhtich_nhapbienvaso(x,a):
    b1,b2=random.choice([(x,-3*x), (3*x,-5*x),(3*x,-x)])
    a=random.choice([a, a+1, a+2])
    thay, thay0=tan(x), a
    t=sincongsin_nhaphaibien(b1,b2)
    m=coscongcos_nhaphaibien(b1,b2)
    t1, t2=t[0], t[1]
    m1, m2=m[0], m[1]
    duoi1=(1/cos(x)**2-1)*a
    duoi2=trigsimp(duoi1)
    rut1=t2/m2
    rut1=trigsimp(rut1)
    rut2=expand_trig(rut1)
    rut3=(rut2+duoi2).subs(tan(x), a)
    kq=rut3.subs(x, pi/4)
    y1=f"$T={latex(t1)}={latex(t2)}$"
    y2=f"$M={latex(m1)}={latex(m2)}$"
    y3=f"$D={latex(duoi1)}={latex(duoi2)}$"
    y4=f"$P={latex(rut1+duoi1)}$"
    y5=f"$P={latex(rut2+duoi2)}$"
    y6=f"$P={latex(rut3)}$"
    
    bai=f" Có ${latex(thay)}={latex(thay0)}$ và  $P={latex(t1/m1+duoi1)}$ là biểu thức có nghĩa."
    bai +=f" Tính $|P|$ (làm tròn đến hàng đơn vị)" 
    return [bai, y1,y2,y3,y4, y5,y6, kq]

#to=cdk_rutgontongthanhtich_nhapbienvaso(x,2)
#print(to)
def cdk_phuongtrinh_cosbangcos_nhapbiencungvasonghiemduong(a,b,n):
    pt=Eq(cos(a), cos(b))
    bai=f"Tính tổng ${latex(n)}$ nghiệm dương nhỏ nhất của phương trình ${latex(pt)}$"
    nghiem=solveset(pt, x, domain=S.Reals)
    nghiemghi = [s.lamda.expr if hasattr(s, 'lamda') else s for s in nghiem.args]
    x1=nghiemghi[0]
    x2=nghiemghi[1]
    y1=f"${latex(pt)}$"
    y2= f"$\\Leftrightarrow \\cos{{\\left({latex(a)}\\right)}}=\\cos{{\\left({latex(b)}\\right)}}$"
    y3=f"$\\Leftrightarrow x={latex(x1)}$ \\quad $x={latex(x2)}$; \\quad n \\in \\mathbb{{Z}}$"
    nghiemduong = Intersection(nghiem, Interval.open(0, 50))
    nghiemduong_5 = sorted(list(nghiemduong))[:n]
    nghiemduong5=set(nghiemduong_5)
    kqngan = sum(nghiemduong_5)
    y4=f"Ta có ${latex(n)}$ nghiệm dương là ${latex(nghiemduong5)}$"
    y5=f"Có tổng ${latex(kqngan)}$"
    return [bai, y1,y2,y3,y4, y5, kqngan]
def cdk_phuongtrinh_sinbangsin_nhapbiencungvasonghiemduong(a,b,n):
    pt=Eq(sin(a), sin(b))
    bai=f"Tính tổng ${latex(n)}$ nghiệm dương nhỏ nhất của phương trình ${latex(pt)}$"
    nghiem=solveset(pt, x, domain=S.Reals)
    nghiemghi = [s.lamda.expr if hasattr(s, 'lamda') else s for s in nghiem.args]
    x1=nghiemghi[0]
    x2=nghiemghi[1]
    y1=f"${latex(pt)}$"
    y2= f"$\\Leftrightarrow \\sin{{\\left({latex(a)}\\right)}}=\\sin{{\\left({latex(b)}\\right)}}$"
    y3=f"$\\Leftrightarrow x={latex(x1)}$ \\quad $x={latex(x2)}$; \\quad n \\in \\mathbb{{Z}}$"
    nghiemduong = Intersection(nghiem, Interval.open(0, 50))
    nghiemduong_5 = sorted(list(nghiemduong))[:n]
    nghiemduong5=set(nghiemduong_5)
    kqngan = sum(nghiemduong_5)
    y4=f"Ta có ${latex(n)}$ nghiệm dương là ${latex(nghiemduong5)}$"
    y5=f"Có tổng ${latex(kqngan)}$"
    return [bai, y1,y2,y3,y4, y5, kqngan]
def costrucos(a, b):
    return -2 * sin((a + b) / 2) * sin((a - b) / 2)

def cdk_phuongtrinh_sinbangcos_nhapsonghiem(n):
    #x, y, z, t , k, n= symbols('x y z t k n')
    bt=random.choice([pi/3, pi/2, 2*pi/3])#tranh sin=1, -1 vi bieu dien ko dep
    A=x
    B=bt+x
    bai=rf"""
        Tính tổng năm nghiệm dương nhỏ nhất của
        $\cos{{{latex(A)}}}=\sin{{\left({latex(pi/2-B)}\right)}}$
         """
    y1=    f"$\\Leftrightarrow \\cos{{\\left({latex(A)}\\right)}}=\\cos{{\\left({latex(B)}\\right)}}$"
    y2=    f"$\\Leftrightarrow \\cos{{\\left({latex(A)}\\right)}}-\\cos{{\\left({latex(B)}\\right)}}=0$"
    t1=costrucos(A,B)
    pt=Eq(t1,0)
    y3=f"$\\Leftrightarrow {latex(pt)}$"
    
    nghiem=solveset(pt)
    nghiemghi = [s.lamda.expr if hasattr(s, 'lamda') else s for s in nghiem.args]
    x1=nghiemghi[0]
    x2=nghiemghi[1]
    y4=f"$\\Leftrightarrow x={latex(x1)}$ \\quad $x={latex(x2)}$; \\quad $n \\in \\mathbb{{Z}}$"
    nghiemduong = Intersection(nghiem, Interval.open(0, 30))
    nghiemduong_5 = sorted(list(nghiemduong))[:n]
    nghiemduong5=set(nghiemduong_5)
    kqngan = sum(nghiemduong_5)
    y5=f"Ta có ${latex(n)}$ nghiệm dương là ${latex(nghiemduong5)}$"
    y6=f"Có tổng ${latex(kqngan)}$"
    kqngan=float(kqngan)
    kqngan=int(round_half_up(kqngan,0))
    return [bai, y1,y4, y5, y6, kqngan]
def cdk_phuongtrinh_tanbangtan_nhapsonghiem(n):
    #x, y, z, t , k, n= symbols('x y z t k n')
    alpha=random.choice([pi/6, pi/4,pi/3, 2*pi/3, 3*pi/4, 5*pi/6])#tranh sin=1, -1 vi bieu dien ko dep
    pt=Eq(tan(x), tan(alpha))
    nghiem=solveset(pt, x, domain=S.Reals)
    nghiemghi = [s.lamda.expr if hasattr(s, 'lamda') else s for s in nghiem.args]
    nghiemduong = Intersection(nghiem, Interval.open(0, 40))
    nghiemduong_5 = sorted(list(nghiemduong))[:n]
    nghiemduong5=set(nghiemduong_5)
    tong_5_nghiem = sum(nghiemduong_5)
   
    if hasattr(nghiem, 'lamda'):
        x1 = nghiem.lamda.expr
    else:
        x1 = nghiem


    kqngan=tong_5_nghiem
    kqngan=float(kqngan)
    kqngan=int(round_half_up(kqngan,0))

    bai=rf"""
       %% Biết $\tan{{x}}=\tan{{\alpha}} \Leftrightarrow x = \alpha + n \pi;$  \\
        Tính tổng năm nghiệm dương nhỏ nhất của ${latex(pt)}$\\
         """
    y1=    f"${latex(pt)}\\Leftrightarrow \\tan{{{latex(x)}}}=\\tan{{\\left({latex(alpha)}\\right)}}$"
    y2=    f"$\\Leftrightarrow x = {latex(x1)} $"
    y3=   f"Các nghiệm dương nhỏ nhất là ${latex(nghiemduong5)}$"
    y4=    f"Có tổng là $S={latex(tong_5_nghiem)} \\approx {latex(kqngan)}$"
    return [bai, y1,y2,y3,y4, kqngan]
 
def cdk_phuongtrinh_bachaitheocos_nhapsonghiem(n):
    
    k=random.choice([2,3,4,5,6,7,8,9])
    alpha=random.choice([pi/6, pi/4,pi/3, 7*pi/6, 5*pi/4, 4*pi/3])#tranh sin=1, -1 vi bieu dien ko dep
    alpha=alpha
    bt1=cos(x)+k
    bt2=cos(x)-cos(alpha)
    bttich=bt1*bt2
    bttichkhaitrien=expand(bttich)
    
    pttrumot=Eq(bttich,0)
    pttruhai=Eq(bttichkhaitrien,0)
    pt0=Eq(bt2,0)
    pt1=Eq(bt1,0)
    
    pt=Eq(cos(x), cos(alpha))
    nghiem=solveset(pt, x, domain=S.Reals)
    nghiemduong = Intersection(nghiem, Interval.open(0, 50))
    
    nghiemduong_5 = sorted(list(nghiemduong))[:n]
    nghiemduong5=set(nghiemduong_5)
    tong_5_nghiem = sum(nghiemduong_5)
    
    nghiemghi = [s.lamda.expr if hasattr(s, 'lamda') else s for s in nghiem.args]  
    x1=nghiemghi[0]
    x2=nghiemghi[1]
    kqngan=tong_5_nghiem
    kqngan=float(kqngan)
    kqngan=int(round_half_up(kqngan,0))
    bai=rf"""
       
        Tính tổng ${latex(n)}$ nghiệm dương nhỏ nhất của $${latex(pttruhai)}$$
         """
       
    y1 =   f"$ {latex(pttruhai)}$"
    y2=  f"$\\Leftrightarrow {latex(pttrumot)}$"
    y3=     f"$\\Leftrightarrow {latex(pt0)}; \\quad {latex(pt1)}$ (vô nghiệm) "
    y4=    f"$\\Leftrightarrow {latex(pt)}$"
    y5=    f"$\\Leftrightarrow \\cos{{{latex(x)}}}=\\cos{{\\left({latex(alpha)}\\right)}}$"
    y6=    f"$\\Leftrightarrow x={latex(x1)}; \\quad x={latex(x2)}; \\quad n \\in \\mathbb{{Z}}$"
    y7=    f"Các nghiệm dương nhỏ nhất là ${latex(nghiemduong5)}$"
    y8=    f"Có tổng là $S={latex(tong_5_nghiem)} \\approx {latex(kqngan)}$"
    return [bai, y1,y2,y3,y4,y5,y6,y7,y8, kqngan]
def cdk_phuongtrinh_bachaitheosin_nhapsonghiem(n):
    #x, y, z, t , k, n= symbols('x y z t k n')
    k=random.choice([2,3,4,5,6,7,8,9])
    alpha=random.choice([pi/6, pi/4,pi/3, 7*pi/6, 5*pi/4, 4*pi/3])#tranh sin=1, -1 vi bieu dien ko dep
    alpha=alpha
    bt1=sin(x)+k
    bt2=sin(x)-sin(alpha)
    bttich=bt1*bt2
    bttichkhaitrien=expand(bttich)
    
    pttrumot=Eq(bttich,0)
    pttruhai=Eq(bttichkhaitrien,0)
    pt0=Eq(bt2,0)
    pt1=Eq(bt1,0)
    #print(pttruba)
    pt=Eq(sin(x), sin(alpha))
    nghiem=solveset(pt, x, domain=S.Reals)
    nghiemduong = Intersection(nghiem, Interval.open(0, 50))
    songhiemduong=random.choice([3,4,5,6])
    nghiemduong_5 = sorted(list(nghiemduong))[:n]
    nghiemduong5=set(nghiemduong_5)
    tong_5_nghiem = sum(nghiemduong_5)
    #print(tong_5_nghiem)
    nghiemghi = [s.lamda.expr if hasattr(s, 'lamda') else s for s in nghiem.args]
    #print(nghiemduong)
    x1=nghiemghi[0]
    x2=nghiemghi[1]
    kqngan=tong_5_nghiem
    #print(kqngan)
    kqngan=float(kqngan)
    #print(kqngan)
    kqngan=int(round_half_up(kqngan,0))
 
    bai=rf"""
       %% Biết $\sin{{x}}=\sin{{\alpha}} \Leftrightarrow x = \alpha + 2n \pi; \quad x= \pi -\alpha +2 n \pi$. \\
        Tính tổng ${latex(n)}$ nghiệm dương nhỏ nhất của $${latex(pttruhai)}$$
         """

    y1=    f"$ {latex(pttruhai)}$"
    y2=   f"$\\Leftrightarrow {latex(pttrumot)}$"
    y3=     f"$\\Leftrightarrow {latex(pt0)}; \\quad {latex(pt1)}$ (vô nghiệm) "
    y4=    f"$\\Leftrightarrow {latex(pt)}$"
    y5=    f"$\\Leftrightarrow \\sin{{{latex(x)}}}=\\sin{{\\left({latex(alpha)}\\right)}}$"
    y6=    f"$\\Leftrightarrow x={latex(x1)}; \\quad x={latex(x2)}; \\quad n \\in \\mathbb{{Z}}$"
    y7=    f"Các nghiệm dương nhỏ nhất là ${latex(nghiemduong5)}$"
    y8=    f"Có tổng là $S={latex(tong_5_nghiem)} \\approx {latex(kqngan)}$"
    return [bai, y1,y2,y3,y4,y5,y6,y7,y8, kqngan]
def cdk_phuongtrinh_nhantutheocos_nhapsonghiem(n):
    #x, y, z, t , k, n= symbols('x y z t k n')
    k=random.choice([2,3,4,5,6,7,8,9])
    alpha=random.choice([pi/6, pi/4,pi/3, 7*pi/6, 5*pi/4, 4*pi/3])#tranh sin=1, -1 vi bieu dien ko dep
    m=random.choice([3,5,7,9,11])
    bt1=cos(x*m)+k
    
    bt2=cos(x)-cos(alpha)
    bttich=bt1*bt2
    bttichkhaitrien=expand(bttich)
    
    pttrumot=Eq(bttich,0)
    pttruhai=Eq(bttichkhaitrien,0)
    pt0=Eq(bt2,0)
    pt1=Eq(bt1,0)

    pt=Eq(cos(x), cos(alpha))
    nghiem=solveset(pt, x, domain=S.Reals)
    nghiemduong = Intersection(nghiem, Interval.open(0, 50))
    
    nghiemduong_5 = sorted(list(nghiemduong))[:n]
    nghiemduong5=set(nghiemduong_5)
    tong_5_nghiem = sum(nghiemduong_5)

    nghiemghi = [s.lamda.expr if hasattr(s, 'lamda') else s for s in nghiem.args]

    x1=nghiemghi[0]
    x2=nghiemghi[1]
    kqngan=tong_5_nghiem

    kqngan=float(kqngan)

    kqngan=int(round_half_up(kqngan,0))

    bai=rf"""
   
        Tính tổng ${latex(n)}$ nghiệm dương nhỏ nhất của $${latex(pttruhai)}$$
         """
    y1=    f"$ {latex(pttruhai)}$"
    y2=    f"$\\Leftrightarrow {latex(pttrumot)}$"
    y3=     f"$\\Leftrightarrow {latex(pt0)}; \\quad {latex(pt1)}$ (vô nghiệm) "
    y4=    f"$\\Leftrightarrow {latex(pt)}$"
    y5=    f"$\\Leftrightarrow \\cos{{{latex(x)}}}=\\cos{{\\left({latex(alpha)}\\right)}}$"
    y6=    f"$\\Leftrightarrow x={latex(x1)}; \\quad x={latex(x2)}; \\quad n \\in \\mathbb{{Z}}$"
    y7=    f"Các nghiệm dương nhỏ nhất là ${latex(nghiemduong5)}$"
    y8=    f"Có tổng là $S={latex(tong_5_nghiem)} \\approx {latex(kqngan)}$"
    return [bai, y1,y2,y3,y4,y5,y6,y7,y8,kqngan]
def cdk_phuongtrinh_nhantutheosin_nhapsonghiem(n):
    #x, y, z, t , k, n= symbols('x y z t k n')
    k=random.choice([2,3,4,5,6,7,8,9])
    alpha=random.choice([pi/6, pi/4,pi/3, 7*pi/6, 5*pi/4, 4*pi/3])#tranh sin=1, -1 vi bieu dien ko dep
    alpha=alpha
    m=random.choice([3,5,7,9,11])
    bt1=sin(x*m)+k
    
    bt2=sin(x)-sin(alpha)
    bttich=bt1*bt2
    bttichkhaitrien=expand(bttich)
    
    pttrumot=Eq(bttich,0)
    pttruhai=Eq(bttichkhaitrien,0)
    pt0=Eq(bt2,0)
    pt1=Eq(bt1,0)
    #print(pttruba)
    pt=Eq(sin(x), sin(alpha))
    nghiem=solveset(pt, x, domain=S.Reals)
    nghiemduong = Intersection(nghiem, Interval.open(0, 50))
    nghiemduong_5 = sorted(list(nghiemduong))[:n]
    nghiemduong5=set(nghiemduong_5)
    tong_5_nghiem = sum(nghiemduong_5)
    #print(tong_5_nghiem)
    nghiemghi = [s.lamda.expr if hasattr(s, 'lamda') else s for s in nghiem.args]
    #print(nghiemduong)
    x1=nghiemghi[0]
    x2=nghiemghi[1]
    kqngan=tong_5_nghiem
    #print(kqngan)
    kqngan=float(kqngan)
    #print(kqngan)
    kqngan=round_half_up(kqngan,0)
    kqngan=int(kqngan)
    #print(kqngan)
    bai=rf"""
  %%    % Biết $\sin{{x}}=\sin{{\alpha}} \Leftrightarrow x = \alpha + 2n \pi; \quad x= \pi -\alpha +2 n \pi$. \\
        Tìm tổng ${latex(n)}$ nghiệm dương nhỏ nhất của $${latex(pttruhai)}$$
         """

       
    y1=   f"$ {latex(pttruhai)}$"
    y2=   f"$\\Leftrightarrow {latex(pttrumot)}$"
    y3=    f"$\\Leftrightarrow {latex(pt0)}; \\quad {latex(pt1)}$ (vô nghiệm) "
    y4=   f"$\\Leftrightarrow {latex(pt)}$"
    y5=   f"$\\Leftrightarrow \\sin{{{latex(x)}}}=\\sin{{\\left({latex(alpha)}\\right)}}$"
    y6=   f"$\\Leftrightarrow x={latex(x1)}; \\quad x={latex(x2)}; \\quad n \\in \\mathbb{{Z}}$"
    y7=   f"Các nghiệm dương nhỏ nhất là ${latex(nghiemduong5)}$"
    y8=   f"Có tổng là $S={latex(tong_5_nghiem)} \\approx {latex(kqngan)}$"
    
    return [bai, y1,y2,y3,y4,y5,y6,y7,y8,kqngan]
def sincongsin(a, b):
    tong=2 * sin((a + b)/2) * cos((a - b) / 2)
     
    return tong
def coscongcos(a, b):
    return 2 * cos((a + b) / 2) * cos((a - b) / 2)
def cdk_phuongtrinh_sincongsin_nhapsonghiem(n):
    
    k=random.choice([2,3,4,5,6,7,8,9])
    alpha=random.choice([pi/6, pi/4,pi/3, 7*pi/6, 5*pi/4, 4*pi/3])#tranh sin=1, -1 vi bieu dien ko dep
    alpha=pi/2
    m=random.choice([7,9,11,13,15,17])
    b=random.choice([2,4,6])  
    n=m-b
    c=Rational((m-n),2)
    
    bt1=sin(x*m)+sin(n*x)
    bt1tich=sincongsin(m*x,n*x)
    bt2=2*k*cos(x*c)
    bttich=simplify(bt1tich-bt2)
    btpttruhai=bttich/(2*cos(x*c))
    pt0=Eq(cos(x*c),0)
    pt1=Eq(btpttruhai,0)
    
    #bttichkhaitrien=expand(bttich)
    #print(btpttruhai)
    pttrumot=Eq(bttich,0)
    pttruhai=Eq(bt1tich, bt2)
    pttruba=Eq(bt1,bt2)
    
    pt=pt0
    nghiem=solveset(pt, x, domain=S.Reals)
    nghiemduong = Intersection(nghiem, Interval.open(0, 50))
    
    nghiemduong_5 = sorted(list(nghiemduong))[:n]
    nghiemduong5=set(nghiemduong_5)
    tong_5_nghiem = sum(nghiemduong_5)
    #print(tong_5_nghiem)
    nghiemghi = [s.lamda.expr if hasattr(s, 'lamda') else s for s in nghiem.args]
    #print(nghiemduong)
    x1=nghiemghi[0]
    x2=nghiemghi[1]
    kqngan=tong_5_nghiem
    #print(kqngan)
    kqngan=float(kqngan)
    #print(kqngan)
    kqngan=int(round_half_up(kqngan,0))
    
    bai=rf"""
        Tìm tổng ${latex(n)}$ nghiệm dương nhỏ nhất của $${latex(pttruba)}$$
         """
 
    y1=    f"$ {latex(pttruba)}$"
    y2=    f"$\\Leftrightarrow {latex(pttruhai)}$"
    y3=    f"$\\Leftrightarrow {latex(pttrumot)}$"
    y4=     f"$\\Leftrightarrow {latex(pt0)}; \\quad {latex(pt1)}$ (vô nghiệm) "
    y5=    f"$\\Leftrightarrow {latex(pt)}$"
    y6=    f"$\\Leftrightarrow \\cos{{{latex(c*x)}}}=\\cos{{\\left({latex(alpha)}\\right)}}$"
    y7=    f"$\\Leftrightarrow x={latex(x1)}; \\quad x={latex(x2)}; \\quad n \\in \\mathbb{{Z}}$"
    y8=    f"Các nghiệm dương nhỏ nhất là ${latex(nghiemduong5)}$"
    y9=    f"Có tổng là $S={latex(tong_5_nghiem)} \\approx {latex(kqngan)}$"
    return [bai, y1,y2,y3,y4,y5,y6,y7,y8, y9,kqngan]
def cdk_phuongtrinh_coscongcos_nhapsonghiem(n):
    
    k=random.choice([2,3,4,5,6,7,8,9])
    alpha=random.choice([pi/6, pi/4,pi/3, 7*pi/6, 5*pi/4, 4*pi/3])#tranh sin=1, -1 vi bieu dien ko dep
    alpha=pi/2
    m=random.choice([7,9,11,13,15])
    b=random.choice([2,4,6])  
    n=m-b
    c=Rational((m-n),2)
    bt1=cos(x*m)+cos(n*x)
    bt1tich=coscongcos(m*x,n*x)
    bt2=2*k*cos(x*c)
    bttich=simplify(bt1tich-bt2)
    btpttruhai=bttich/(2*cos(x*c))
    pt0=Eq(cos(x*c),0)
    pt1=Eq(btpttruhai,0)
    
    #bttichkhaitrien=expand(bttich)
    #print(btpttruhai)
    pttrumot=Eq(bttich,0)
    pttruhai=Eq(bt1tich, bt2)
    pttruba=Eq(bt1,bt2)
    
    pt=pt0
    nghiem=solveset(pt, x, domain=S.Reals)
    nghiemduong = Intersection(nghiem, Interval.open(0, 50))
    
    nghiemduong_5 = sorted(list(nghiemduong))[:n]
    nghiemduong5=set(nghiemduong_5)
    tong_5_nghiem = sum(nghiemduong_5)
    #print(tong_5_nghiem)
    nghiemghi = [s.lamda.expr if hasattr(s, 'lamda') else s for s in nghiem.args]
    #print(nghiemduong)
    x1=nghiemghi[0]
    x2=nghiemghi[1]
    kqngan=tong_5_nghiem
    #print(kqngan)
    kqngan=float(kqngan)
    #print(kqngan)
    kqngan=round_half_up(kqngan,0)
    kqngan=int(kqngan)
    #print(kqngan)
    bai=rf"""
        Tìm tổng ${latex(n)}$ nghiệm dương nhỏ nhất của $${latex(pttruba)}$$
         """

    y1=   f"$ {latex(pttruba)}$"
    y2=    f"$\\Leftrightarrow {latex(pttruhai)}$"
    y3=    f"$\\Leftrightarrow {latex(pttrumot)}$"
    y4=     f"$\\Leftrightarrow {latex(pt0)}; \\quad {latex(pt1)}$ (vô nghiệm) "
    y5=    f"$\\Leftrightarrow {latex(pt)}$"
    y6=    f"$\\Leftrightarrow \\cos{{{latex(x*c)}}}=\\cos{{\\left({latex(alpha)}\\right)}}$"
    y7=    f"$\\Leftrightarrow x={latex(x1)}; \\quad x={latex(x2)}; \\quad n \\in \\mathbb{{Z}}$"
    y8=    f"Các nghiệm dương nhỏ nhất là ${latex(nghiemduong5)}$"
    y9=    f"Có tổng là $S={latex(tong_5_nghiem)} \\approx {latex(kqngan)}$"
    return [bai, y1,y2,y3,y4,y5,y6,y7,y8, y9,kqngan]
#to=cdk_phuongtrinh_bachaitheosin_nhapsonghiem(1)
#print(to)
bt=random.choice([pi/3, pi/2, 2*pi/3])#tranh sin=1, -1 vi bieu dien ko dep
A=x
B=bt+x
to=cos(A-B)
t1=costrucos(A,B)
pt=Eq(t1,0)
pt=solveset(pt)
#print(sin(pi/2+x))
#print(pt)










    
