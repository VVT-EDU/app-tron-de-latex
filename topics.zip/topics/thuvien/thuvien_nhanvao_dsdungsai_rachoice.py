import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    indices_dung = random.sample(range(len(dung)), 2)
    dsdung = [dung[i] for i in indices_dung]
# Tạo tập chỉ số không trùng với indices_dung
    indices_sai_pool = [i for i in range(len(sai)) if i not in indices_dung]
    indices_sai = random.sample(indices_sai_pool, 2)
    dssai = [sai[i] for i in indices_sai]
    
    dung1, dung2 =dsdung[0], dsdung[1]
    sai1,sai2    =dssai[1],dssai[0]
    du1, du2     =f"${dung1}$",f"${dung2}$"
    sa1, sa2     =f"${sai1}$",  f"${sai2}$"
    lg=dung
    dung1 = r'\True ' + f"{du1}"
    dung2 = r'\True ' + f"{du2}"
    sai1 = f"{sa1} " # Convert to string for consistency
    sai2 = f"{sa2}"
    choice = [dung1, sai1, sai2, dung2]
    choice = random.sample(choice, 4)
    choice = f"\\choiceTF \n {{ {choice[0]} }}\n {{ {choice[1]} }}\n {{ {choice[2]} }}\n {{ {choice[3]} }}"
    loigiai = " \\\\\n".join([f"${x}$" for x in lg]) + " \\\\"
    return [choice, loigiai]
def nhanvao_dsdungsai_rachoice_tracnghiem(dung, sai):
    indices_dung = random.sample(range(len(dung)), 1)
    dsdung = [dung[i] for i in indices_dung]
# Tạo tập chỉ số không trùng với indices_dung
    indices_sai_pool = [i for i in range(len(sai)) if i not in indices_dung]
    indices_sai = random.sample(indices_sai_pool, 3)
    dssai = [sai[i] for i in indices_sai]
    
    dung1       =dsdung[0]
    sai1,sai2, sai3    =dssai[1],dssai[2],dssai[0]
    du1                  =f"${dung1}$"
    sa1, sa2, sa3        =f"${sai1}$",  f"${sai2}$",  f"${sai3}$"
    lg=dung
    dung1 = r'\True ' + f"{du1}"
    
    sai1 = f"{sa1} " # Convert to string for consistency
    sai2 = f"{sa2}"
    sai3 = f"{sa3}"
    choice = [dung1, sai1, sai2, sai3]
    choice = random.sample(choice, 4)
    choice = f"\\choice \n {{ {choice[0]} }}\n {{ {choice[1]} }}\n {{ {choice[2]} }}\n {{ {choice[3]} }}"
    loigiai = " \\\\\n".join([f"${x}$" for x in lg]) + " \\\\"
    return [choice, loigiai]
def nhanvao_dsdungsai_rachoice_tracnghiem_it(dung, sai):
   
    
    dung1       =dung[0]
    sai1,sai2, sai3    =sai[1],sai[2],sai[0]
    du1                  =f"${dung1}$"
    sa1, sa2, sa3        =f"${sai1}$",  f"${sai2}$",  f"${sai3}$"
    lg=dung
    dung1 = r'\True ' + f"{du1}"
    
    sai1 = f"{sa1} " # Convert to string for consistency
    sai2 = f"{sa2}"
    sai3 = f"{sa3}"
    choice = [dung1, sai1, sai2, sai3]
    choice = random.sample(choice, 4)
    choice = f"\\choice \n {{ {choice[0]} }}\n {{ {choice[1]} }}\n {{ {choice[2]} }}\n {{ {choice[3]} }}"
    loigiai = " \\\\\n".join([f"${x}$" for x in lg]) + " \\\\"
    return [choice, loigiai]

#to=nhanvao_dsdungsai_rachoice_dungsai([1,1,2,3,4],[5,6,7,8])
#print(to)





    
