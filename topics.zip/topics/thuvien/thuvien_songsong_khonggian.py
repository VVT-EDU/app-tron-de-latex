import random
from decimal import Decimal, ROUND_HALF_UP
from sympy import latex, sqrt
# Hàm làm tròn số theo quy tắc ROUND_HALF_UP
def round_half_up(number, decimals=0):
    factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))

# Hàm tạo khẳng định đúng về giao điểm/giao tuyến của hình chóp
def chopdaytamgiac(A, B, C, D):
    hethuc1 = f"\\text{{Giao điểm giữa }} ({A}{B}{C}) \\text{{ và }} {B}{D} \\text{{ là }} {B}"
    hethuc2 = f"\\text{{Giao tuyến giữa }} ({A}{B}{C}) \\text{{ và }} ({D}{B}{C}) \\text{{ là đường thẳng }} {B}{C}"
    hethuc3 = f"\\text{{Hai đường thẳng }} {A}{D} \\text{{ và }} {B}{C} \\text{{ không có điểm chung }} "
    hethuc4 = f"\\text{{Đường thẳng }} {A}{B} \\text{{ và }} ({B}{C}{D}) \\text{{ có điểm chung }} "
    dung=[hethuc1, hethuc2, hethuc3, hethuc4]

    hethuc1 = f"\\text{{Giao điểm giữa }} ({A}{B}{C}) \\text{{ và }} {D}{C} \\text{{ là }} {B}"
    hethuc2 = f"\\text{{Giao tuyến giữa }} ({A}{B}{D}) \\text{{ và }} ({D}{B}{C}) \\text{{ là đường thẳng }} {A}{C}"
    hethuc3 = f"\\text{{Hai đường thẳng }} {A}{C} \\text{{ và }} {B}{D} \\text{{ có điểm chung }} "
    hethuc4 = f"\\text{{Đường thẳng }} {A}{C} \\text{{ và }} ({B}{C}{D}) \\text{{ không có điểm chung }} "
    sai= [hethuc1, hethuc2, hethuc3, hethuc4]
    return [dung, sai]
 
# Hàm tạo khẳng định đúng về giao điểm/giao tuyến giữa hai tam giác
def choptamgiactamgiac(S, M, N, P, A, B, C):
    hethuc1 = f"\\text{{Giao điểm giữa }} ({M}{N}{P}) \\text{{ và }} {S}{A} \\text{{ là }} {M}"
    hethuc2 = f"\\text{{Giao điểm giữa }} ({M}{N}{P}) \\text{{ và }} {S}{B} \\text{{ là }} {N}"
    hethuc3 = f"\\text{{Giao tuyến giữa }} ({M}{N}{P}) \\text{{ và }} ({S}{A}{B}) \\text{{ là đường thẳng }} {M}{N}"
    hethuc4 = f"\\text{{Giao tuyến giữa }} ({M}{N}{P}) \\text{{ và }} ({S}{A}{C}) \\text{{ là đường thẳng }} {M}{P}"
    hethuc5 = f"\\text{{Giao tuyến giữa }} ({M}{N}{C}) \\text{{ và }} ({S}{A}{B}) \\text{{ là đường thẳng }} {M}{N}"
    hethuc6 = f"\\text{{Giao tuyến giữa }} ({P}{N}{C}) \\text{{ và }} ({S}{A}{B}) \\text{{ là đường thẳng }} {S}{B}"
    hethuc7 = f"\\text{{Hai đường thẳng }} {A}{M} \\text{{ và }} {B}{N} \\text{{ có điểm chung }} "
    dung=[hethuc1, hethuc2, hethuc3, hethuc4, hethuc5, hethuc6, hethuc7]

    hethuc1 = f"\\text{{Giao điểm giữa }} ({M}{N}{P}) \\text{{ và }} {S}{A} \\text{{ là }} {N}"
    hethuc2 = f"\\text{{Giao điểm giữa }} ({M}{N}{P}) \\text{{ và }} {S}{B} \\text{{ là }} {M}"
    hethuc3 = f"\\text{{Giao tuyến giữa }} ({M}{N}{P}) \\text{{ và }} ({S}{A}{B}) \\text{{ là đường thẳng }} {M}{P}"
    hethuc4 = f"\\text{{Giao tuyến giữa }} ({M}{N}{P}) \\text{{ và }} ({S}{A}{C}) \\text{{ là đường thẳng }} {M}{N}"
    hethuc5 = f"\\text{{Giao tuyến giữa }} ({M}{N}{C}) \\text{{ và }} ({S}{A}{B}) \\text{{ là đường thẳng }} {M}{C}"
    hethuc6 = f"\\text{{Giao tuyến giữa }} ({P}{N}{C}) \\text{{ và }} ({S}{A}{B}) \\text{{ là đường thẳng }} {S}{P}"
    hethuc7 = f"\\text{{Hai đường thẳng }} {A}{M} \\text{{ và }} {C}{P} \\text{{ không có điểm chung }} "
    sai=[hethuc1, hethuc2, hethuc3, hethuc4, hethuc5, hethuc6, hethuc7]
    return [dung, sai]

# Hàm tạo khẳng định đúng khi có cạnh song song#MN//AB
def choptamgiactamgiaccocanhsongsong(S, M, N, P, A, B, C):
 
    hethuc8 = f"\\text{{Hai đường thẳng }} {A}{B} \\text{{ và }} {M}{N} \\text{{ không có điểm chung }} "
    hethuc9 = f"\\text{{Đường thẳng }} {M}{N} \\text{{ và }} ({A}{B}{C}) \\text{{ không có điểm chung }} "
    hethuc10 = f"\\text{{Đường thẳng }} {A}{B} \\text{{ và }} ({M}{N}{P}) \\text{{ không có điểm chung }} "
    hethuc1 = f"\\text{{Giao điểm giữa }} ({M}{N}{P}) \\text{{ và }} {S}{A} \\text{{ là }} {M}"
    hethuc2 = f"\\text{{Giao điểm giữa }} ({M}{N}{P}) \\text{{ và }} {S}{B} \\text{{ là }} {N}"
    hethuc3 = f"\\text{{Giao tuyến giữa }} ({M}{N}{P}) \\text{{ và }} ({S}{A}{B}) \\text{{ là đường thẳng }} {M}{N}"
    hethuc4 = f"\\text{{Giao tuyến giữa }} ({M}{N}{P}) \\text{{ và }} ({S}{A}{C}) \\text{{ là đường thẳng }} {M}{P}"
    hethuc5 = f"\\text{{Giao tuyến giữa }} ({M}{N}{C}) \\text{{ và }} ({S}{A}{B}) \\text{{ là đường thẳng }} {M}{N}"
    hethuc6 = f"\\text{{Giao tuyến giữa }} ({P}{N}{C}) \\text{{ và }} ({S}{A}{B}) \\text{{ là đường thẳng }} {S}{B}"
    hethuc7 = f"\\text{{Hai đường thẳng }} {A}{M} \\text{{ và }} {B}{N} \\text{{ có điểm chung }} "
    dung=[hethuc1, hethuc2, hethuc3, hethuc4, hethuc5, hethuc6, hethuc7, hethuc8, hethuc9, hethuc10]
    hethuc8 = f"\\text{{Hai đường thẳng }} {A}{B} \\text{{ và }} {M}{N} \\text{{ có điểm chung }} "
    hethuc9 = f"\\text{{Đường thẳng }} {M}{N} \\text{{ và }} ({A}{B}{C}) \\text{{ có điểm chung }} "
    hethuc10 = f"\\text{{Đường thẳng }} {A}{B} \\text{{ và }} ({M}{N}{P}) \\text{{ có điểm chung }} "
    hethuc1 = f"\\text{{Giao điểm giữa }} ({M}{N}{P}) \\text{{ và }} {S}{A} \\text{{ là }} {N}"
    hethuc2 = f"\\text{{Giao điểm giữa }} ({M}{N}{P}) \\text{{ và }} {S}{B} \\text{{ là }} {M}"
    hethuc3 = f"\\text{{Giao tuyến giữa }} ({M}{N}{P}) \\text{{ và }} ({S}{A}{B}) \\text{{ là đường thẳng }} {M}{P}"
    hethuc4 = f"\\text{{Giao tuyến giữa }} ({M}{N}{P}) \\text{{ và }} ({S}{A}{C}) \\text{{ là đường thẳng }} {M}{N}"
    hethuc5 = f"\\text{{Giao tuyến giữa }} ({M}{N}{C}) \\text{{ và }} ({S}{A}{B}) \\text{{ là đường thẳng }} {M}{C}"
    hethuc6 = f"\\text{{Giao tuyến giữa }} ({P}{N}{C}) \\text{{ và }} ({S}{A}{B}) \\text{{ là đường thẳng }} {S}{P}"
    hethuc7 = f"\\text{{Hai đường thẳng }} {A}{M} \\text{{ và }} {C}{P} \\text{{ không có điểm chung }} "
    sai=[hethuc1, hethuc2, hethuc3, hethuc4, hethuc5, hethuc6, hethuc7, hethuc8, hethuc9, hethuc10]
    return [dung, sai]
def tamgiaccocanhsongsongdaytiso(S,M,N,A,B,ten1="S", ten2="M",ten3="N", ten4="A", ten5="B"):
    sa=S.distance(A)
    sb=S.distance(B)
    sm=S.distance(M)
    sn=S.distance(N)
    mn=M.distance(N)
    ab=A.distance(B)
    hethuc1=f"\\dfrac{{ {ten1}{ten4} }}{{ {ten1}{ten2}}}={latex(sa/sm)}"
    hethuc2=f"\\dfrac{{ {ten1}{ten5} }}{{ {ten1}{ten3}}}={latex(sb/sn)}"
    hethuc3=f"\\dfrac{{ {ten4}{ten5} }}{{ {ten2}{ten3}}}={latex(ab/mn)}"
    hethuc4 = f"\\text{{Hai đường thẳng }} {ten4}{ten2} \\text{{ và }} {ten5}{ten3} \\text{{ có điểm chung }} "
    hethuc5 = f"\\text{{Hai đường thẳng }} {ten4}{ten5} \\text{{ và }} {ten2}{ten3} \\text{{ không có điểm chung }} "
    hethuc6 = f"\\text{{Mặt phẳng }} (\\alpha)\\text{{ chứa đường thẳng }} {ten4}{ten5} \\text{{ và}}"
    hethuc6 +=f"(\\alpha) \\text{{ không chứa }} {ten2}{ten3} \\text{{ thì }} (\\alpha) \\parallel {ten2}{ten3} "
    dung=[hethuc1, hethuc2, hethuc3, hethuc4, hethuc5, hethuc6]
 
    sai=random.choice([2,3,sqrt(1)/2])
    hethuc1=f"\\dfrac{{ {ten1}{ten4} }}{{ {ten1}{ten2}}}={latex(sa/sm*sai)}"
    hethuc2=f"\\dfrac{{ {ten1}{ten5} }}{{ {ten1}{ten3}}}={latex(sb/sn*sai)}"
    hethuc3=f"\\dfrac{{ {ten4}{ten5} }}{{ {ten2}{ten3}}}={latex(ab/mn*sai)}"
    hethuc4 = f"\\text{{Hai đường thẳng }} {ten4}{ten2} \\text{{ và }} {ten5}{ten3} \\text{{ không có điểm chung }} "
    hethuc5 = f"\\text{{Hai đường thẳng }} {ten4}{ten5} \\text{{ và }} {ten2}{ten3} \\text{{  có điểm chung }} "
     
    hethuc6 = f"\\text{{Mặt phẳng }} (\\alpha)\\text{{ chứa đường thẳng }} {ten4}{ten5}  "
    hethuc6 +=f" \\text{{ thì }} (\\alpha) \\parallel {ten2}{ten3} "
    sai=[hethuc1, hethuc2, hethuc3, hethuc4, hethuc5, hethuc6]
    return [dung, sai]
def cdk_tamgiaccocanhsongsongdaytiso(S,M,N,A,B,ten1="S", ten2="M",ten3="N", ten4="A", ten5="B"):
    sa=S.distance(A)
    sm=S.distance(M)
    hethuc1 =f"\\dfrac{{ {ten1}{ten4} }}{{ {ten1}{ten2}}}"
    hethuc1 += f"=\\dfrac{{ {ten1}{ten5} }}{{ {ten1}{ten3}}}"
    hethuc1 += f"=\\dfrac{{ {ten4}{ten5} }}{{ {ten2}{ten3}}}={latex(sa/sm)}"
    return hethuc1
#tinh phan só dau tien MA/MB
def cdk_menelaus_tinh(A,B,C,M,P,N ,ten1="A", ten2="B",ten3="C", ten4="M", ten5="P", ten6="N"):
    ma=M.distance(A)
    mb=M.distance(B)
    pb=P.distance(B)
    pc=P.distance(C)
    nc=N.distance(C)
    na=N.distance(A)
    ac=A.distance(C)
    hethuc1 =f"\\dfrac{{ {ten4}{ten1} }}{{ {ten4}{ten2} }}"
    hethuc1 +=f"\\cdot \\dfrac{{ {ten5}{ten2}}}{{ {ten5}{ten3}}}"
    hethuc1 +=f"\\cdot \\dfrac{{ {ten6}{ten3}}}{{ {ten6}{ten1}}}=1"
    hethuc1 +=f"\\Rightarrow "
    hethuc1 +=f"{latex(ma/mb)}"
    hethuc1 +=f"\\cdot {latex(pb/pc)}"
    hethuc1 +=f"\\cdot \\dfrac{{ {ten6}{ten3} }}{{ {ten6}{ten1} }}=1"
    hethuc1 +=f"\\Rightarrow \\dfrac{{ {ten6}{ten3} }}{{ {ten6}{ten1} }}={latex(mb*pc/(ma*pb))}"
    hethuc1 +=f"\\Rightarrow \\dfrac{{ {ten1}{ten3} }}{{ {ten1}{ten6} }} ={latex(ac/na)}"
    return hethuc1
    
def cdk_menelaus0():
    bai = ( 
           r'Hai tam giác $SMH$ và $SKH$ đồng dạng. \\'
           r'Hai tam giác $SAC$ và $KIC$ đồng dạng. \\'
           f"Có $\\dfrac{{CI}}{{CA}}=\\dfrac{{KI}}{{MA}}$ \\, "
           f"Có $\\dfrac{{HS}}{{HI}}=\\dfrac{{MS}}{{KI}}$ \\\\"
           f"Nên $\\dfrac{{CI}}{{CA}} \\cdot \\dfrac{{HS}}{{HI}} = \\dfrac{{MA}}{{MS}}$\\\\"
           f" Định lí Menelaus $\\dfrac{{CI}}{{CA}} \\cdot \\dfrac{{HS}}{{HI}} \\cdot \\dfrac{{MA}}{{MS}}=1$ \\\\"
           f" Chỉnh lại chút $\\boxed{{\\dfrac{{CI}}{{CA}}  \\cdot \\dfrac{{MA}}{{MS}} \\cdot \\dfrac{{HS}}{{HI}}=1 }}$\\\\"
            
            )
    
    # Hình vẽ
    hinhve = (
        r'\begin{tikzpicture}[scale=0.6,yscale=0.7,font=\footnotesize, line join=round, line cap=round, >=stealth]' +
        r' \def \day{-60}' +
        r' \def \dinh{90}' +
        r' \def \dai{8}' +
        r' \def \rong{5}' +
        r' \def \cao{8}' +
        r'\path (0,0) coordinate(A) (\dai,0)coordinate(B)' +
        r' ($(A)+(\day:\rong)$)coordinate(D)($(B)+(0:\rong)$)coordinate(C)'
        r'($(A)+(\dinh:\cao)$)coordinate(S)' +
        r'  ($(A)!0.5!(C)$)coordinate(I)' +
        
        #r'  ($(M)!0.5!(C)$)coordinate(K)' +
        r' ($(S)!0.35!(A)$)coordinate(M)'+
        r'  ($(M)!0.5!(C)$)coordinate(K)' +
        r' ($(S)!0.7!(I)$)coordinate(G);'+
        r'\fill[blue!20](S)--(A)--(I)--(S);'+
        r'\fill[yellow!40](K)--(C)--(I)--(K);'+
        r'\tkzInterLL(M,C)(S,I) \tkzGetPoint{H}'+
        r'\tkzInterLL(M,G)(B,I) \tkzGetPoint{B1}'+
        r'\draw (S)--(A)--(C) (S)--(I)--(K);' +
        r'\draw[dashed](C)--(M);' +
        r'\draw($(K)+(90:0.8)$)  circle(16pt);'+
        r'\foreach \i/\g in{S/180,A/180 ,K/90, C/-90, I/-90, H/0, M/180} \fill(\i) circle(2pt) ($(\i)+(\g:0.8)$)node{\i};' +
        r'\end{tikzpicture}'
    )
    ketqua=f"\\immini{{ {bai}}}{{ {hinhve} }}"
    return ketqua















