from sympy import symbols, Interval, latex, solveset, S, Eq, Ne, expand
from sympy.sets import Complement, FiniteSet
import os, re, random
from sympy import Line, Point, symbols, Eq, solve, pi
from sympy import symbols, Interval, latex
from sympy import symbols, expand, simplify, Limit, oo, latex, sqrt
from sympy import symbols, fraction, simplify
import os, re

def atn_gioihan_dayso_phanthuc_nhaphaiso(a,b):
    n=symbols('n')
    tu=random.sample([a*n**3+b*n, a*n**2-b*n, a*n+b, a*n,          (a+1)*n**4+b,  (a+1)*n**2+2*b],       6)
    mau=random.sample([b*n**3,    b*n**2+a,   b*n+a, b*n**4+a*n, (a+1)*n**2-2*b, (a+1)*n-(a+b)],6)
    ps0, ps1, ps2, ps3, ps4, ps5=tu[0]/mau[0],tu[1]/mau[1],tu[2]/mau[2],tu[3]/mau[3],tu[4]/mau[4],tu[5]/mau[5]
    gh1=Limit(ps0, n, oo)
    gh2=Limit(ps1, n, oo)
    gh3=Limit(ps2, n, oo)
    gh4=Limit(ps3, n, oo)
    gh5=Limit(ps4, n, oo)
    gh6=Limit(ps5, n, oo)
    kq1=gh1.doit()
    kq2=gh2.doit()
    kq3=gh3.doit()
    kq4=gh4.doit()
    kq5=gh5.doit()
    kq6=gh6.doit()
    bt1=f" {latex(gh1)}={latex(kq1)} "
    bt2=f" {latex(gh2)}={latex(kq2)} "
    bt3=f" {latex(gh3)}={latex(kq3)} "
    bt4=f" {latex(gh4)}={latex(kq4)} "
    bt5=f" {latex(gh5)}={latex(kq5)} "
    bt6=f" {latex(gh6)}={latex(kq6)} "
    dung=[bt1,bt2,bt3,bt4,bt5,bt6]
    sai=random.choice([1,2,3])
    bt1=f" {latex(gh1)}={latex(kq1+sai)} "
    bt2=f" {latex(gh2)}={latex(kq2+sai)} "
    bt3=f" {latex(gh3)}={latex(kq3+sai)} "
    bt4=f" {latex(gh4)}={latex(kq4+sai)} "
    bt5=f" {latex(gh5)}={latex(kq5+sai)} "
    bt6=f" {latex(gh6)}={latex(kq6+sai)} "
    sai=[bt1,bt2,bt3,bt4,bt5,bt6]
    return [dung,sai]
    
def atn_gioihan_dayso_somu_nhaphaiso(a,b):
    n=symbols('n')
    tu=random.sample([a**n+b, b**n+a, (a+b)**n-a, (2*a)**n+a, (2*b)**n+b, (a+1)**n-b],       6)
    mau=random.sample([a**n+b**n, b**n+(a+b)**n, (a+b)**n-a**n, (2*a)**n+b**n, (2*b)**n+a**n, (a+b)**n-b**n],6)
    ps0, ps1, ps2, ps3, ps4, ps5=tu[0]/mau[0],tu[1]/mau[1],tu[2]/mau[2],tu[3]/mau[3],tu[4]/mau[4],tu[5]/mau[5]
    gh1=Limit(ps0, n, oo)
    gh2=Limit(ps1, n, oo)
    gh3=Limit(ps2, n, oo)
    gh4=Limit(ps3, n, oo)
    gh5=Limit(ps4, n, oo)
    gh6=Limit(ps5, n, oo)
    kq1=gh1.doit()
    kq2=gh2.doit()
    kq3=gh3.doit()
    kq4=gh4.doit()
    kq5=gh5.doit()
    kq6=gh6.doit()
    bt1=f" {latex(gh1)}={latex(kq1)} "
    bt2=f" {latex(gh2)}={latex(kq2)} "
    bt3=f" {latex(gh3)}={latex(kq3)} "
    bt4=f" {latex(gh4)}={latex(kq4)} "
    bt5=f" {latex(gh5)}={latex(kq5)} "
    bt6=f" {latex(gh6)}={latex(kq6)} "
    dung=[bt1,bt2,bt3,bt4,bt5,bt6]
    sai=random.choice([1,2,3])
    bt1=f" {latex(gh1)}={latex(kq1+sai)} "
    bt2=f" {latex(gh2)}={latex(kq2+sai)} "
    bt3=f" {latex(gh3)}={latex(kq3+sai)} "
    bt4=f" {latex(gh4)}={latex(kq4+sai)} "
    bt5=f" {latex(gh5)}={latex(kq5+sai)} "
    bt6=f" {latex(gh6)}={latex(kq6+sai)} "
    sai=[bt1,bt2,bt3,bt4,bt5,bt6]
    return [dung,sai]

def atn_gioihan_hamso_phanthuc_nhaphaiso(a,b):
    x=symbols('x')
    x0=random.choice([1,2,3,4,5])
    t1=expand((x-x0)*(x-a))
    t2=expand((x-x0)*(x-a*2))
    t3=expand((x-x0)*(x-a*3))
    t4=expand((x-x0)*(x-a*4))
    t5=expand((x-x0)*(x-a*5))
    t6=expand((x-x0)*(x-a*6))
    m1=expand(b*(x-x0))
    m2=expand(b*(x-x0)*2)
    m3=expand(b*(x-x0)*(-1))
    m4=expand(b*(x-x0)*3)
    m5=expand(b*(x-x0)*(-2))
    m6=expand(b*(x-x0)*4)
    
    tu=random.sample([t1,t2,t3,t4,t5,t6],       6)
    mau=random.sample([m1,m2,m3,m4,m5,m6],      6)
    ps0, ps1, ps2, ps3, ps4, ps5=tu[0]/mau[0],tu[1]/mau[1],tu[2]/mau[2],tu[3]/mau[3],tu[4]/mau[4],tu[5]/mau[5]
    gh1=Limit(ps0, x, x0, dir='+-')
    gh2=Limit(ps1, x,  x0, dir='+-')
    gh3=Limit(ps2, x,  x0, dir='+-')
    gh4=Limit(ps3, x,  x0, dir='+-')
    gh5=Limit(ps4, x,  x0, dir='+-')
    gh6=Limit(ps5, x,  x0, dir='+-')
    kq1=gh1.doit()
    kq2=gh2.doit()
    kq3=gh3.doit()
    kq4=gh4.doit()
    kq5=gh5.doit()
    kq6=gh6.doit()
    bt1=f" {latex(gh1)}={latex(kq1)} "
    bt2=f" {latex(gh2)}={latex(kq2)} "
    bt3=f" {latex(gh3)}={latex(kq3)} "
    bt4=f" {latex(gh4)}={latex(kq4)} "
    bt5=f" {latex(gh5)}={latex(kq5)} "
    bt6=f" {latex(gh6)}={latex(kq6)} "
    dung=[bt1,bt2,bt3,bt4,bt5,bt6]
    sai=random.choice([1,2,3])
    bt1=f" {latex(gh1)}={latex(kq1+sai)} "
    bt2=f" {latex(gh2)}={latex(kq2+sai)} "
    bt3=f" {latex(gh3)}={latex(kq3+sai)} "
    bt4=f" {latex(gh4)}={latex(kq4+sai)} "
    bt5=f" {latex(gh5)}={latex(kq5+sai)} "
    bt6=f" {latex(gh6)}={latex(kq6+sai)} "
    sai=[bt1,bt2,bt3,bt4,bt5,bt6]
    return [dung,sai]

from sympy import symbols, expand, collect

def cdk_vocungtruvocung_nhaphaiso(a,b):
    x=symbols('x')
    t=random.choice([x+a, x+b, x])
    bt1=expand(t**2)
    bt1=sqrt(bt1+a)
    bt2=t-a
    bt=bt1-bt2
    gh1=Limit(bt, x, oo)
    btlh=bt1+bt2
    tu=expand(bt*btlh)
    mau=btlh
    gh2=Limit(tu/mau, x, oo)
    gh3=gh2.doit()
    kq=float(gh3)
    bai=f" $T={latex(gh1)}$. Tính $|T|$ (làm tròn đến hàng đơn vị)"
    ht1=f"${latex(gh1)}$"
    ht2=f"$={latex(gh2)}$"
    ht3=f"$={latex(gh3)}$"
    #kq=f"{kq}"
    return [bai, ht1, ht2, ht3, kq]

def cdk_khongchiakhong_nhaphaiso(a,b):
    x=symbols('x')
    x0=a+b
    mau=x-x0
    mauthem=mau
    bt1=expand(mau+b)
    bt2=expand(a*mau+b)
    
    tua=sqrt(bt1)-sqrt(bt2)
    tub=sqrt(bt1)+sqrt(bt2)
    mau=expand(tua*tub)
    pt=Eq(mau,0)
    x0=solve(pt)[0]
    #print(x0)
    bieuthuc=tua/mauthem
    gioihan=Limit(bieuthuc, x, x0, dir='+-')
    bai=f"  $A={latex(gioihan)}$. Tính $|A|$ (làm tròn đến hàng đơn vị) "
    y1=f"Có ${latex(tua*tub)}={latex(mau)}$ nên "
    tu1=mau
    mau1=mauthem*tub
    bieuthuc1=tu1/mau1
    
    gioihan1=Limit(bieuthuc1, x, x0, dir='+-')
    y2=f"$A={latex(gioihan1)}$"
    #print(gioihan1)
    bieuthuc2=simplify(bieuthuc1)
    #bieuthuc2=factor(bieuthuc1)
    #print(bieuthuc2)
    gioihan2=Limit(bieuthuc2, x, x0, dir='+-')
    y3=f"$A={latex(gioihan2)}$"
    gioihan3 = gioihan2.doit()
    #print(gioihan2)
    y4=f"$A={latex(gioihan3)}$"
    kq=float(gioihan3)
     
    return [bai, y1,y2,y3,y4, kq]

    
    
















    








    
   
