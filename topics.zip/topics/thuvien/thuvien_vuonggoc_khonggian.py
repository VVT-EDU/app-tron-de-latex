from sympy import symbols, Interval, latex, solveset, S, Eq, Ne, expand, Plane
from sympy.sets import Complement, FiniteSet
import os, re, random
from sympy import Line, Point, symbols, Eq, solve, pi, sqrt
from sympy import symbols, Interval, latex
from sympy import FiniteSet
import os, re
from sympy import Point3D, Line, latex, simplify, Matrix
from sympy.geometry import Point
import sympy as sp
from math import gcd
from functools import reduce
from sympy import Point3D
from sympy.vector import CoordSys3D, cross
from sympy import Matrix, Rational, cos, sin , pi, deg

# Hệ tọa độ
N = CoordSys3D('N')

x, y, z, t = symbols('x y z t')
R = Interval(-S.Infinity, S.Infinity)
# Đường dẫn tới thư mục
output_directory = 'D:/py12_2025/data'
from decimal import Decimal, ROUND_HALF_UP

# Function to round numbers using ROUND_HALF_UP
def round_half_up(number, decimals=0):
    factor = Decimal('1.' + '0' * decimals)
    return float(Decimal(str(number)).quantize(factor, rounding=ROUND_HALF_UP))
 

from sympy import Point3D
from sympy.vector import CoordSys3D, cross

def tichcohuong(p1, p2):
    N = CoordSys3D('N')
    v1 = p1.x * N.i + p1.y * N.j + p1.z * N.k
    v2 = p2.x * N.i + p2.y * N.j + p2.z * N.k
    result = cross(v1, v2)
    # Lấy hệ số theo từng trục và gom thành tuple
    x = result.dot(N.i)
    y = result.dot(N.j)
    z = result.dot(N.k)
    return Point3D(x, y, z)

# Hàm để tạo nội dung loigiai, dapan, dieukien và bai
###canh_vuongmat
def atn_tudien_canhvuongmat_nhapbondiem(S,A,B,C):
    y1=f"\\text{{Hai đường thẳng }} {S}{A} \\text{{ và }} {A}{B} \\text{{ vuông góc }}"
    y2=f"\\text{{Hai đường thẳng }} {S}{A} \\text{{ và }} {A}{C} \\text{{ vuông góc }}"
    y3=f"\\text{{Hai đường thẳng }} {S}{A} \\text{{ và }} {B}{C} \\text{{ vuông góc }}"    
    y4=f"\\text{{Đường thẳng }} {S}{A} \\text{{ vuông góc mặt phẳng }} ({A}{B}{C}) "
    y5=f"\\text{{Mặt phẳng }} (\\alpha) \\text{{ chứa hai đường thẳng }} {B}{A} \\text{{ và }}  {B}{C} \\text{{ thì }}(\\alpha) \\text{{ vuông góc }} {S}{A}"
    dung=[y1,y2,y3,y4,y5]
    y1=f"\\text{{Hai đường thẳng }} {S}{A} \\text{{ và }} {S}{B} \\text{{ vuông góc }}"
    y2=f"\\text{{Hai đường thẳng }} {S}{A} \\text{{ và }} {S}{C} \\text{{ vuông góc }}"  
    y3=f"\\text{{Đường thẳng }} {S}{A} \\text{{ vuông góc mặt phẳng }} ({S}{B}{C}) "
    y4=f"\\text{{Mặt phẳng }} (\\alpha) \\text{{ chứa hai đường thẳng }} {B}{S} \\text{{ và }}   {B}{C} \\text{{ thì }}(\\alpha) \\text{{ vuông góc }} {S}{A}"
    sai=[y1,y2,y3,y4]
    
    return [dung, sai]

############################################
def atn_tudienvuong_nhapbondiem(S,A,B,C):
    s=random.choice([2,3,5,7,8])
    s=sqrt(s)
    b=random.choice([2,4,6,8])
    c=random.choice([1,3,5,7,9])

    r'''A = Point3D(0, 0, 0)
    B = Point3D(b, 0, 0)
    C = Point3D(0,c,0)
    I = (B + C) / 2
    S = Point3D(0, 0, s)'''
    y1=f"\\text{{Hai đường thẳng }} {S}{A} \\text{{ và }} {A}{B} \\text{{ vuông góc }}"
    y2=f"\\text{{Hai đường thẳng }} {S}{A} \\text{{ và }} {A}{C} \\text{{ vuông góc }}"
    y3=f"\\text{{Hai đường thẳng }} {S}{A} \\text{{ và }} {B}{C} \\text{{ vuông góc }}"
    y4=f"\\text{{Hai đường thẳng }} {S}{B} \\text{{ và }} {A}{C} \\text{{ vuông góc }}"
    y5=f"\\text{{Hai đường thẳng }} {S}{C} \\text{{ và }} {A}{B} \\text{{ vuông góc }}"
    y6=f"\\text{{Đường thẳng }} {S}{A} \\text{{ vuông góc mặt phẳng }} ({A}{B}{C}) "
    y7=f"\\text{{Đường thẳng }} {B}{A} \\text{{ vuông góc mặt phẳng }} ({A}{S}{C}) "
    y8=f"\\text{{Đường thẳng }} {C}{A} \\text{{ vuông góc mặt phẳng }} ({A}{B}{S}) "
    y9=f"\\text{{Mặt phẳng }} (\\alpha) \\text{{ chứa hai đường thẳng }} {B}{A} \\text{{ và }}    {B}{C} \\text{{ thì }} (\\alpha) \\text{{ vuông góc }} {S}{A}"
    dung=[y1,y2,y3,y4,y5,y6,y7,y8, y9]
    y1=f"\\text{{Hai đường thẳng }} {S}{A} \\text{{ và }} {S}{B} \\text{{ vuông góc }}"
    y2=f"\\text{{Hai đường thẳng }} {S}{A} \\text{{ và }} {S}{C} \\text{{ vuông góc }}"
    y3=f"\\text{{Hai đường thẳng }} {C}{A} \\text{{ và }} {B}{C} \\text{{ vuông góc }}"
    y4=f"\\text{{Hai đường thẳng }} {S}{B} \\text{{ và }} {A}{B} \\text{{ vuông góc }}"
    y5=f"\\text{{Hai đường thẳng }} {S}{C} \\text{{ và }} {A}{C} \\text{{ vuông góc }}"
    y6=f"\\text{{Đường thẳng }} {S}{B} \\text{{ vuông góc mặt phẳng }} ({A}{B}{C}) "
    y7=f"\\text{{Đường thẳng }} {S}{C} \\text{{ vuông góc mặt phẳng }} ({A}{B}{C}) "
    y8=f"\\text{{Đường thẳng }} {S}{C} \\text{{ vuông góc mặt phẳng }} ({A}{B}{S}) "
    y9=f"\\text{{Mặt phẳng }} (\\alpha) \\text{{ chứa }} {S}{A} \\text{{ thì }} (\\alpha) \\text{{ vuông góc }} {B}{C}"
    sai=[y1,y2,y3,y4,y5,y6,y7,y8, y9]   
    
    return [dung, sai]
def cdk_tudien_duongvuongmat_coduongcaovaday_rakhoangcach(S,A,B,C, ten1="S", ten2="A", ten3="B", ten4="C"):
    sa=S.distance(A)
    ab=A.distance(B)
    ac=A.distance(C)
    bc=B.distance(C)
    O=Point3D(0,0,0)
    AB, AC, BC=B-A, C-A, C-B
    AS, SB, SC=S-A, B-S, C-S
    tich1=tichcohuong(AB,AC)
    dtich1=O.distance(tich1)
    dtich1=abs(dtich1/2)
    dcao1=dtich1*2/bc
    ttich=AS.dot(tich1)
    ttich=abs(ttich/6)
    tich2=tichcohuong(SB, SC)
    dtich2=O.distance(tich2)
    dtich2=abs(dtich2/2)
    kcach=3*ttich/dtich2
    kq=kcach
    y1=f"Gọi ${ten2}_1 \\in {ten3}{ten4}$ và ${ten2}{ten2}_1 \\perp {ten3}{ten4}$"
    y2=f"Gọi ${ten2}_2 \\in {ten1}{ten2}_1$ và ${ten2}{ten2}_2 \\perp {ten1}{ten2}_1$ "
    y3=f"Có ${ten3}{ten4} \\perp ({ten2}{ten2}_1{ten1})$"
    y4=f"Có ${ten2}{ten2}_2 \\perp ({ten1}{ten3}{ten4})$"
    
    y5=f"Diện tích tam giác ${ten2}{ten3}{ten4}$ bằng ${latex(dtich1)}$"
    y6=f"${ten1}{ten2}={latex(sa)}$, ${ten2}{ten2}_1={latex(dcao1)}$ "
    y6 +=f" và $\\dfrac{{1}}{{ {ten2}{ten2}_2^2 }}=\\dfrac{{1}}{{ {ten2}{ten1}^2}}+\\dfrac{{1}}{{{ten2}{ten2}_1^2}}$"
    #y7=f"Thể tích khối ${ten1}{ten2}{ten3}{ten4}$ bằng ${latex(ttich)}$"
    #y8=f"Diện tích tam giác ${ten1}{ten3}{ten4}$ bằng ${latex(dtich2)}$"
    y7=f"Khoảng cách từ ${ten2}$ đến mặt phẳng $({ten1}{ten3}{ten4})$ là ${ten2}{ten2}_2={latex(kcach)}$"
       
    return [y1,y2,y3,y4,y5,y6,y7,kq]
# Function to generate multiple questions and save to two files
def cdk_tudien_duongvuongmat_coduongcaovaday_rathetich(S,A,B,C, ten1="S", ten2="A", ten3="B", ten4="C"):
    sa=S.distance(A)
    ab=A.distance(B)
    ac=A.distance(C)
    bc=B.distance(C)
    O=Point3D(0,0,0)
    AB, AC, BC=B-A, C-A, C-B
    AS, SB, SC=S-A, B-S, C-S
    tich1=tichcohuong(AB,AC)
    dtich1=O.distance(tich1)
    dtich1=abs(dtich1/2)
    dcao1=dtich1*2/bc
    ttich=AS.dot(tich1)
    ttich=abs(ttich/6)
    kq=(ttich)
    
    y1=f"Diện tích tam giác ${ten2}{ten3}{ten4}$ bằng ${latex(dtich1)}$"
    y2=f"${ten1}{ten2}={latex(sa)}$"
    
    y3=f"Thể tích khối ${ten1}{ten2}{ten3}{ten4}$ bằng ${latex(ttich)}$"
    
       
    return [y1,y2,y3,kq]
# Function to generate multiple questions and save to two files

def cdk_tudien_duongvuongmat_duongvuongmat_coduongcaovaday_rakhoangcach(S,A,B,C, ten1="S", ten2="A", ten3="B", ten4="C"):
    #SA vuong(ABC) #CB vuong(SAB)
    sa=S.distance(A)
    ab=A.distance(B)
    ac=A.distance(C)
    bc=B.distance(C)
    O=Point3D(0,0,0)
    AB, AC, BC=B-A, C-A, C-B
    AS, SB, SC=S-A, B-S, C-S
    tich1=tichcohuong(AB,AC)
    dtich1=O.distance(tich1)
    dtich1=abs(dtich1/2)
    dcao1=dtich1*2/bc
    ttich=AS.dot(tich1)
    ttich=abs(ttich/6)
    tich2=tichcohuong(SB, SC)
    dtich2=O.distance(tich2)
    dtich2=abs(dtich2/2)
    kcach=3*ttich/dtich2
    kq=kcach
    y1=f"Gọi ${ten2}^\\prime \\in {ten3}{ten1}$ và ${ten2}{ten2}^\\prime \\perp {ten3}{ten1}$"
  
    y2=f"Có ${ten3}{ten4} \\perp ({ten3}{ten2}{ten1})$"
    y3=f"Có ${ten2}{ten2}^\\prime \\perp ({ten1}{ten3}{ten4})$"
    
    y4=f"Diện tích tam giác ${ten2}{ten3}{ten4}$ bằng ${latex(dtich1)}$"
    y5=f"${ten1}{ten2}={latex(sa)}$, ${ten2}{ten3}={latex(dcao1)}$ "
    y5 +=f" và $\\dfrac{{1}}{{ {ten2}^\\prime {ten2}^2 }}=\\dfrac{{1}}{{ {ten2}{ten1}^2}}+\\dfrac{{1}}{{{ten2}{ten3}^2}}$"
    #y7=f"Thể tích khối ${ten1}{ten2}{ten3}{ten4}$ bằng ${latex(ttich)}$"
    #y8=f"Diện tích tam giác ${ten1}{ten3}{ten4}$ bằng ${latex(dtich2)}$"
    y6=f"Khoảng cách từ ${ten2}$ đến mặt phẳng $({ten1}{ten3}{ten4})$ là ${ten2}{ten2}^\\prime={latex(kcach)}$"
       
    return [y1,y2,y3,y4,y5,y6,kq]















