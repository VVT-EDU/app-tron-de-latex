import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    # P(A): Thích Game, P(B): Thích Phim, P(AB): Thích cả hai
    p_a = random.randint(35, 55)   # 35% - 55%
    p_b = random.randint(40, 60)   # 40% - 60%
    # P(AB) phải nhỏ hơn hoặc bằng min(p_a, p_b)
    p_ab = random.randint(10, min(p_a, p_b) - 5) 
    
    # Tính P(A cup B): Thích ít nhất một trong hai
    p_union = p_a + p_b - p_ab
    # Tính P(chỉ thích Game): P(A) - P(AB)
    p_only_a = p_a - p_ab
    
    # --- 2. DANH SÁCH KHẲNG ĐỊNH ĐỐI ỨNG ---
    dung_list = [
        rf"Xác suất học sinh đó thích chơi Game là $P(A) = {p_a}\%$",
        rf"Xác suất học sinh đó thích cả xem phim và chơi Game là $P(AB) = {p_ab}\%$",
        rf"Xác suất học sinh đó thích ít nhất một trong hai sở thích trên là $P(A \cup B) = {p_union}\%$",
        rf"Xác suất học sinh đó chỉ thích chơi Game (không thích xem phim) là ${p_only_a}\%$",
        rf"Biến cố $AB$ là biến cố: \lq\lq Học sinh được chọn thích cả hai thứ\rq\rq",
        rf"Xác suất học sinh đó không thích cả Game lẫn Phim là ${100 - p_union}\%$"
    ]
    
    sai_list = [
        rf"Xác suất học sinh đó thích xem phim là $P(B) = {p_ab}\%$", # Nhầm với P(AB)
        rf"Xác suất học sinh đó thích cả xem phim và chơi Game là $P(AB) = {p_a + p_b}\%$", # Sai công thức
        rf"Xác suất học sinh đó thích ít nhất một trong hai sở thích trên là $P(A \cup B) = {p_a + p_b}\%$", # Quên trừ P(AB)
        rf"Xác suất học sinh đó chỉ thích chơi Game là ${p_a}\%$", # Nhầm với P(A)
        rf"Biến cố $A \cup B$ là biến cố xung khắc",
        rf"Xác suất học sinh đó không thích cả Game lẫn Phim là ${p_union}\%$" # Nhầm với biến cố đối
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 3. RENDER MÃ EX ---
    return rf"""\begin{{ex}}
    Khảo sát sở thích của học sinh một trường THPT, kết quả cho thấy có ${p_a}\%$ học sinh thích chơi Game, ${p_b}\%$ học sinh thích xem phim và ${p_ab}\%$ học sinh thích cả hai sở thích này. Chọn ngẫu nhiên một học sinh. Xét hai biến cố:
    $A$: \lq\lq Học sinh đó thích chơi Game\rq\rq; $B$: \lq\lq Học sinh đó thích xem phim\rq\rq.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        Dựa vào giả thiết, ta có: $P(A) = {p_a/100:.2f}$; $P(B) = {p_b/100:.2f}$; $P(AB) = {p_ab/100:.2f}$.
        \begin{{itemize}}
            \item Xác suất thích ít nhất một trong hai: $P(A \cup B) = P(A) + P(B) - P(AB) = {p_a/100:.2f} + {p_b/100:.2f} - {p_ab/100:.2f} = {p_union/100:.2f}$.
            \item Xác suất chỉ thích chơi Game: $P(A \setminus B) = P(A) - P(AB) = {(p_a - p_ab)/100:.2f}$.
            \item Xác suất không thích cả hai: $P(\overline{{A \cup B}}) = 1 - P(A \cup B) = {1 - p_union/100:.2f}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
