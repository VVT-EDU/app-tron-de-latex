import random
import itertools

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def format_prob(value):
    """Định dạng số thực sang chuỗi có dấu phẩy kiểu Việt Nam."""
    if isinstance(value, int): return str(value)
    return f"{value:.3f}".replace('.', ',').rstrip('0').rstrip(',')

def generate():
    # --- 1. TẠO TẬP HỢP S ---
    digits = [1, 2, 3, 4, 5, 6]
    # Tạo tất cả các số có 3 chữ số đôi một khác nhau
    S = ["".join(map(str, p)) for p in itertools.permutations(digits, 3)]
    n_S = len(S) # 6P3 = 120
    
    # --- 2. TÍNH TOÁN BIẾN CỐ ---
    # Biến cố A: số > 200
    A_list = [s for s in S if int(s) > 200]
    n_A = len(A_list)
    p_A = round(n_A / n_S, 3)
    
    # Biến cố B: số lẻ (kết thúc bằng 1, 3, 5)
    B_list = [s for s in S if int(s[-1]) % 2 != 0]
    n_B = len(B_list)
    p_B = round(n_B / n_S, 3)
    
    # Biến cố giao AB: số > 200 VÀ là số lẻ
    AB_list = [s for s in A_list if s in B_list]
    n_AB = len(AB_list)
    p_AB = round(n_AB / n_S, 3)
    
    # --- 3. DANH SÁCH KHẲNG ĐỊNH ---
    dung_list = [
        rf"Số phần tử của tập hợp $S$ là $n(S) = {n_S}$",
        rf"Số các kết quả thuận lợi cho biến cố $A$ là $n(A) = {n_A}$",
        rf"Xác suất của biến cố $B$ là $P(B) = {format_prob(p_B)}$",
        rf"Xác suất của biến cố giao $AB$ là $P(AB) = {format_prob(p_AB)}$",
        rf"Số các số lẻ trong $S$ là ${n_B}$ số",
        rf"$A$ và $B$ không phải là hai biến cố độc lập" # Vì P(A)*P(B) != P(AB)
    ]
    
    sai_list = [
        rf"Số phần tử của tập hợp $S$ là $n(S) = 216$", # 6^3 (nhầm sang có thể lặp)
        rf"Số các kết quả thuận lợi cho biến cố $A$ là $n(A) = 100$",
        rf"Xác suất của biến cố $B$ là $P(B) = {format_prob(0.5)}$",
        rf"Xác suất của biến cố $A$ là $P(A) = {format_prob(0.6)}$",
        rf"Biến cố $A$ và $B$ là hai biến cố xung khắc",
        rf"Số các kết quả thuận lợi cho biến cố giao $AB$ là $n(AB) = {n_A + n_B}$"
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 4. RENDER MÃ EX ---
    return rf"""\begin{{ex}}
    Từ các chữ số $\{{1; 2; 3; 4; 5; 6\}}$, lập tập hợp $S$ gồm các số có 3 chữ số đôi một khác nhau. Chọn ngẫu nhiên một số từ tập $S$. 
    Gọi $A$ là biến cố: \lq\lq Chọn được số lớn hơn 200\rq\rq, biến cố $B$: \lq\lq Chọn được số lẻ\rq\rq.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        * Số phần tử của $S$ là chỉnh hợp chập 3 của 6: $n(S) = A_6^3 = 6 \cdot 5 \cdot 4 = {n_S}$.
        * Biến cố $A$: Chữ số hàng trăm có 5 cách chọn (từ $\{{2,3,4,5,6\}}$), hai vị trí còn lại có $A_5^2$ cách. 
          Vậy $n(A) = 5 \cdot A_5^2 = 5 \cdot 20 = {n_A}$. Suy ra $P(A) = \frac{{{n_A}}}{{{n_S}}} = {format_prob(p_A)}$.
        * Biến cố $B$: Chữ số hàng đơn vị có 3 cách chọn (từ $\{{1,3,5\}}$), hai vị trí còn lại có $A_5^2$ cách.
          Vậy $n(B) = 3 \cdot A_5^2 = 3 \cdot 20 = {n_B}$. Suy ra $P(B) = \frac{{{n_B}}}{{{n_S}}} = {format_prob(p_B)}$.
        * Biến cố $AB$: 
          - TH1: Hàng đơn vị là 1 $\Rightarrow$ hàng trăm có 5 cách ($2,3,4,5,6$), hàng chục có 4 cách $\Rightarrow 20$ số.
          - TH2: Hàng đơn vị là 3 hoặc 5 (2 cách) $\Rightarrow$ hàng trăm có 4 cách, hàng chục có 4 cách $\Rightarrow 2 \cdot 4 \cdot 4 = 32$ số.
          Vậy $n(AB) = 20 + 32 = {n_AB}$. Suy ra $P(AB) = \frac{{{n_AB}}}{{{n_S}}} = {format_prob(p_AB)}$.
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
