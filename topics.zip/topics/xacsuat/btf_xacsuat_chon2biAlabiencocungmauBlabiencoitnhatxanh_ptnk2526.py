import random
import math

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def format_prob(value):
    """Định dạng số thực sang chuỗi có dấu phẩy kiểu Việt Nam."""
    if float(value).is_integer(): return str(int(value))
    return f"{value:.3f}".replace('.', ',').rstrip('0').rstrip(',')

def nCr(n, r):
    """Tính tổ hợp chập r của n."""
    if r > n or r < 0: return 0
    return math.comb(n, r)

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    n = random.randint(4, 8)  # Số bi xanh
    m = random.randint(4, 8)  # Số bi đỏ
    tong = n + m
    
    # --- 2. TÍNH TOÁN BIẾN CỐ ---
    # Không gian mẫu: Chọn 2 từ (n+m)
    n_omega = nCr(tong, 2)
    
    # Biến cố A: 2 bi cùng màu (2 xanh hoặc 2 đỏ)
    n_A = nCr(n, 2) + nCr(m, 2)
    p_A = round(n_A / n_omega, 3)
    
    # Biến cố B: Ít nhất 1 bi xanh (Tổng - 2 bi đỏ)
    n_B = n_omega - nCr(m, 2)
    p_B = round(n_B / n_omega, 3)
    
    # Biến cố giao AB: Cùng màu VÀ có ít nhất 1 xanh => Chỉ có thể là 2 bi xanh
    n_AB = nCr(n, 2)
    p_AB = round(n_AB / n_omega, 3)

    # --- 3. DANH SÁCH KHẲNG ĐỊNH ---
    dung_list = [
        rf"Số phần tử của không gian mẫu là $n(\Omega) = {n_omega}$",
        rf"Số kết quả thuận lợi cho biến cố $A$ là $n(A) = {n_A}$",
        rf"Xác suất của biến cố $B$ là $P(B) = \frac{{{n_B}}}{{{n_omega}}}$",
        rf"Xác suất để chọn được 2 bi cùng màu xanh là $P(AB) = {format_prob(p_AB)}$",
        rf"Biến cố đối của $B$ là biến cố: \lq\lq Chọn được 2 bi màu đỏ\rq\rq",
        rf"Số kết quả thuận lợi cho biến cố $B$ là $n(B) = {n_B}$"
    ]
    
    sai_list = [
        rf"Số phần tử của không gian mẫu là $n(\Omega) = {tong}$",
        rf"Số kết quả thuận lợi cho biến cố $A$ là $n(A) = {nCr(n, 1) * nCr(m, 1)}$", # Nhầm sang khác màu
        rf"Xác suất của biến cố $B$ là $P(B) = {format_prob(round(nCr(n, 2)/n_omega, 3))}$", # Nhầm sang 2 bi xanh
        rf"Xác suất của biến cố $A$ là $P(A) = {format_prob(round(n/tong, 3))}$",
        rf"$A$ và $B$ là hai biến cố xung khắc", # Sai vì giao nhau tại trường hợp 2 bi xanh
        rf"Biến cố đối của $A$ là biến cố: \lq\lq Chọn được ít nhất một bi xanh\rq\rq"
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 4. RENDER MÃ EX ---
    return rf"""\begin{{ex}}
    Một hộp chứa ${n}$ quả bi xanh và ${m}$ quả bi đỏ. Lấy ngẫu nhiên đồng thời 2 quả bi từ hộp.
    Gọi $A$ là biến cố: \lq\lq Lấy được 2 quả bi cùng màu\rq\rq, biến cố $B$: \lq\lq Lấy được ít nhất một quả bi xanh\rq\rq.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        * Không gian mẫu: Chọn 2 bi từ ${tong}$ bi nên $n(\Omega) = C_{{{tong}}}^2 = {n_omega}$.
        * Biến cố $A$: Lấy được 2 bi cùng màu (2 xanh hoặc 2 đỏ).
          $n(A) = C_{n}^2 + C_{m}^2 = C_{{{n}}}^2 + C_{{{m}}}^2 = {nCr(n, 2)} + {nCr(m, 2)} = {n_A}$.
          $\Rightarrow P(A) = \frac{{{n_A}}}{{{n_omega}}} = {format_prob(p_A)}$.
        * Biến cố $B$: Lấy được ít nhất một bi xanh. 
          Biến cố đối $\overline{{B}}$: \lq\lq Không lấy được bi xanh nào\rq\rq ~ (tức là lấy được 2 bi đỏ).
          $n(\overline{{B}}) = C_{{{m}}}^2 = {nCr(m, 2)}$.
          $\Rightarrow n(B) = n(\Omega) - n(\overline{{B}}) = {n_omega} - {nCr(m, 2)} = {n_B}$.
          $\Rightarrow P(B) = \frac{{{n_B}}}{{{n_omega}}}$.
        * Biến cố giao $AB$: 2 bi vừa cùng màu vừa có ít nhất 1 xanh $\Rightarrow$ 2 bi cùng màu xanh.
          $n(AB) = C_{{{n}}}^2 = {nCr(n, 2)} \Rightarrow P(AB) = \frac{{{nCr(n, 2)}}}{{{n_omega}}} = {format_prob(p_AB)}$.
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
