import random
import math

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def format_prob(value):
    """Định dạng số thực, giữ nguyên số Pi nếu cần hoặc làm tròn."""
    return f"{value:.3f}".replace('.', ',').rstrip('0').rstrip(',')

def generate():
    # --- 1. THAM SỐ ---
    # Giả sử hình vuông cạnh a = 2, tâm O(0,0)
    # Hình tròn nội tiếp bán kính r = 1
    a = 2
    r = 1
    s_square = a**2 # = 4
    s_circle = math.pi * (r**2) # = pi
    
    # --- 2. TÍNH TOÁN XÁC SUẤT ---
    # P(A): Điểm nằm trong hình tròn
    p_A_val = s_circle / s_square # pi / 4
    p_A_latex = r"\frac{\pi}{4}"
    
    # P(B): Điểm nằm phía trên đường chéo (chia đôi hình vuông)
    p_B_val = 0.5
    p_B_latex = r"\frac{1}{2}"
    
    # P(AB): Điểm nằm trong hình tròn VÀ nằm phía trên đường chéo
    # Đường chéo chia hình tròn thành 2 nửa bằng nhau
    p_AB_val = p_A_val / 2 # pi / 8
    p_AB_latex = r"\frac{\pi}{8}"

    # --- 3. DANH SÁCH KHẲNG ĐỊNH ---
    dung_list = [
        rf"Diện tích miền không gian mẫu là $S = {s_square}$",
        rf"Xác suất của biến cố $A$ là $P(A) = {p_A_latex}$",
        rf"Xác suất của biến cố $B$ là $P(B) = {p_B_latex}$",
        rf"Xác suất của biến cố giao $AB$ là $P(AB) = {p_AB_latex}$",
        rf"$A$ và $B$ là hai biến cố độc lập", # Vì P(A)*P(B) = (pi/4)*(1/2) = pi/8 = P(AB)
        rf"Biến cố đối của $B$ có xác suất $P(\overline{{B}}) = 0,5$"
    ]
    
    sai_list = [
        rf"Xác suất của biến cố $A$ là $P(A) = \frac{{\pi}}{2}$",
        rf"Xác suất của biến cố giao $AB$ là $P(AB) = \frac{{\pi}}{4}$",
        rf"$A$ và $B$ là hai biến cố xung khắc",
        rf"Diện tích hình tròn nội tiếp là $S_C = 2\pi$",
        rf"Xác suất để điểm nằm ngoài hình tròn là $1 - \frac{{\pi}}{8}$",
        rf"Biến cố $B$ có xác suất phụ thuộc vào độ dài cạnh hình vuông"
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 4. RENDER MÃ EX ---
    return rf"""\begin{{ex}}
    Trong mặt phẳng tọa độ $Oxy$, cho hình vuông $V = \{{(x; y) \mid -1 \le x \le 1, -1 \le y \le 1\}}$. Chọn ngẫu nhiên một điểm $M$ trong hình vuông $V$.
    Gọi $A$ là biến cố: \lq\lq Điểm $M$ nằm trong hình tròn $C: x^2 + y^2 \le 1$\rq\rq.
    Gọi $B$ là biến cố: \lq\lq Điểm $M$ nằm phía trên đường thẳng $y = x$\rq\rq.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        * Không gian mẫu là hình vuông có cạnh $a = 2$, diện tích $S_V = 2^2 = 4$.
        * Biến cố $A$: Miền thuận lợi là hình tròn bán kính $R=1$, diện tích $S_A = \pi \cdot 1^2 = \pi$.
          $\Rightarrow P(A) = \frac{{S_A}}{{S_V}} = {p_A_latex}$.
        * Biến cố $B$: Đường thẳng $y = x$ là đường chéo chia hình vuông thành hai phần có diện tích bằng nhau.
          $\Rightarrow P(B) = \frac{1}{2}$.
        * Biến cố $AB$: Vì tâm hình tròn trùng với tâm hình vuông và đường thẳng $y=x$ đi qua tâm này nên nó chia hình tròn thành hai phần bằng nhau.
          Diện tích phần hình tròn nằm phía trên đường thẳng là $S_{{AB}} = \frac{{\pi}}{2}$.
          $\Rightarrow P(AB) = \frac{{\pi/2}}{4} = {p_AB_latex}$.
        * Kiểm tra tính độc lập: $P(A) \cdot P(B) = \frac{{\pi}}{4} \cdot \frac{1}{2} = \frac{{\pi}}{8} = P(AB)$. 
          Vậy $A, B$ độc lập.
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
