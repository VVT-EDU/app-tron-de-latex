import random
from math import comb

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def format_num(n):
    """Định dạng số nguyên có dấu chấm phân cách hàng nghìn."""
    return f"{n:,}".replace(',', '.')

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    n_xanh = random.randint(10, 15)
    n_do = random.randint(16, 22)
    tong = n_xanh + n_do
    
    # --- 2. TÍNH TOÁN CÁC GIÁ TRỊ ---
    n_omega = comb(tong, 2)
    n_A = comb(n_do, 2)    # 2 đỏ
    n_B = comb(n_xanh, 2)  # 2 xanh
    n_C = n_A + n_B        # 2 viên cùng màu (A hợp B)
    n_khac_mau = n_xanh * n_do
    
    # --- 3. DANH SÁCH KHẲNG ĐỊNH ĐỐI ỨNG ---
    dung_list = [
        rf"Biến cố hợp của $A$ và $B$ là biến cố: \lq\lq Lấy được hai viên bi cùng màu\rq\rq",
        rf"Số phần tử của không gian mẫu là $n(\Omega) = {format_num(n_omega)}$",
        rf"$A$ và $B$ là hai biến cố xung khắc",
        rf"Số phần tử của biến cố $A \cup B$ là $n(A \cup B) = {format_num(n_C)}$",
        rf"Xác suất của biến cố $A$ là $P(A) = \dfrac{{{n_A}}}{{{n_omega}}}$",
        rf"Biến cố đối của $A \cup B$ là biến cố: \lq\lq Lấy được hai viên bi khác màu\rq\rq"
    ]
    
    sai_list = [
        rf"Biến cố hợp của $A$ và $B$ là biến cố: \lq\lq Lấy được hai viên bi khác màu\rq\rq",
        rf"Số phần tử của không gian mẫu là $n(\Omega) = {format_num(comb(tong, 1))}$", # Sai: lấy 1 thay vì 2
        rf"$A$ và $B$ là hai biến cố đối nhau", # Sai: vì tổng xác suất chưa bằng 1
        rf"Số phần tử của biến cố $A \cup B$ là $n(A \cup B) = {format_num(n_A * n_B)}$", # Bẫy quy tắc nhân
        rf"Xác suất của biến cố $A$ là $P(A) = \dfrac{{{n_do}}}{{{tong}}}$", # Sai: nhầm sang lấy 1 viên
        rf"Biến cố giao $A \cap B$ là biến cố chắc chắn"
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 4. RENDER MÃ EX ---
    return rf"""\begin{{ex}}
    Một hộp đựng ${n_xanh}$ viên bi màu xanh và ${n_do}$ viên bi màu đỏ. Lấy ngẫu nhiên đồng thời $2$ viên bi từ hộp. Xét các biến cố:
    $A$: \lq\lq Lấy được hai viên bi màu đỏ\rq\rq;
    $B$: \lq\lq Lấy được hai viên bi màu xanh\rq\rq.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        \begin{{itemize}}
            \item Không gian mẫu khi lấy 2 viên từ ${tong}$ viên: $n(\Omega) = C_{{{tong}}}^2 = {n_omega}$.
            \item Biến cố $A \cup B$ (biến cố hợp) xảy ra khi lấy được 2 viên cùng màu đỏ hoặc 2 viên cùng màu xanh. Do đó, đây là biến cố \lq\lq Lấy được hai viên bi cùng màu\rq\rq.
            \item Vì không thể cùng lúc lấy được 2 viên vừa là màu đỏ vừa là màu xanh nên $A \cap B = \varnothing$, suy ra $A, B$ xung khắc.
            \item Số phần tử của biến cố hợp (áp dụng quy tắc cộng): $n(A \cup B) = n(A) + n(B) = C_{{{n_do}}}^2 + C_{{{n_xanh}}}^2 = {n_A} + {n_B} = {n_C}$.
            \item Biến cố đối của \lq\lq cùng màu\rq\rq~là \lq\lq khác màu\rq\rq. Số cách chọn 2 viên khác màu là ${n_xanh} \cdot {n_do} = {n_khac_mau}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
