import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def format_prob(value):
    """Định dạng số thực sang chuỗi có dấu phẩy kiểu Việt Nam."""
    return f"{value:.2f}".replace('.', ',').rstrip('0').rstrip(',')

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    # p1, p2 là xác suất bắn TRÚNG của xạ thủ 1 và 2
    p1 = random.choice([0.6, 0.7, 0.8, 0.9])
    p2 = random.choice([0.5, 0.6, 0.7, 0.8])
    
    # Xác suất bắn trượt tương ứng
    q1 = round(1 - p1, 2)
    q2 = round(1 - p2, 2)
    
    # --- 2. TÍNH TOÁN CÁC BIẾN CỐ ---
    # P(Cả hai cùng trúng)
    p_both_hit = round(p1 * p2, 3)
    
    # P(Cả hai cùng trượt)
    p_both_miss = round(q1 * q2, 3)
    
    # P(Ít nhất một người trúng) = 1 - P(Cả hai trượt)
    p_at_least_one_hit = round(1 - p_both_miss, 3)
    
    # P(Xạ thủ 1 trúng, xạ thủ 2 trượt)
    p_hit_miss = round(p1 * q2, 3)

    # --- 3. DANH SÁCH KHẲNG ĐỊNH ĐỐI ỨNG ---
    dung_list = [
        rf"$A$ và $B$ là hai biến cố độc lập",
        rf"Xác suất để cả hai xạ thủ cùng bắn trúng bia là ${format_prob(p_both_hit)}$",
        rf"Xác suất để có ít nhất một xạ thủ bắn trúng bia là ${format_prob(p_at_least_one_hit)}$",
        rf"Xác suất để xạ thủ thứ nhất trúng và xạ thủ thứ hai trượt là ${format_prob(p_hit_miss)}$",
        rf"Xác suất để cả hai xạ thủ cùng bắn trượt bia là ${format_prob(p_both_miss)}$",
        rf"Biến cố đối của biến cố \lq\lq Cả hai xạ thủ đều bắn trượt\rq\rq~là \lq\lq Có ít nhất một xạ thủ bắn trúng\rq\rq"
    ]
    
    sai_list = [
        rf"$A$ và $B$ là hai biến cố xung khắc",
        rf"Xác suất để cả hai xạ thủ cùng bắn trúng bia là ${format_prob(p1 + p2)}$", # Sai quy tắc nhân
        rf"Xác suất để có ít nhất một xạ thủ bắn trúng bia là ${format_prob(p_both_miss)}$", # Nhầm với biến cố đối
        rf"Xác suất để xạ thủ thứ nhất trúng và xạ thủ thứ hai trượt là ${format_prob(p2 * q1)}$", # Ngược xạ thủ
        rf"Xác suất để cả hai xạ thủ cùng bắn trượt bia là ${format_prob(q1 + q2)}$", # Sai quy tắc nhân
        rf"Xác suất để biến cố $A$ xảy ra là $P(A) = {format_prob(q1)}$" # Nhầm trúng thành trượt
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 4. RENDER MÃ EX ---
    return rf"""\begin{{ex}}
    Hai xạ thủ cùng nổ súng bắn vào một bia một cách độc lập. Xác suất bắn trúng đích của xạ thủ thứ nhất và xạ
    thủ thứ hai lần lượt là ${format_prob(p1)}$ và ${format_prob(p2)}$. 
    Gọi biến cố $A$: \lq\lq Xạ thủ thứ nhất bắn trúng bia\rq\rq, biến cố $B$: \lq\lq Xạ thủ thứ hai bắn trúng bia\rq\rq.
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        Ta có $P(A) = {format_prob(p1)}$, $P(B) = {format_prob(p2)}$. Suy ra $P(\overline{{A}}) = {format_prob(q1)}$, $P(\overline{{B}}) = {format_prob(q2)}$.
        \begin{{itemize}}
            \item Vì hai xạ thủ bắn độc lập nên $A, B$ là hai biến cố độc lập.
            \item Xác suất cả hai cùng trúng: $P(AB) = P(A) \cdot P(B) = {format_prob(p1)} \cdot {format_prob(p2)} = {format_prob(p_both_hit)}$.
            \item Xác suất cả hai cùng trượt: $P(\overline{{A}} \cdot \overline{{B}}) = P(\overline{{A}}) \cdot P(\overline{{B}}) = {format_prob(q1)} \cdot {format_prob(q2)} = {format_prob(p_both_miss)}$.
            \item Xác suất có ít nhất một người trúng: $P = 1 - P(\overline{{A}} \cdot \overline{{B}}) = 1 - {format_prob(p_both_miss)} = {format_prob(p_at_least_one_hit)}$.
            \item Xác suất xạ thủ 1 trúng, xạ thủ 2 trượt: $P(A\overline{{B}}) = P(A) \cdot P(\overline{{B}}) = {format_prob(p1)} \cdot {format_prob(q2)} = {format_prob(p_hit_miss)}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
