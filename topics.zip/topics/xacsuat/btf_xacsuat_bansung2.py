import random

def nhanvao_dsdungsai_rachoice_dungsai(dung, sai):
    """Trộn 2 đúng, 2 sai từ danh sách khẳng định đối ứng."""
    all_indices = random.sample(range(min(len(dung), len(sai))), 4)
    idx_dung = all_indices[:2]
    idx_sai = all_indices[2:]
    
    selected_dung = [dung[i] for i in idx_dung]
    selected_sai = [sai[i] for i in idx_sai]
    
    choices = [r'\True ' + item for item in selected_dung] + selected_sai
    random.shuffle(choices)
    
    choice_str = (f"\\choiceTF \n"
                  f" {{ {choices[0]} }}\n"
                  f" {{ {choices[1]} }}\n"
                  f" {{ {choices[2]} }}\n"
                  f" {{ {choices[3]} }}")
    return choice_str

def format_p(value):
    """Định dạng số thực sang chuỗi có dấu phẩy kiểu Việt Nam."""
    return f"{round(value, 4)}".replace('.', ',')

def generate():
    # --- 1. THAM SỐ NGẪU NHIÊN ---
    # Xác suất bắn trúng của 3 xạ thủ P(A1), P(A2), P(A3)
    p1 = random.choice([0.6, 0.7, 0.8])
    p2 = random.choice([0.5, 0.6, 0.65])
    p3 = random.choice([0.4, 0.5, 0.7])
    
    # Xác suất trượt (biến cố đối)
    q1, q2, q3 = round(1-p1, 2), round(1-p2, 2), round(1-p3, 2)
    
    # --- 2. TÍNH TOÁN CÁC BIẾN CỐ ---
    # P(Cả 3 cùng trượt)
    p_none_hit = round(q1 * q2 * q3, 4)
    
    # P(Ít nhất 1 người trúng) = 1 - P(Cả 3 trượt)
    p_at_least_one = round(1 - p_none_hit, 4)
    
    # P(Cả 3 cùng trúng)
    p_all_hit = round(p1 * p2 * p3, 4)
    
    # P(Chỉ người thứ nhất trúng) = p1 * q2 * q3
    p_only_first = round(p1 * q2 * q3, 4)

    # --- 3. DANH SÁCH KHẲNG ĐỊNH ĐỐI ỨNG ---
    dung_list = [
        rf"Xác suất để cả ba xạ thủ cùng bắn trượt là ${format_p(p_none_hit)}$",
        rf"Xác suất để có ít nhất một xạ thủ bắn trúng mục tiêu là ${format_p(p_at_least_one)}$",
        rf"Xác suất để cả ba xạ thủ cùng bắn trúng mục tiêu là ${format_p(p_all_hit)}$",
        rf"Xác suất để chỉ có duy nhất xạ thủ thứ nhất bắn trúng là ${format_p(p_only_first)}$",
        rf"Biến cố \lq\lq Có ít nhất một xạ thủ bắn trúng\rq\rq~là biến cố đối của biến cố \lq\lq Cả ba xạ thủ bắn trượt\rq\rq",
        rf"Xác suất xạ thủ thứ hai bắn trượt mục tiêu là ${format_p(q2)}$"
    ]
    
    sai_list = [
        rf"Xác suất để cả ba xạ thủ cùng bắn trượt là ${format_p(q1+q2+q3)}$", # Sai: dùng tổng xác suất trượt
        rf"Xác suất để có ít nhất một xạ thủ bắn trúng mục tiêu là ${format_p(p_none_hit)}$", # Sai: nhầm với biến cố đối
        rf"Xác suất để cả ba xạ thủ cùng bắn trúng mục tiêu là ${format_p(p1+p2+p3)}$", # Sai: dùng tổng xác suất trúng
        rf"Xác suất để chỉ có duy nhất xạ thủ thứ nhất bắn trúng là ${format_p(p1)}$", # Sai: nhầm với P(A1)
        rf"Ba biến cố xạ thủ trúng mục tiêu là các biến cố xung khắc", # Sai: đây là biến cố độc lập
        rf"Xác suất xạ thủ thứ hai bắn trượt mục tiêu là ${format_p(p2)}$" # Sai: nhầm trúng thành trượt
    ]
    
    choice_tf = nhanvao_dsdungsai_rachoice_dungsai(dung_list, sai_list)

    # --- 4. RENDER MÃ EX ---
    return rf"""\begin{{ex}}
    Ba xạ thủ cùng nổ súng bắn vào mục tiêu một cách độc lập. Biết rằng xác suất bắn trúng mục tiêu của ba xạ thủ lần lượt là ${format_p(p1)}$; ${format_p(p2)}$; ${format_p(p3)}$. 
    \textbf{{Xét tính đúng sai của các khẳng định sau:}}
    {choice_tf}
    \loigiai{{
        Gọi $A_i$ là biến cố xạ thủ thứ $i$ bắn trúng mục tiêu ($i=1, 2, 3$).
        Ta có $P(A_1)={format_p(p1)}$, $P(A_2)={format_p(p2)}$, $P(A_3)={format_p(p3)}$.
        Suy ra xác suất bắn trượt tương ứng là $P(\overline{{A_1}})={format_p(q1)}$, $P(\overline{{A_2}})={format_p(q2)}$, $P(\overline{{A_3}})={format_p(q3)}$.
        \begin{{itemize}}
            \item Xác suất cả ba cùng trượt: $P(\overline{{A_1}} \cdot \overline{{A_2}} \cdot \overline{{A_3}}) = {format_p(q1)} \cdot {format_p(q2)} \cdot {format_p(q3)} = {format_p(p_none_hit)}$.
            \item Xác suất ít nhất một xạ thủ trúng: $P = 1 - P(\text{{cả 3 trượt}}) = 1 - {format_p(p_none_hit)} = {format_p(p_at_least_one)}$.
            \item Xác suất cả ba cùng trúng: $P(A_1 A_2 A_3) = {format_p(p1)} \cdot {format_p(p2)} \cdot {format_p(p3)} = {format_p(p_all_hit)}$.
            \item Xác suất chỉ xạ thủ 1 trúng: $P(A_1 \overline{{A_2}} \cdot \overline{{A_3}}) = {format_p(p1)} \cdot {format_p(q2)} \cdot {format_p(q3)} = {format_p(p_only_first)}$.
        \end{{itemize}}
    }}
\end{{ex}}"""

if __name__ == "__main__":
    print(generate())
